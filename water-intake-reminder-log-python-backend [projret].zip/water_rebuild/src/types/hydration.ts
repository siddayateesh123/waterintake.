export type CategoryType = "Morning" | "Afternoon" | "Evening" | "Night" | "Other";
export type DatasetMode = "demo" | "personal";
export type UnitMode = "ml" | "L";
export type ThemeMode = "light" | "dark";

export type NavSection =
  | "dashboard"
  | "log"
  | "history"
  | "analytics"
  | "reports"
  | "import"
  | "settings"
  | "help";

export interface UnusualWarning {
  level: "low" | "high";
  message: string;
}

export interface WaterRecord {
  id: number;
  date: string;
  time: string;
  amount_ml: number;
  category: CategoryType;
  notes: string;
  unusual_warning?: UnusualWarning | null;
}

export interface AppSettings {
  daily_target_ml: number;
  preferred_unit: UnitMode;
  reminders_enabled: boolean;
  reminder_interval_min: number;
  browser_notifications: boolean;
  low_threshold_ml: number;
  high_threshold_ml: number;
  theme: ThemeMode;
  active_dataset: DatasetMode;
}

export interface TimelineEntry {
  id: number;
  time: string;
  label: string;
  amount_ml: number;
  cumulative_ml: number;
  target_ml: number;
  category: CategoryType;
  notes: string;
}

export interface WeeklySeriesPoint {
  date: string;
  label: string;
  short_day: string;
  total_ml: number;
  target_ml: number;
  completion_pct: number;
  entries: number;
  met_target: boolean;
}

export interface MonthlySeriesPoint {
  date: string;
  label: string;
  total_ml: number;
  target_ml: number;
}

export interface WeeklyComparisonBucket {
  week: string;
  range: string;
  total_ml: number;
  average_ml: number;
  target_ml: number;
}

export interface DailyPatternPoint {
  day: string;
  average_ml: number;
  logged_days: number;
}

export interface CategoryDistributionPoint {
  category: CategoryType;
  total_ml: number;
  count: number;
  percentage: number;
}

export interface AnalyticsData {
  reference_date: string;
  total_records: number;
  overall_total_ml: number;
  overall_highest_day: { date: string; total_ml: number };
  overall_lowest_day: { date: string; total_ml: number };
  daily: {
    date: string;
    day_name: string;
    total_ml: number;
    total_liters: number;
    target_ml: number;
    target_liters: number;
    remaining_ml: number;
    remaining_liters: number;
    exceeded_ml: number;
    exceeded_liters: number;
    completion_pct: number;
    entry_count: number;
    highest_entry_ml: number;
    hydration_status: string;
    timeline: TimelineEntry[];
  };
  weekly: {
    start_date: string;
    end_date: string;
    total_ml: number;
    total_liters: number;
    daily_average_ml: number;
    daily_average_liters: number;
    highest_day: { date: string; label: string; total_ml: number };
    lowest_day: { date: string; label: string; total_ml: number };
    days_target_achieved: number;
    series: WeeklySeriesPoint[];
  };
  monthly: {
    start_date: string;
    end_date: string;
    total_ml: number;
    total_liters: number;
    daily_average_ml: number;
    monthly_completion_pct: number;
    active_days: number;
    days_target_achieved: number;
    series: MonthlySeriesPoint[];
    weekly_comparison: WeeklyComparisonBucket[];
    daily_patterns: DailyPatternPoint[];
  };
  category_distribution: CategoryDistributionPoint[];
}

export interface ChartEngineStatus {
  matplotlib_available: boolean;
  client_png_fallback_available: boolean;
  supported_charts: Record<string, string>;
  message: string;
}

export interface ToastNotification {
  id: string;
  type: "success" | "warning" | "error" | "info" | "reminder";
  title: string;
  message: string;
  timestamp: string;
}

export interface ImportPreviewResult {
  total_rows: number;
  valid_count: number;
  invalid_count: number;
  valid_rows: Array<{
    row_number: number;
    date: string;
    time: string;
    amount_ml: number;
    category: CategoryType;
    notes: string;
    unusual_warning?: UnusualWarning | null;
  }>;
  invalid_rows: Array<{
    row_number: number;
    raw: Record<string, string>;
    errors: string[];
  }>;
  dataset: DatasetMode;
}

export interface ReportSummary {
  title: string;
  dataset: DatasetMode;
  generated_at: string;
  date_range: { start: string; end: string };
  total_consumption_ml: number;
  total_consumption_liters: number;
  average_daily_ml: number;
  average_daily_liters: number;
  daily_target_ml: number;
  daily_target_liters: number;
  target_completion_pct: number;
  total_records: number;
  active_days: number;
  highest_intake_day: { date: string; total_ml: number };
  lowest_intake_day: { date: string; total_ml: number };
  daily_trends: Array<{ date: string; total_ml: number }>;
  weekly_trends: WeeklyComparisonBucket[];
  records: WaterRecord[];
}
