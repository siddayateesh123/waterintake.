interface CircularProgressProps {
  percentage: number;
  size?: number;
  strokeWidth?: number;
  statusLabel: string;
}

export function CircularProgress({
  percentage,
  size = 112,
  strokeWidth = 9,
  statusLabel,
}: CircularProgressProps) {
  const clamped = Math.max(0, Math.min(100, percentage));
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (clamped / 100) * circumference;
  const isComplete = percentage >= 100;

  return (
    <div className="flex items-center gap-4">
      <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90 transform" aria-hidden="true">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="transparent"
            stroke="currentColor"
            strokeWidth={strokeWidth}
            className="text-blue-100 dark:text-slate-700"
          />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="transparent"
            stroke="currentColor"
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            className={`transition-[stroke-dashoffset] duration-500 ease-out ${
              isComplete ? "text-[#14B8A6]" : "text-[#2196F3] dark:text-sky-400"
            }`}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-mono-num text-lg font-bold text-[#172554] dark:text-slate-50">
            {percentage.toFixed(0)}%
          </span>
        </div>
      </div>
      <div className="min-w-0">
        <p className="text-xs text-slate-500 dark:text-slate-400">Daily Goal Status</p>
        <p
          className={`mt-0.5 text-sm font-semibold ${
            isComplete ? "text-[#14B8A6] dark:text-teal-400" : "text-[#172554] dark:text-slate-100"
          }`}
        >
          {statusLabel}
        </p>
      </div>
    </div>
  );
}
