import {
  BarChart3,
  BookOpen,
  Droplets,
  FileSpreadsheet,
  History,
  LayoutDashboard,
  PlusCircle,
  Settings,
  Upload,
  X,
} from "lucide-react";
import type { DatasetMode, NavSection } from "../types/hydration";

interface SidebarProps {
  activeNav: NavSection;
  onSelectNav: (nav: NavSection) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  activeDataset: DatasetMode;
  recordCount: number;
}

const NAV_ITEMS: Array<{ id: NavSection; label: string; icon: typeof LayoutDashboard }> = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "log", label: "Log Water Intake", icon: PlusCircle },
  { id: "history", label: "History", icon: History },
  { id: "analytics", label: "Analytics", icon: BarChart3 },
  { id: "reports", label: "Reports & Export", icon: FileSpreadsheet },
  { id: "import", label: "Import Data", icon: Upload },
  { id: "settings", label: "Settings", icon: Settings },
  { id: "help", label: "Help & About", icon: BookOpen },
];

export function Sidebar({
  activeNav,
  onSelectNav,
  mobileOpen,
  onCloseMobile,
  activeDataset,
  recordCount,
}: SidebarProps) {
  const handleSelect = (id: NavSection) => {
    onSelectNav(id);
    onCloseMobile();
  };

  return (
    <>
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-[1px] lg:hidden"
          onClick={onCloseMobile}
          aria-hidden="true"
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-[260px] flex-col border-r border-blue-100 bg-white transition-transform duration-200 ease-out dark:border-slate-800 dark:bg-slate-900 lg:static lg:translate-x-0 ${
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        }`}
        aria-label="Primary navigation"
      >
        <div className="flex h-16 items-center justify-between border-b border-blue-100 px-5 dark:border-slate-800">
          <button
            type="button"
            onClick={() => handleSelect("dashboard")}
            className="flex items-center gap-2.5 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2196F3] rounded-md"
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#2196F3] text-white">
              <Droplets className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <span className="block truncate font-display text-sm font-bold tracking-tight text-[#172554] dark:text-slate-50">
                Water Intake Log
              </span>
              <span className="block truncate text-xs text-slate-500 dark:text-slate-400">
                CampusSolve #31
              </span>
            </div>
          </button>

          <button
            type="button"
            onClick={onCloseMobile}
            className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-500 hover:bg-blue-50 hover:text-[#172554] dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-100 lg:hidden"
            aria-label="Close navigation menu"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4">
          <ul className="space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = activeNav === item.id;
              return (
                <li key={item.id}>
                  <button
                    type="button"
                    onClick={() => handleSelect(item.id)}
                    className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors duration-150 whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2196F3] ${
                      isActive
                        ? "bg-blue-50 text-[#2196F3] dark:bg-sky-950/60 dark:text-sky-400"
                        : "text-slate-600 hover:bg-slate-50 hover:text-[#172554] dark:text-slate-300 dark:hover:bg-slate-800/70 dark:hover:text-slate-50"
                    }`}
                  >
                    <Icon
                      className={`h-4 w-4 shrink-0 ${
                        isActive ? "text-[#2196F3] dark:text-sky-400" : "text-slate-400 dark:text-slate-500"
                      }`}
                    />
                    <span className="truncate">{item.label}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="border-t border-blue-100 p-4 dark:border-slate-800">
          <div className="rounded-lg border border-blue-100 bg-[#F4F9FF] px-3.5 py-3 dark:border-slate-700 dark:bg-slate-800/60">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Active Workspace
            </p>
            <p className="mt-0.5 text-sm font-semibold text-[#172554] dark:text-slate-100">
              {activeDataset === "demo" ? "Demonstration Dataset" : "Personal Hydration Log"}
            </p>
            <p className="mt-1 font-mono-num text-xs text-slate-600 dark:text-slate-400">
              {recordCount} stored {recordCount === 1 ? "entry" : "entries"} · JSON & CSV
            </p>
          </div>
        </div>
      </aside>
    </>
  );
}
