import type {
  AnalyticsData,
  AppSettings,
  CategoryType,
  ChartEngineStatus,
  DatasetMode,
  ImportPreviewResult,
  ReportSummary,
  WaterRecord,
} from "../types/hydration";
import { getLocalDateString } from "../utils/formatters";

async function requestJson<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const data = (await response.json()) as T & { ok?: boolean; error?: string };
  if (!response.ok || data.ok === false) {
    throw new Error(data.error || "Unable to complete the requested operation.");
  }
  return data;
}

export interface BootstrapResponse {
  ok: boolean;
  settings: AppSettings;
  records: WaterRecord[];
  total: number;
  analytics: AnalyticsData;
  chart_engine: ChartEngineStatus;
  recovery_notice?: string | null;
}

export async function fetchBootstrap(dataset?: DatasetMode): Promise<BootstrapResponse> {
  const params = new URLSearchParams({ reference_date: getLocalDateString() });
  if (dataset) params.set("dataset", dataset);
  return requestJson<BootstrapResponse>(`/api/bootstrap?${params.toString()}`);
}

export async function fetchRecords(query: {
  dataset?: DatasetMode;
  search?: string;
  category?: string;
  date?: string;
  start_date?: string;
  end_date?: string;
  sort_by?: string;
  page?: number;
  page_size?: number;
}) {
  const params = new URLSearchParams();
  Object.entries(query).forEach(([k, v]) => {
    if (v !== undefined && v !== "" && v !== null) {
      params.set(k, String(v));
    }
  });
  return requestJson<{
    ok: boolean;
    records: WaterRecord[];
    total: number;
    page: number;
    page_size: number;
    total_pages: number;
    dataset: DatasetMode;
  }>(`/api/records?${params.toString()}`);
}

export async function addWaterRecord(payload: {
  date: string;
  time: string;
  amount_ml: number | string;
  category: CategoryType | string;
  notes?: string;
  dataset?: DatasetMode;
}) {
  return requestJson<{
    ok: boolean;
    record: WaterRecord;
    warning?: { level: "low" | "high"; message: string } | null;
    target_just_reached: boolean;
    date_total_ml: number;
    analytics: AnalyticsData;
  }>("/api/records", {
    method: "POST",
    body: JSON.stringify({ ...payload, reference_date: getLocalDateString() }),
  });
}

export async function updateWaterRecord(
  id: number,
  payload: {
    date: string;
    time: string;
    amount_ml: number | string;
    category: CategoryType | string;
    notes?: string;
    dataset?: DatasetMode;
  }
) {
  return requestJson<{
    ok: boolean;
    record: WaterRecord;
    warning?: { level: "low" | "high"; message: string } | null;
    analytics: AnalyticsData;
  }>(`/api/records/${id}`, {
    method: "PUT",
    body: JSON.stringify({ ...payload, reference_date: getLocalDateString() }),
  });
}

export async function deleteWaterRecord(id: number, dataset: DatasetMode) {
  const params = new URLSearchParams({
    dataset,
    reference_date: getLocalDateString(),
  });
  return requestJson<{
    ok: boolean;
    deleted_id: number;
    remaining_count: number;
    analytics: AnalyticsData;
  }>(`/api/records/${id}?${params.toString()}`, {
    method: "DELETE",
  });
}

export async function updateAppSettings(patch: Partial<AppSettings>) {
  return requestJson<{
    ok: boolean;
    settings: AppSettings;
    analytics: AnalyticsData;
  }>("/api/settings", {
    method: "PUT",
    body: JSON.stringify({ ...patch, reference_date: getLocalDateString() }),
  });
}

export async function resetDemoDataset() {
  return requestJson<{
    ok: boolean;
    count: number;
    records: WaterRecord[];
    analytics: AnalyticsData;
  }>("/api/dataset/reset-demo", {
    method: "POST",
    body: JSON.stringify({ reference_date: getLocalDateString() }),
  });
}

export async function clearPersonalDataset() {
  return requestJson<{
    ok: boolean;
    count: number;
    records: WaterRecord[];
    analytics: AnalyticsData;
  }>("/api/dataset/clear-personal", {
    method: "POST",
    body: JSON.stringify({ reference_date: getLocalDateString() }),
  });
}

export async function previewCsvImport(csvText: string, dataset: DatasetMode) {
  return requestJson<{ ok: boolean } & ImportPreviewResult>("/api/import/preview", {
    method: "POST",
    body: JSON.stringify({ csv_text: csvText, dataset }),
  });
}

export async function commitCsvImport(csvText: string, dataset: DatasetMode) {
  return requestJson<{
    ok: boolean;
    imported_count: number;
    rejected_count: number;
    total_rows: number;
    invalid_rows: ImportPreviewResult["invalid_rows"];
    analytics: AnalyticsData;
  }>("/api/import/commit", {
    method: "POST",
    body: JSON.stringify({ csv_text: csvText, dataset, reference_date: getLocalDateString() }),
  });
}

export async function fetchReportSummary(query: {
  dataset: DatasetMode;
  start_date?: string;
  end_date?: string;
  category?: string;
  search?: string;
  title?: string;
}) {
  const params = new URLSearchParams({ reference_date: getLocalDateString() });
  Object.entries(query).forEach(([k, v]) => {
    if (v !== undefined && v !== "") params.set(k, String(v));
  });
  return requestJson<{
    ok: boolean;
    summary: ReportSummary;
    chart_engine: ChartEngineStatus;
  }>(`/api/reports/summary?${params.toString()}`);
}

export async function fetchSampleFile(kind: "csv" | "json" | "mixed_csv") {
  return requestJson<{ ok: boolean; filename: string; content: string }>(`/api/sample-file/${kind}`);
}

export function buildReportExportUrl(query: {
  dataset: DatasetMode;
  format: "csv" | "md" | "txt";
  start_date?: string;
  end_date?: string;
  category?: string;
  search?: string;
  title?: string;
}): string {
  const params = new URLSearchParams({ reference_date: getLocalDateString() });
  Object.entries(query).forEach(([k, v]) => {
    if (v !== undefined && v !== "") params.set(k, String(v));
  });
  return `/api/reports/export?${params.toString()}`;
}
