import { useCallback, useEffect, useState } from "react";
import { ConfirmModal } from "./components/ConfirmModal";
import { EditRecordModal } from "./components/EditRecordModal";
import { Header } from "./components/Header";
import { QuickAddModal } from "./components/QuickAddModal";
import { Sidebar } from "./components/Sidebar";
import { ToastContainer } from "./components/ToastContainer";
import { useReminders } from "./hooks/useReminders";
import { AnalyticsPage } from "./pages/AnalyticsPage";
import { DashboardPage } from "./pages/DashboardPage";
import { HelpAboutPage } from "./pages/HelpAboutPage";
import { HistoryPage } from "./pages/HistoryPage";
import { ImportPage } from "./pages/ImportPage";
import { LogIntakePage } from "./pages/LogIntakePage";
import { ReportsPage } from "./pages/ReportsPage";
import { SettingsPage } from "./pages/SettingsPage";
import {
  addWaterRecord,
  clearPersonalDataset,
  deleteWaterRecord,
  fetchBootstrap,
  fetchRecords,
  resetDemoDataset,
  updateAppSettings,
  updateWaterRecord,
} from "./services/api";
import type {
  AnalyticsData,
  AppSettings,
  CategoryType,
  ChartEngineStatus,
  DatasetMode,
  NavSection,
  ToastNotification,
  WaterRecord,
} from "./types/hydration";

export default function App() {
  const [activeNav, setActiveNav] = useState<NavSection>("dashboard");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [records, setRecords] = useState<WaterRecord[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [chartEngine, setChartEngine] = useState<ChartEngineStatus>({
    matplotlib_available: false,
    client_png_fallback_available: true,
    supported_charts: {},
    message: "",
  });

  const [toasts, setToasts] = useState<ToastNotification[]>([]);
  const [notificationHistory, setNotificationHistory] = useState<ToastNotification[]>([]);

  const [quickAddOpen, setQuickAddOpen] = useState(false);
  const [quickAddPreset, setQuickAddPreset] = useState<number | "">(250);
  const [editingRecord, setEditingRecord] = useState<WaterRecord | null>(null);
  const [confirmState, setConfirmState] = useState<{
    open: boolean;
    title: string;
    description: string;
    confirmLabel: string;
    destructive: boolean;
    onConfirm: () => Promise<void>;
  }>({
    open: false,
    title: "",
    description: "",
    confirmLabel: "Confirm",
    destructive: true,
    onConfirm: async () => {},
  });

  const pushToast = useCallback(
    (toast: Omit<ToastNotification, "id" | "timestamp">) => {
      const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      const timestamp = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      const entry: ToastNotification = { ...toast, id, timestamp };
      setToasts((prev) => [entry, ...prev].slice(0, 4));
      setNotificationHistory((prev) => [entry, ...prev].slice(0, 20));
      window.setTimeout(() => {
        setToasts((prev) => prev.filter((item) => item.id !== id));
      }, 6000);
    },
    []
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((item) => item.id !== id));
  }, []);

  const notifyHelper = useCallback(
    (type: ToastNotification["type"], title: string, message: string) => {
      pushToast({ type, title, message });
    },
    [pushToast]
  );

  const loadAppData = useCallback(async (datasetOverride?: DatasetMode) => {
    setLoading(true);
    setLoadError("");
    try {
      const res = await fetchBootstrap(datasetOverride);
      setSettings(res.settings);
      setRecords(res.records);
      setAnalytics(res.analytics);
      setChartEngine(res.chart_engine);
      if (res.recovery_notice) {
        pushToast({
          type: "warning",
          title: "Storage Auto-Recovery",
          message: res.recovery_notice,
        });
      }
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : "Unable to load application data.");
    } finally {
      setLoading(false);
    }
  }, [pushToast]);

  useEffect(() => {
    void loadAppData();
  }, [loadAppData]);

  // Keep HTML root .dark class synchronized with settings.theme
  useEffect(() => {
    const root = document.documentElement;
    if (settings?.theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
  }, [settings?.theme]);

  useReminders(settings, analytics?.daily.remaining_ml ?? 0, pushToast);

  const refreshRecords = useCallback(async (dataset: DatasetMode) => {
    const res = await fetchRecords({ dataset, sort_by: "date_desc" });
    setRecords(res.records);
  }, []);

  const handleAddRecord = async (payload: {
    amount_ml: string;
    date: string;
    time: string;
    category: CategoryType;
    notes: string;
  }) => {
    if (!settings) return;
    const res = await addWaterRecord({ ...payload, dataset: settings.active_dataset });
    setAnalytics(res.analytics);
    await refreshRecords(settings.active_dataset);

    pushToast({
      type: "success",
      title: "Water Intake Recorded",
      message: `Added ${res.record.amount_ml} ml (${res.record.category}) for ${res.record.date}.`,
    });

    if (res.warning) {
      pushToast({
        type: "warning",
        title: "Entry Review Notice",
        message: res.warning.message,
      });
    }

    if (res.target_just_reached) {
      const msg = `Daily target of ${settings.daily_target_ml.toLocaleString()} ml achieved!`;
      pushToast({
        type: "success",
        title: "Daily Target Reached",
        message: msg,
      });
      if (
        settings.browser_notifications &&
        "Notification" in window &&
        Notification.permission === "granted"
      ) {
        try {
          new Notification("Daily Hydration Target Reached", { body: msg });
        } catch {
          // Ignore browser restriction
        }
      }
    }
  };

  const handleUpdateRecord = async (
    id: number,
    payload: {
      amount_ml: string;
      date: string;
      time: string;
      category: CategoryType;
      notes: string;
    }
  ) => {
    if (!settings) return;
    const res = await updateWaterRecord(id, { ...payload, dataset: settings.active_dataset });
    setAnalytics(res.analytics);
    await refreshRecords(settings.active_dataset);
    pushToast({
      type: "success",
      title: "Record Updated",
      message: `Updated entry #${id} to ${res.record.amount_ml} ml.`,
    });
    if (res.warning) {
      pushToast({
        type: "warning",
        title: "Entry Review Notice",
        message: res.warning.message,
      });
    }
  };

  const handleDeleteRequest = (record: WaterRecord) => {
    if (!settings) return;
    setConfirmState({
      open: true,
      title: `Delete Record #${record.id}?`,
      description: `This will permanently remove the ${record.amount_ml} ml entry logged on ${record.date} at ${record.time} from both JSON and CSV storage.`,
      confirmLabel: "Delete Entry",
      destructive: true,
      onConfirm: async () => {
        const res = await deleteWaterRecord(record.id, settings.active_dataset);
        setAnalytics(res.analytics);
        await refreshRecords(settings.active_dataset);
        pushToast({
          type: "info",
          title: "Record Deleted",
          message: `Removed entry #${record.id}.`,
        });
      },
    });
  };

  const handleSaveSettings = async (patch: Partial<AppSettings>) => {
    const res = await updateAppSettings(patch);
    setSettings(res.settings);
    setAnalytics(res.analytics);
    await refreshRecords(res.settings.active_dataset);
    pushToast({
      type: "success",
      title: "Preferences Updated",
      message: "Your settings and hydration target calculations have been saved.",
    });
  };

  const handleSwitchDataset = async (mode: DatasetMode) => {
    if (!settings || settings.active_dataset === mode) return;
    try {
      const res = await updateAppSettings({ active_dataset: mode });
      setSettings(res.settings);
      setAnalytics(res.analytics);
      await refreshRecords(mode);
      pushToast({
        type: "info",
        title: "Workspace Switched",
        message:
          mode === "demo"
            ? "Now viewing the 42-record Demonstration Dataset."
            : "Now viewing your Personal Hydration Log.",
      });
    } catch (err) {
      pushToast({
        type: "error",
        title: "Switch Failed",
        message: err instanceof Error ? err.message : "Unable to switch dataset.",
      });
    }
  };

  const handleToggleTheme = async () => {
    if (!settings) return;
    const nextTheme = settings.theme === "dark" ? "light" : "dark";
    try {
      const res = await updateAppSettings({ theme: nextTheme });
      setSettings(res.settings);
      setAnalytics(res.analytics);
    } catch {
      // Fallback local toggle
      setSettings({ ...settings, theme: nextTheme });
    }
  };

  const handleTriggerTestReminder = () => {
    const rem = analytics?.daily.remaining_ml ?? 0;
    const msg =
      rem > 0
        ? `Hydration check-in: ${Math.round(rem).toLocaleString()} ml left to reach today's target.`
        : "Hydration check-in: Daily hydration target already achieved!";
    pushToast({
      type: "reminder",
      title: "Hydration Reminder",
      message: msg,
    });
    if (
      settings?.browser_notifications &&
      "Notification" in window &&
      Notification.permission === "granted"
    ) {
      try {
        new Notification("Water Intake Reminder Log", { body: msg });
      } catch {
        // Toast already displayed
      }
    }
  };

  const handleRequestResetDemo = () => {
    setConfirmState({
      open: true,
      title: "Reset Demonstration Dataset?",
      description:
        "Restores the 42 realistic sample records (including boundary values) anchored to today's date. Your Personal Log remains untouched.",
      confirmLabel: "Reset Demo Data",
      destructive: false,
      onConfirm: async () => {
        const res = await resetDemoDataset();
        if (settings?.active_dataset === "demo") {
          setRecords(res.records);
          setAnalytics(res.analytics);
        }
        pushToast({
          type: "success",
          title: "Demonstration Data Restored",
          message: `Restored ${res.count} demonstration records.`,
        });
      },
    });
  };

  const handleRequestClearPersonal = () => {
    setConfirmState({
      open: true,
      title: "Clear Personal Hydration Log?",
      description:
        "Permanently deletes all entries in your Personal Log (water_records.json and water_records.csv). Demonstration data is unaffected.",
      confirmLabel: "Clear Personal Log",
      destructive: true,
      onConfirm: async () => {
        const res = await clearPersonalDataset();
        if (settings?.active_dataset === "personal") {
          setRecords([]);
          setAnalytics(res.analytics);
        }
        pushToast({
          type: "info",
          title: "Personal Log Cleared",
          message: "All personal hydration records have been removed.",
        });
      },
    });
  };

  if (loading && !settings) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F4F9FF] text-[#172554] dark:bg-slate-950 dark:text-slate-100">
        <div className="space-y-3 text-center">
          <div className="mx-auto h-10 w-10 animate-spin rounded-full border-4 border-blue-200 border-t-[#2196F3]" />
          <p className="text-sm font-medium">Loading Water Intake Reminder Log...</p>
        </div>
      </div>
    );
  }

  if (loadError || !settings || !analytics) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F4F9FF] p-6 dark:bg-slate-950">
        <div className="max-w-md rounded-xl border border-red-200 bg-white p-6 text-center dark:border-red-900 dark:bg-slate-900">
          <h1 className="font-display text-lg font-bold text-[#172554] dark:text-slate-50">
            Unable to Load Application
          </h1>
          <p className="mt-2 text-xs text-slate-600 dark:text-slate-300">
            {loadError || "Backend storage could not be reached."}
          </p>
          <button
            type="button"
            onClick={() => void loadAppData()}
            className="mt-4 rounded-lg bg-[#2196F3] px-4 py-2 text-xs font-semibold text-white hover:bg-blue-600"
          >
            Retry Connection
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-[#F4F9FF] text-[#172554] dark:bg-slate-950 dark:text-slate-100">
      <Sidebar
        activeNav={activeNav}
        onSelectNav={setActiveNav}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
        activeDataset={settings.active_dataset}
        recordCount={records.length}
      />

      <div className="flex min-w-0 flex-1 flex-col">
        <Header
          activeNav={activeNav}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
          onQuickAddClick={() => {
            setQuickAddPreset(250);
            setQuickAddOpen(true);
          }}
          onOpenSettings={() => setActiveNav("settings")}
          theme={settings.theme}
          onToggleTheme={() => void handleToggleTheme()}
          activeDataset={settings.active_dataset}
          onSwitchDataset={(mode) => void handleSwitchDataset(mode)}
          hydrationStatus={analytics.daily.hydration_status}
          notifications={notificationHistory}
          onTriggerTestReminder={handleTriggerTestReminder}
        />

        <main className="mx-auto w-full max-w-[1360px] flex-1 p-4 sm:p-6">
          {activeNav === "dashboard" && (
            <DashboardPage
              analytics={analytics}
              settings={settings}
              records={records}
              onQuickAddAmount={(amount) => {
                setQuickAddPreset(amount);
                setQuickAddOpen(true);
              }}
              onNavigate={setActiveNav}
              onSwitchDataset={(mode) => void handleSwitchDataset(mode)}
              onEditRecord={setEditingRecord}
              onDeleteRecord={handleDeleteRequest}
            />
          )}

          {activeNav === "log" && (
            <LogIntakePage
              records={records}
              settings={settings}
              onAddRecord={handleAddRecord}
              onEditRecord={setEditingRecord}
              onDeleteRecord={handleDeleteRequest}
            />
          )}

          {activeNav === "history" && (
            <HistoryPage
              records={records}
              settings={settings}
              onEditRecord={setEditingRecord}
              onDeleteRecord={handleDeleteRequest}
              onNavigate={setActiveNav}
            />
          )}

          {activeNav === "analytics" && (
            <AnalyticsPage
              analytics={analytics}
              settings={settings}
              chartEngine={chartEngine}
              onNotify={notifyHelper}
            />
          )}

          {activeNav === "reports" && (
            <ReportsPage
              settings={settings}
              analytics={analytics}
              chartEngine={chartEngine}
              onNotify={notifyHelper}
            />
          )}

          {activeNav === "import" && (
            <ImportPage
              settings={settings}
              onImportCommitted={async (nextAnalytics) => {
                setAnalytics(nextAnalytics);
                await refreshRecords(settings.active_dataset);
              }}
              onNotify={notifyHelper}
            />
          )}

          {activeNav === "settings" && (
            <SettingsPage
              settings={settings}
              onSaveSettings={handleSaveSettings}
              onRequestResetDemo={handleRequestResetDemo}
              onRequestClearPersonal={handleRequestClearPersonal}
              onTriggerTestReminder={handleTriggerTestReminder}
              onNotify={notifyHelper}
            />
          )}

          {activeNav === "help" && <HelpAboutPage />}
        </main>
      </div>

      <QuickAddModal
        open={quickAddOpen}
        initialAmount={quickAddPreset}
        onClose={() => setQuickAddOpen(false)}
        onConfirm={handleAddRecord}
      />

      <EditRecordModal
        record={editingRecord}
        onClose={() => setEditingRecord(null)}
        onSave={handleUpdateRecord}
      />

      <ConfirmModal
        open={confirmState.open}
        title={confirmState.title}
        description={confirmState.description}
        confirmLabel={confirmState.confirmLabel}
        destructive={confirmState.destructive}
        onCancel={() => setConfirmState((prev) => ({ ...prev, open: false }))}
        onConfirm={async () => {
          try {
            await confirmState.onConfirm();
          } finally {
            setConfirmState((prev) => ({ ...prev, open: false }));
          }
        }}
      />

      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
