"""CRUD, search/filtering, sorting, and bulk CSV import service."""

import csv
from io import StringIO
import math
from typing import Any, Dict, List, Optional, Tuple

from backend.models.water_record import AppSettings, VALID_CATEGORIES, ValidationIssue, WaterRecord
from backend.services.storage_service import StorageService
from backend.utils.validators import (
    check_unusual_intake,
    validate_amount,
    validate_category,
    validate_date,
    validate_notes,
    validate_record_payload,
    validate_time,
)


REQUIRED_CSV_COLUMNS = {"Date", "Time", "Amount_ml", "Category"}


class RecordService:
    """High-level record management, filtering, and bulk CSV import operations."""

    def __init__(self, storage: StorageService):
        self.storage = storage

    def _enrich_record(self, record: WaterRecord, settings: AppSettings) -> Dict[str, Any]:
        data = record.to_dict()
        warning = check_unusual_intake(float(record.amount_ml), settings)
        data["unusual_warning"] = warning
        return data

    def list_records(
        self,
        dataset: Optional[str] = None,
        search: str = "",
        category: str = "",
        date_exact: str = "",
        start_date: str = "",
        end_date: str = "",
        sort_by: str = "date_desc",
        page: int = 1,
        page_size: int = 0,
    ) -> Dict[str, Any]:
        settings = self.storage.load_settings()
        target_ds = dataset or settings.active_dataset
        records = self.storage.load_records(target_ds)

        filtered = self.filter_records(
            records=records,
            search=search,
            category=category,
            date_exact=date_exact,
            start_date=start_date,
            end_date=end_date,
            sort_by=sort_by,
        )

        total_count = len(filtered)
        if page_size and page_size > 0:
            total_pages = max(1, math.ceil(total_count / page_size))
            safe_page = max(1, min(page, total_pages))
            start_idx = (safe_page - 1) * page_size
            paged = filtered[start_idx : start_idx + page_size]
        else:
            total_pages = 1
            safe_page = 1
            paged = filtered

        return {
            "records": [self._enrich_record(r, settings) for r in paged],
            "total": total_count,
            "page": safe_page,
            "page_size": page_size or total_count,
            "total_pages": total_pages,
            "dataset": target_ds,
            "recovery_notice": self.storage.last_recovery_notice,
        }

    def filter_records(
        self,
        records: List[WaterRecord],
        search: str = "",
        category: str = "",
        date_exact: str = "",
        start_date: str = "",
        end_date: str = "",
        sort_by: str = "date_desc",
    ) -> List[WaterRecord]:
        result = list(records)

        if search and search.strip():
            q = search.strip().lower()
            result = [
                r
                for r in result
                if q in str(r.id).lower()
                or q in r.date.lower()
                or q in r.time.lower()
                or q in str(r.amount_ml).lower()
                or q in r.category.lower()
                or q in (r.notes or "").lower()
            ]

        if category and category.strip() and category.strip().lower() != "all":
            cat_lower = category.strip().lower()
            result = [r for r in result if r.category.lower() == cat_lower]

        if date_exact and date_exact.strip():
            d_exact = date_exact.strip()
            result = [r for r in result if r.date == d_exact]
        else:
            if start_date and start_date.strip():
                s_date = start_date.strip()
                result = [r for r in result if r.date >= s_date]
            if end_date and end_date.strip():
                e_date = end_date.strip()
                result = [r for r in result if r.date <= e_date]

        if sort_by == "date_asc":
            result.sort(key=lambda r: (r.date, r.time, r.id))
        elif sort_by == "amount_desc":
            result.sort(key=lambda r: (float(r.amount_ml), r.date, r.time), reverse=True)
        elif sort_by == "amount_asc":
            result.sort(key=lambda r: (float(r.amount_ml), r.date, r.time))
        else:  # date_desc default
            result.sort(key=lambda r: (r.date, r.time, r.id), reverse=True)

        return result

    def add_record(self, payload: Dict[str, Any], dataset: Optional[str] = None) -> Dict[str, Any]:
        settings = self.storage.load_settings()
        target_ds = dataset or settings.active_dataset
        validated = validate_record_payload(payload)

        records = self.storage.load_records(target_ds)
        next_id = max((r.id for r in records), default=0) + 1
        new_rec = WaterRecord(id=next_id, **validated)
        records.append(new_rec)
        self.storage.save_records(records, target_ds)

        warning = check_unusual_intake(float(new_rec.amount_ml), settings)
        today_total = sum(float(r.amount_ml) for r in records if r.date == new_rec.date)
        previous_total = today_total - float(new_rec.amount_ml)
        target_just_reached = previous_total < settings.daily_target_ml <= today_total

        return {
            "record": self._enrich_record(new_rec, settings),
            "warning": warning,
            "target_just_reached": target_just_reached,
            "date_total_ml": round(today_total, 2),
        }

    def update_record(self, record_id: int, payload: Dict[str, Any], dataset: Optional[str] = None) -> Dict[str, Any]:
        settings = self.storage.load_settings()
        target_ds = dataset or settings.active_dataset
        records = self.storage.load_records(target_ds)

        index = next((i for i, r in enumerate(records) if r.id == record_id), None)
        if index is None:
            raise ValidationIssue(f"Water intake record #{record_id} was not found.", code="NOT_FOUND")

        validated = validate_record_payload(payload)
        updated = WaterRecord(id=record_id, **validated)
        records[index] = updated
        self.storage.save_records(records, target_ds)

        return {
            "record": self._enrich_record(updated, settings),
            "warning": check_unusual_intake(float(updated.amount_ml), settings),
        }

    def delete_record(self, record_id: int, dataset: Optional[str] = None) -> Dict[str, Any]:
        settings = self.storage.load_settings()
        target_ds = dataset or settings.active_dataset
        records = self.storage.load_records(target_ds)

        remaining = [r for r in records if r.id != record_id]
        if len(remaining) == len(records):
            raise ValidationIssue(f"Water intake record #{record_id} was not found.", code="NOT_FOUND")

        self.storage.save_records(remaining, target_ds)
        return {"deleted_id": record_id, "remaining_count": len(remaining)}

    def preview_csv_import(self, csv_text: str, dataset: Optional[str] = None) -> Dict[str, Any]:
        """Parse and validate an uploaded CSV string row-by-row without mutating storage."""
        if not csv_text or not csv_text.strip():
            raise ValidationIssue("The uploaded CSV file is empty.", code="EMPTY_CSV")

        settings = self.storage.load_settings()
        target_ds = dataset or settings.active_dataset
        existing_records = self.storage.load_records(target_ds)

        existing_signatures = {
            (r.date, r.time, float(r.amount_ml), r.category.lower()) for r in existing_records
        }

        try:
            reader = csv.DictReader(StringIO(csv_text.lstrip("\ufeff")))
        except csv.Error as exc:
            raise ValidationIssue("Unable to parse CSV format. Please verify comma delimiters and encoding.", code="MALFORMED_CSV") from exc

        if not reader.fieldnames:
            raise ValidationIssue("CSV file is missing a header row.", code="MISSING_HEADERS")

        # Normalize header names flexibly (strip whitespace)
        normalized_headers = [h.strip() for h in reader.fieldnames if h is not None]
        header_map = {h.lower(): h for h in normalized_headers}

        missing_cols = [col for col in sorted(REQUIRED_CSV_COLUMNS) if col.lower() not in header_map]
        if missing_cols:
            raise ValidationIssue(
                f"CSV is missing required column(s): {', '.join(missing_cols)}. "
                f"Expected headers: ID, Date, Time, Amount_ml, Category, Notes.",
                code="MISSING_COLUMNS",
            )

        valid_rows: List[Dict[str, Any]] = []
        invalid_rows: List[Dict[str, Any]] = []
        seen_in_file = set()
        total_rows = 0

        for row_num, raw_row in enumerate(reader, start=2):
            total_rows += 1
            # Clean keys
            row = {(k.strip().lower() if k else ""): (v.strip() if isinstance(v, str) else "") for k, v in raw_row.items()}

            if None in raw_row and raw_row[None]:
                invalid_rows.append({
                    "row_number": row_num,
                    "raw": row,
                    "errors": ["Row contains extra unmapped columns compared to header."],
                })
                continue

            row_errors: List[str] = []

            raw_date = row.get("date", "")
            raw_time = row.get("time", "")
            raw_amount = row.get("amount_ml", "")
            raw_category = row.get("category", "")
            raw_notes = row.get("notes", "")

            parsed_date = None
            parsed_time = None
            parsed_amount = None
            parsed_category = None
            parsed_notes = ""

            try:
                parsed_date = validate_date(raw_date)
            except ValidationIssue as err:
                row_errors.append(err.message)

            try:
                parsed_time = validate_time(raw_time)
            except ValidationIssue as err:
                row_errors.append(err.message)

            try:
                parsed_amount = validate_amount(raw_amount)
            except ValidationIssue as err:
                row_errors.append(err.message)

            try:
                parsed_category = validate_category(raw_category)
            except ValidationIssue as err:
                row_errors.append(err.message)

            try:
                parsed_notes = validate_notes(raw_notes)
            except ValidationIssue as err:
                row_errors.append(err.message)

            if not row_errors and parsed_date and parsed_time and parsed_amount is not None and parsed_category:
                sig = (parsed_date, parsed_time, float(parsed_amount), parsed_category.lower())
                if sig in existing_signatures:
                    row_errors.append("Duplicate of an existing stored water intake record.")
                elif sig in seen_in_file:
                    row_errors.append("Duplicate row found within the uploaded CSV file.")
                else:
                    seen_in_file.add(sig)

            if row_errors:
                invalid_rows.append({
                    "row_number": row_num,
                    "raw": {
                        "id": row.get("id", ""),
                        "date": raw_date,
                        "time": raw_time,
                        "amount_ml": raw_amount,
                        "category": raw_category,
                        "notes": raw_notes,
                    },
                    "errors": row_errors,
                })
            else:
                clean_amount = int(parsed_amount) if float(parsed_amount).is_integer() else parsed_amount
                valid_rows.append({
                    "row_number": row_num,
                    "date": parsed_date,
                    "time": parsed_time,
                    "amount_ml": clean_amount,
                    "category": parsed_category,
                    "notes": parsed_notes,
                    "unusual_warning": check_unusual_intake(float(clean_amount), settings),
                })

        if total_rows == 0:
            raise ValidationIssue("CSV contains headers only and no data rows.", code="NO_DATA_ROWS")

        return {
            "total_rows": total_rows,
            "valid_count": len(valid_rows),
            "invalid_count": len(invalid_rows),
            "valid_rows": valid_rows,
            "invalid_rows": invalid_rows,
            "dataset": target_ds,
        }

    def commit_csv_import(self, csv_text: str, dataset: Optional[str] = None) -> Dict[str, Any]:
        """Validate CSV and append all valid rows to JSON & CSV storage."""
        preview = self.preview_csv_import(csv_text, dataset=dataset)
        settings = self.storage.load_settings()
        target_ds = dataset or settings.active_dataset
        records = self.storage.load_records(target_ds)

        next_id = max((r.id for r in records), default=0) + 1
        imported_records: List[WaterRecord] = []
        for item in preview["valid_rows"]:
            rec = WaterRecord(
                id=next_id,
                date=item["date"],
                time=item["time"],
                amount_ml=item["amount_ml"],
                category=item["category"],
                notes=item["notes"],
            )
            records.append(rec)
            imported_records.append(rec)
            next_id += 1

        if imported_records:
            self.storage.save_records(records, target_ds)

        return {
            "imported_count": len(imported_records),
            "rejected_count": preview["invalid_count"],
            "total_rows": preview["total_rows"],
            "invalid_rows": preview["invalid_rows"],
            "dataset": target_ds,
        }
