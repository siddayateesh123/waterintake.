import express from "express";
import type { Request, Response } from "express";
import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT || 3000);
const ENGINE_PATH = path.join(__dirname, "backend", "engine.py");

interface PythonEngineResult {
  ok: boolean;
  error?: string;
  field?: string | null;
  code?: string;
  [key: string]: unknown;
}

function callPythonEngine(action: string, payload: Record<string, unknown> = {}): Promise<PythonEngineResult> {
  return new Promise((resolve, reject) => {
    const py = spawn("python3", [ENGINE_PATH], { cwd: __dirname });
    let stdout = "";
    let stderr = "";

    py.stdout.on("data", (chunk: Buffer) => {
      stdout += chunk.toString("utf-8");
    });

    py.stderr.on("data", (chunk: Buffer) => {
      stderr += chunk.toString("utf-8");
    });

    py.on("error", (err) => {
      reject(new Error(`Unable to start Python backend engine: ${err.message}`));
    });

    py.on("close", (code) => {
      try {
        const parsed = JSON.parse(stdout.trim() || "{}") as PythonEngineResult;
        if (typeof parsed.ok === "boolean") {
          resolve(parsed);
          return;
        }
        resolve({
          ok: false,
          error: "Invalid response from Python engine.",
          code: "ENGINE_RESPONSE_ERROR",
        });
      } catch {
        console.error("Python engine error:", code, stderr);
        resolve({
          ok: false,
          error: "A backend processing error occurred. Please check your input and try again.",
          code: "ENGINE_PARSE_ERROR",
        });
      }
    });

    py.stdin.write(JSON.stringify({ action, payload }));
    py.stdin.end();
  });
}

function mapStatus(result: PythonEngineResult, successCode = 200): number {
  if (result.ok) return successCode;
  if (result.code === "NOT_FOUND") return 404;
  if (result.code === "MATPLOTLIB_UNAVAILABLE") return 501;
  if (result.code === "INTERNAL_ERROR" || result.code === "ENGINE_PARSE_ERROR") return 500;
  return 400;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "8mb" }));

  app.get("/api/health", (_req: Request, res: Response) => {
    res.json({ ok: true, service: "Water Intake Reminder Log API" });
  });

  app.get("/api/bootstrap", async (req: Request, res: Response) => {
    const result = await callPythonEngine("bootstrap", {
      dataset: req.query.dataset,
      reference_date: req.query.reference_date,
    });
    res.status(mapStatus(result)).json(result);
  });

  app.get("/api/records", async (req: Request, res: Response) => {
    const result = await callPythonEngine("get_records", {
      dataset: req.query.dataset,
      search: req.query.search || "",
      category: req.query.category || "",
      date_exact: req.query.date || "",
      start_date: req.query.start_date || "",
      end_date: req.query.end_date || "",
      sort_by: req.query.sort_by || "date_desc",
      page: Number(req.query.page || 1),
      page_size: Number(req.query.page_size || 0),
    });
    res.status(mapStatus(result)).json(result);
  });

  app.post("/api/records", async (req: Request, res: Response) => {
    const body = (req.body || {}) as Record<string, unknown>;
    const result = await callPythonEngine("add_record", body);
    res.status(mapStatus(result, 201)).json(result);
  });

  app.put("/api/records/:id", async (req: Request, res: Response) => {
    const body = (req.body || {}) as Record<string, unknown>;
    const result = await callPythonEngine("update_record", {
      ...body,
      id: Number(req.params.id),
    });
    res.status(mapStatus(result)).json(result);
  });

  app.delete("/api/records/:id", async (req: Request, res: Response) => {
    const result = await callPythonEngine("delete_record", {
      id: Number(req.params.id),
      dataset: req.query.dataset,
      reference_date: req.query.reference_date,
    });
    res.status(mapStatus(result)).json(result);
  });

  app.get("/api/analytics", async (req: Request, res: Response) => {
    const result = await callPythonEngine("get_analytics", {
      dataset: req.query.dataset,
      reference_date: req.query.reference_date,
    });
    res.status(mapStatus(result)).json(result);
  });

  app.get("/api/settings", async (_req: Request, res: Response) => {
    const result = await callPythonEngine("get_settings", {});
    res.status(mapStatus(result)).json(result);
  });

  app.put("/api/settings", async (req: Request, res: Response) => {
    const body = (req.body || {}) as Record<string, unknown>;
    const result = await callPythonEngine("update_settings", body);
    res.status(mapStatus(result)).json(result);
  });

  app.post("/api/dataset/reset-demo", async (req: Request, res: Response) => {
    const body = (req.body || {}) as Record<string, unknown>;
    const result = await callPythonEngine("reset_demo", body);
    res.status(mapStatus(result)).json(result);
  });

  app.post("/api/dataset/clear-personal", async (req: Request, res: Response) => {
    const body = (req.body || {}) as Record<string, unknown>;
    const result = await callPythonEngine("clear_personal", body);
    res.status(mapStatus(result)).json(result);
  });

  app.post("/api/import/preview", async (req: Request, res: Response) => {
    const body = (req.body || {}) as Record<string, unknown>;
    const result = await callPythonEngine("import_preview", body);
    res.status(mapStatus(result)).json(result);
  });

  app.post("/api/import/commit", async (req: Request, res: Response) => {
    const body = (req.body || {}) as Record<string, unknown>;
    const result = await callPythonEngine("import_commit", body);
    res.status(mapStatus(result)).json(result);
  });

  app.get("/api/reports/summary", async (req: Request, res: Response) => {
    const result = await callPythonEngine("report_summary", {
      dataset: req.query.dataset,
      start_date: req.query.start_date || "",
      end_date: req.query.end_date || "",
      category: req.query.category || "",
      search: req.query.search || "",
      title: req.query.title || "Water Intake Summary Report",
      reference_date: req.query.reference_date,
    });
    res.status(mapStatus(result)).json(result);
  });

  app.get("/api/reports/export", async (req: Request, res: Response) => {
    const result = await callPythonEngine("export_report", {
      dataset: req.query.dataset,
      format: req.query.format || "csv",
      start_date: req.query.start_date || "",
      end_date: req.query.end_date || "",
      category: req.query.category || "",
      search: req.query.search || "",
      title: req.query.title || "Water Intake Summary Report",
      reference_date: req.query.reference_date,
    });
    if (!result.ok) {
      res.status(mapStatus(result)).json(result);
      return;
    }
    const filename = String(result.filename || "water_intake_report.txt");
    const mime = String(result.mime || "text/plain; charset=utf-8");
    const content = String(result.content || "");
    res.setHeader("Content-Type", mime);
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.send(content);
  });

  app.get("/api/charts/status", async (_req: Request, res: Response) => {
    const result = await callPythonEngine("chart_status", {});
    res.status(mapStatus(result)).json(result);
  });

  app.get("/api/charts/export/:chartType", async (req: Request, res: Response) => {
    const result = await callPythonEngine("generate_chart", {
      chart_type: req.params.chartType,
      dataset: req.query.dataset,
      reference_date: req.query.reference_date,
    });
    if (result.ok && typeof result.file_path === "string" && fs.existsSync(result.file_path)) {
      res.download(result.file_path, `${req.params.chartType}.png`);
      return;
    }
    res.status(mapStatus(result)).json(result);
  });

  app.get("/api/sample-file/:kind", (req: Request, res: Response) => {
    const kind = req.params.kind;
    const mapFiles: Record<string, string> = {
      csv: path.join(__dirname, "sample_data", "sample_records.csv"),
      json: path.join(__dirname, "sample_data", "sample_records.json"),
      mixed_csv: path.join(__dirname, "sample_data", "sample_import_mixed_test.csv"),
    };
    const filePath = mapFiles[kind];
    if (!filePath || !fs.existsSync(filePath)) {
      res.status(404).json({ ok: false, error: "Sample file not found." });
      return;
    }
    const content = fs.readFileSync(filePath, "utf-8");
    res.json({ ok: true, filename: path.basename(filePath), content });
  });

  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(__dirname, "dist");
    app.use(express.static(distDir));
    app.get("*", (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Water Intake Reminder Log running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
