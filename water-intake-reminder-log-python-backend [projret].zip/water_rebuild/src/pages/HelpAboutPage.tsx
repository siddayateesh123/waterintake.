import { CheckCircle2, Database, Droplets, ShieldCheck, Terminal } from "lucide-react";

export function HelpAboutPage() {
  const workflowSteps = [
    "Launch application and review the welcome banner & Demo/Personal dataset toggle.",
    "Inspect Dashboard daily KPI cards, circular progress ring, and consumption timeline.",
    "Adjust a custom daily hydration target in Settings and observe recalculated metrics.",
    "Log a valid water intake entry via Quick Add or Log Water Intake.",
    "Test defensive validation by entering 0, negative, or text values to see friendly errors.",
    "Record multiple valid entries across Morning, Afternoon, Evening, or Night categories.",
    "Open History to search keywords, filter by category/date range, sort, edit, or delete.",
    "Explore Analytics to review Daily, Weekly, and Monthly statistics.",
    "Inspect all 5 interactive Recharts visualizations and filter views.",
    "Export CSV, Markdown, or Plain Text audit reports from Reports & Export.",
    "Download high-resolution PNG graphical charts from Analytics or Reports.",
    "Restart the server/backend and verify JSON & CSV persistence.",
    "Reopen Dashboard to confirm all records and settings remain intact.",
  ];

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <section className="rounded-xl border border-blue-100 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-start gap-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[#2196F3] text-white">
            <Droplets className="h-6 w-6" />
          </div>
          <div>
            <p className="text-xs font-semibold text-[#2196F3] dark:text-sky-400">
              CampusSolve Project #31 · Health &amp; Wellbeing
            </p>
            <h2 className="mt-0.5 font-display text-xl font-bold text-[#172554] dark:text-slate-50">
              Water Intake Reminder Log
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
              Water Intake Reminder Log is a user-friendly application designed to simplify daily water intake
              tracking through automated calculations, structured local storage, graphical analytics, and
              downloadable reports.
            </p>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <section className="rounded-xl border border-blue-100 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center gap-2 text-sm font-bold text-[#172554] dark:text-slate-50">
            <ShieldCheck className="h-4 w-4 text-[#14B8A6]" />
            <h3>Input Validation Rules</h3>
          </div>
          <ul className="mt-3 space-y-2 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
            <li>• Water amount must be a positive number greater than 0 ml (up to 10,000 ml per entry).</li>
            <li>• Negative numbers, zero, blank values, and alphabetic strings are blocked centrally.</li>
            <li>• Dates must follow valid calendar YYYY-MM-DD format; times must use 24-hour HH:MM.</li>
            <li>• Categories must be one of Morning, Afternoon, Evening, Night, or Other.</li>
            <li>• Configurable low/high thresholds flag unusual entries for user review without medical claims.</li>
          </ul>
        </section>

        <section className="rounded-xl border border-blue-100 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center gap-2 text-sm font-bold text-[#172554] dark:text-slate-50">
            <Database className="h-4 w-4 text-[#2196F3]" />
            <h3>Local Persistence &amp; Tech Stack</h3>
          </div>
          <ul className="mt-3 space-y-2 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
            <li>• Frontend: React 19, Tailwind CSS, Recharts, and Lucide icons.</li>
            <li>• Backend: Python 3.11 persistence, validation, and analytics engine (+ Flask &amp; Matplotlib modules).</li>
            <li>• JSON &amp; CSV Sync: Every write atomically updates both JSON and CSV files without data loss.</li>
            <li>• Fault Tolerance: Automatic backup and CSV recovery if a JSON file is corrupted.</li>
            <li>• Isolated Workspaces: Demonstration dataset never overwrites your Personal Log.</li>
          </ul>
        </section>
      </div>

      <section className="rounded-xl border border-blue-100 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center gap-2 text-sm font-bold text-[#172554] dark:text-slate-50">
          <Terminal className="h-4 w-4 text-[#2196F3]" />
          <h3>Demonstration Workflow Guide</h3>
        </div>
        <ol className="mt-4 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
          {workflowSteps.map((step, idx) => (
            <li
              key={step}
              className="flex items-start gap-2.5 rounded-lg border border-blue-50 bg-[#F4F9FF]/70 p-3 text-xs text-slate-700 dark:border-slate-800 dark:bg-slate-800/50 dark:text-slate-300"
            >
              <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#14B8A6]" />
              <span>
                <strong className="font-mono-num text-[#172554] dark:text-slate-100">
                  {String(idx + 1).padStart(2, "0")}.
                </strong>{" "}
                {step}
              </span>
            </li>
          ))}
        </ol>
      </section>
    </div>
  );
}
