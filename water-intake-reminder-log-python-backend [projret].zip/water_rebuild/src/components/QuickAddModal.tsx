import { useEffect, useState } from "react";
import { Droplets, X } from "lucide-react";
import type { CategoryType } from "../types/hydration";
import {
  getLocalDateString,
  getLocalTimeString,
  suggestCategoryForTime,
} from "../utils/formatters";

interface QuickAddModalProps {
  open: boolean;
  initialAmount: number | "";
  onClose: () => void;
  onConfirm: (payload: {
    amount_ml: string;
    date: string;
    time: string;
    category: CategoryType;
    notes: string;
  }) => Promise<void>;
}

const CATEGORIES: CategoryType[] = ["Morning", "Afternoon", "Evening", "Night", "Other"];

export function QuickAddModal({
  open,
  initialAmount,
  onClose,
  onConfirm,
}: QuickAddModalProps) {
  const [amount, setAmount] = useState(initialAmount ? String(initialAmount) : "250");
  const [category, setCategory] = useState<CategoryType>("Morning");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (open) {
      const nowTime = getLocalTimeString();
      setAmount(initialAmount ? String(initialAmount) : "250");
      setCategory(suggestCategoryForTime(nowTime));
      setNotes("");
      setError("");
    }
  }, [open, initialAmount]);

  if (!open) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      await onConfirm({
        amount_ml: amount,
        date: getLocalDateString(),
        time: getLocalTimeString(),
        category,
        notes,
      });
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to save water intake.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4 backdrop-blur-[1px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="quick-add-title"
    >
      <div className="w-full max-w-md rounded-xl border border-blue-100 bg-white p-6 shadow-xl dark:border-slate-700 dark:bg-slate-900">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-50 text-[#2196F3] dark:bg-sky-950 dark:text-sky-400">
              <Droplets className="h-5 w-5" />
            </div>
            <div>
              <h2 id="quick-add-title" className="font-display text-base font-bold text-[#172554] dark:text-slate-50">
                Confirm Water Intake
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Record entry for today ({getLocalDateString()})
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800"
            aria-label="Close modal"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {error && (
            <div className="rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs font-medium text-red-700 dark:border-red-900 dark:bg-red-950/50 dark:text-red-300">
              {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
              Water Amount (ml)
            </label>
            <input
              type="text"
              inputMode="decimal"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="e.g. 250"
              className="mt-1.5 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3.5 py-2.5 font-mono-num text-sm text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:focus:border-sky-400"
              autoFocus
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
              Category
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as CategoryType)}
              className="mt-1.5 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3.5 py-2.5 text-sm text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
              Optional Notes
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Desk refill, post-walk glass"
              maxLength={300}
              className="mt-1.5 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3.5 py-2.5 text-sm text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            />
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="rounded-lg bg-[#2196F3] px-4 py-2 text-xs font-semibold text-white hover:bg-blue-600 disabled:opacity-60"
            >
              {submitting ? "Saving..." : "Confirm & Record"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
