import { useState } from "react";
import {
  Bell,
  Menu,
  Moon,
  Plus,
  Settings,
  Sun,
} from "lucide-react";
import type {
  DatasetMode,
  NavSection,
  ThemeMode,
  ToastNotification,
} from "../types/hydration";

interface HeaderProps {
  activeNav: NavSection;
  onOpenMobileMenu: () => void;
  onQuickAddClick: () => void;
  onOpenSettings: () => void;
  theme: ThemeMode;
  onToggleTheme: () => void;
  activeDataset: DatasetMode;
  onSwitchDataset: (mode: DatasetMode) => void;
  hydrationStatus: string;
  notifications: ToastNotification[];
  onTriggerTestReminder: () => void;
}

const SECTION_TITLES: Record<NavSection, string> = {
  dashboard: "Dashboard",
  log: "Log Water Intake",
  history: "Water Intake History",
  analytics: "Hydration Analytics",
  reports: "Reports & Export",
  import: "Bulk CSV Import",
  settings: "Settings & Targets",
  help: "Help & About",
};

export function Header({
  activeNav,
  onOpenMobileMenu,
  onQuickAddClick,
  onOpenSettings,
  theme,
  onToggleTheme,
  activeDataset,
  onSwitchDataset,
  hydrationStatus,
  notifications,
  onTriggerTestReminder,
}: HeaderProps) {
  const [notifOpen, setNotifOpen] = useState(false);

  const now = new Date();
  const formattedDate = now.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
  const formattedDay = now.toLocaleDateString("en-US", { weekday: "long" });

  return (
    <header className="sticky top-0 z-30 flex h-16 shrink-0 items-center justify-between gap-4 border-b border-blue-100 bg-white/95 px-4 backdrop-blur-sm dark:border-slate-800 dark:bg-slate-900/95 sm:px-6">
      <div className="flex min-w-0 items-center gap-3">
        <button
          type="button"
          onClick={onOpenMobileMenu}
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-blue-100 text-slate-600 hover:bg-blue-50 hover:text-[#172554] dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800 lg:hidden"
          aria-label="Open navigation menu"
        >
          <Menu className="h-5 w-5" />
        </button>

        <div className="min-w-0">
          <h1 className="truncate font-display text-base font-bold text-[#172554] dark:text-slate-50 sm:text-lg">
            {SECTION_TITLES[activeNav]}
          </h1>
          <div className="hidden items-center gap-2 text-xs text-slate-500 dark:text-slate-400 sm:flex">
            <span>{formattedDay}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono-num">{formattedDate}</span>
            <span aria-hidden="true">·</span>
            <span className="font-medium text-[#14B8A6] dark:text-teal-400">{hydrationStatus}</span>
          </div>
        </div>
      </div>

      <div className="flex shrink-0 items-center gap-2 sm:gap-3">
        <div
          className="hidden items-center rounded-lg border border-blue-100 bg-[#F4F9FF] p-0.5 dark:border-slate-700 dark:bg-slate-800 md:flex"
          role="group"
          aria-label="Dataset mode"
        >
          <button
            type="button"
            onClick={() => onSwitchDataset("demo")}
            className={`rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
              activeDataset === "demo"
                ? "bg-white text-[#172554] shadow-xs dark:bg-slate-700 dark:text-white"
                : "text-slate-600 hover:text-[#172554] dark:text-slate-400 dark:hover:text-slate-100"
            }`}
          >
            Demo Data
          </button>
          <button
            type="button"
            onClick={() => onSwitchDataset("personal")}
            className={`rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
              activeDataset === "personal"
                ? "bg-white text-[#172554] shadow-xs dark:bg-slate-700 dark:text-white"
                : "text-slate-600 hover:text-[#172554] dark:text-slate-400 dark:hover:text-slate-100"
            }`}
          >
            Personal Log
          </button>
        </div>

        <button
          type="button"
          onClick={onQuickAddClick}
          className="inline-flex h-10 items-center gap-1.5 rounded-lg bg-[#2196F3] px-3.5 text-xs font-semibold text-white transition-colors duration-150 hover:bg-blue-600 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2196F3] focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-900 sm:text-sm"
        >
          <Plus className="h-4 w-4" />
          <span>Quick Add</span>
        </button>

        <div className="relative">
          <button
            type="button"
            onClick={() => setNotifOpen((prev) => !prev)}
            className="relative flex h-10 w-10 items-center justify-center rounded-lg border border-blue-100 bg-white text-slate-600 transition-colors hover:bg-blue-50 hover:text-[#172554] dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
            aria-label="Notifications and reminders"
          >
            <Bell className="h-4 w-4" />
            {notifications.length > 0 && (
              <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-[#2196F3]" />
            )}
          </button>

          {notifOpen && (
            <div className="absolute right-0 mt-2 w-80 rounded-xl border border-blue-100 bg-white p-4 shadow-lg dark:border-slate-700 dark:bg-slate-900">
              <div className="flex items-center justify-between border-b border-blue-100 pb-2.5 dark:border-slate-800">
                <h2 className="text-sm font-semibold text-[#172554] dark:text-slate-100">
                  Recent Alerts & Reminders
                </h2>
                <button
                  type="button"
                  onClick={() => {
                    onTriggerTestReminder();
                    setNotifOpen(false);
                  }}
                  className="text-xs font-medium text-[#2196F3] hover:underline whitespace-nowrap"
                >
                  Test Reminder
                </button>
              </div>
              <div className="mt-2.5 max-h-60 space-y-2 overflow-y-auto">
                {notifications.length === 0 ? (
                  <p className="py-4 text-center text-xs text-slate-500 dark:text-slate-400">
                    No alerts recorded yet during this session.
                  </p>
                ) : (
                  notifications.slice(0, 6).map((item) => (
                    <div
                      key={item.id}
                      className="rounded-lg border border-slate-100 bg-[#F4F9FF] p-2.5 dark:border-slate-800 dark:bg-slate-800/70"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-[#172554] dark:text-slate-100">
                          {item.title}
                        </span>
                        <span className="font-mono-num text-slate-400">{item.timestamp}</span>
                      </div>
                      <p className="mt-1 text-xs text-slate-600 dark:text-slate-300">
                        {item.message}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={onToggleTheme}
          className="flex h-10 w-10 items-center justify-center rounded-lg border border-blue-100 bg-white text-slate-600 transition-colors hover:bg-blue-50 hover:text-[#172554] dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
          aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
          title={theme === "dark" ? "Light Mode" : "Dark Mode"}
        >
          {theme === "dark" ? <Sun className="h-4 w-4 text-amber-400" /> : <Moon className="h-4 w-4" />}
        </button>

        <button
          type="button"
          onClick={onOpenSettings}
          className="hidden h-10 w-10 items-center justify-center rounded-lg border border-blue-100 bg-white text-slate-600 transition-colors hover:bg-blue-50 hover:text-[#172554] dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 sm:flex"
          aria-label="Open settings"
          title="Settings"
        >
          <Settings className="h-4 w-4" />
        </button>
      </div>
    </header>
  );
}
