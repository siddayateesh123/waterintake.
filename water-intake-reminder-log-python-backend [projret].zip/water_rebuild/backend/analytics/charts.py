"""Matplotlib analytical chart generator with graceful availability detection."""

from pathlib import Path
from typing import Any, Dict, Optional


try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    MATPLOTLIB_AVAILABLE = True
except ImportError:
    plt = None  # type: ignore
    MATPLOTLIB_AVAILABLE = False


CHART_TYPES = {
    "daily_bar": "Daily Water Intake — Bar Chart",
    "weekly_line": "Weekly Water Consumption — Line Chart",
    "monthly_area": "Monthly Water Consumption — Area Chart",
    "category_donut": "Water Intake Distribution — Donut Chart",
    "target_vs_actual": "Daily Target vs Actual Intake — Comparison Chart",
}


def get_chart_engine_status() -> Dict[str, Any]:
    """Report whether Matplotlib is installed in the current Python runtime."""
    return {
        "matplotlib_available": MATPLOTLIB_AVAILABLE,
        "client_png_fallback_available": True,
        "supported_charts": CHART_TYPES,
        "message": (
            "Matplotlib PNG export engine is active."
            if MATPLOTLIB_AVAILABLE
            else "Matplotlib is not installed in this Python runtime environment. "
            "Core analytics remain fully operational, and crisp PNG chart exports are "
            "automatically generated via the built-in browser high-DPI renderer."
        ),
    }


def generate_matplotlib_chart(
    chart_type: str,
    analytics: Dict[str, Any],
    output_path: Path,
) -> Dict[str, Any]:
    """Generate a high-resolution PNG chart via Matplotlib if installed."""
    if chart_type not in CHART_TYPES:
        return {
            "success": False,
            "code": "INVALID_CHART_TYPE",
            "message": f"Unsupported chart type '{chart_type}'.",
        }

    if not MATPLOTLIB_AVAILABLE or plt is None:
        return {
            "success": False,
            "code": "MATPLOTLIB_UNAVAILABLE",
            "matplotlib_available": False,
            "message": (
                "Matplotlib is unavailable in this environment. Install dependencies from "
                "backend/requirements.txt for server-side Matplotlib rendering, or use the "
                "built-in PNG exporter in the browser."
            ),
        }

    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(9, 4.8), dpi=160)
    fig.patch.set_facecolor("#FFFFFF")
    ax.set_facecolor("#F8FBFF")

    if chart_type == "daily_bar":
        timeline = analytics["daily"]["timeline"]
        labels = [item["time"] for item in timeline] or ["No Entries"]
        values = [item["amount_ml"] for item in timeline] or [0]
        ax.bar(labels, values, color="#2196F3", width=0.55)
        ax.set_title("Today's Water Intake Entries (ml)", fontsize=13, fontweight="bold", color="#172554")
        ax.set_ylabel("Amount (ml)", color="#475569")
        ax.grid(axis="y", linestyle="--", alpha=0.4)

    elif chart_type == "weekly_line":
        series = analytics["weekly"]["series"]
        labels = [item["label"] for item in series]
        values = [item["total_ml"] for item in series]
        target = analytics["daily"]["target_ml"]
        ax.plot(labels, values, marker="o", linewidth=2.5, color="#2196F3", label="Actual Intake")
        ax.axhline(target, color="#14B8A6", linestyle="--", linewidth=1.6, label=f"Target ({target} ml)")
        ax.set_title("Weekly Water Consumption (Last 7 Days)", fontsize=13, fontweight="bold", color="#172554")
        ax.set_ylabel("Total (ml)", color="#475569")
        ax.legend()
        ax.grid(True, linestyle="--", alpha=0.35)

    elif chart_type == "monthly_area":
        series = analytics["monthly"]["series"]
        labels = [item["label"] for item in series]
        values = [item["total_ml"] for item in series]
        x = list(range(len(labels)))
        ax.fill_between(x, values, color="#38BDF8", alpha=0.3)
        ax.plot(x, values, color="#2196F3", linewidth=2)
        step = max(1, len(labels) // 6)
        ax.set_xticks(x[::step])
        ax.set_xticklabels(labels[::step], rotation=20, ha="right")
        ax.set_title("30-Day Monthly Hydration Trend", fontsize=13, fontweight="bold", color="#172554")
        ax.set_ylabel("Daily Total (ml)", color="#475569")
        ax.grid(axis="y", linestyle="--", alpha=0.35)

    elif chart_type == "category_donut":
        dist = [c for c in analytics["category_distribution"] if c["total_ml"] > 0]
        if not dist:
            dist = [{"category": "No Data", "total_ml": 1}]
        labels = [d["category"] for d in dist]
        values = [d["total_ml"] for d in dist]
        colors = ["#2196F3", "#38BDF8", "#14B8A6", "#172554", "#94A3B8"][: len(labels)]
        ax.pie(values, labels=labels, colors=colors, autopct="%1.1f%%", wedgeprops={"width": 0.42})
        ax.set_title("Water Intake Distribution by Time Category", fontsize=13, fontweight="bold", color="#172554")

    elif chart_type == "target_vs_actual":
        series = analytics["weekly"]["series"]
        labels = [item["label"] for item in series]
        actual = [item["total_ml"] for item in series]
        target = [item["target_ml"] for item in series]
        x = list(range(len(labels)))
        width = 0.36
        ax.bar([i - width / 2 for i in x], actual, width=width, color="#2196F3", label="Actual (ml)")
        ax.bar([i + width / 2 for i in x], target, width=width, color="#14B8A6", alpha=0.75, label="Target (ml)")
        ax.set_xticks(x)
        ax.set_xticklabels(labels)
        ax.set_title("Daily Target vs Actual Intake", fontsize=13, fontweight="bold", color="#172554")
        ax.set_ylabel("Volume (ml)", color="#475569")
        ax.legend()
        ax.grid(axis="y", linestyle="--", alpha=0.35)

    plt.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)

    return {
        "success": True,
        "matplotlib_available": True,
        "chart_type": chart_type,
        "file_path": str(output_path),
    }
