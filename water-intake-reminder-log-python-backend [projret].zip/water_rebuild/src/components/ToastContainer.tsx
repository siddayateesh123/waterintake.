import { AlertTriangle, BellRing, CheckCircle2, Info, X, XCircle } from "lucide-react";
import type { ToastNotification } from "../types/hydration";

interface ToastContainerProps {
  toasts: ToastNotification[];
  onDismiss: (id: string) => void;
}

export function ToastContainer({ toasts, onDismiss }: ToastContainerProps) {
  if (toasts.length === 0) return null;

  return (
    <div
      className="fixed bottom-4 right-4 z-50 flex w-full max-w-sm flex-col gap-2.5 px-4 sm:px-0"
      aria-live="polite"
    >
      {toasts.map((toast) => {
        const styleMap = {
          success: {
            border: "border-teal-200 dark:border-teal-800",
            icon: <CheckCircle2 className="h-4 w-4 shrink-0 text-[#14B8A6]" />,
          },
          warning: {
            border: "border-amber-200 dark:border-amber-800",
            icon: <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />,
          },
          error: {
            border: "border-red-200 dark:border-red-800",
            icon: <XCircle className="h-4 w-4 shrink-0 text-red-600 dark:text-red-400" />,
          },
          reminder: {
            border: "border-blue-200 dark:border-sky-800",
            icon: <BellRing className="h-4 w-4 shrink-0 text-[#2196F3] dark:text-sky-400" />,
          },
          info: {
            border: "border-blue-200 dark:border-slate-700",
            icon: <Info className="h-4 w-4 shrink-0 text-[#2196F3] dark:text-sky-400" />,
          },
        }[toast.type];

        return (
          <div
            key={toast.id}
            className={`flex items-start gap-3 rounded-xl border bg-white p-3.5 shadow-lg transition-all duration-150 dark:bg-slate-900 ${styleMap.border}`}
            role="status"
          >
            <div className="mt-0.5">{styleMap.icon}</div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold text-[#172554] dark:text-slate-100">
                {toast.title}
              </p>
              <p className="mt-0.5 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
                {toast.message}
              </p>
            </div>
            <button
              type="button"
              onClick={() => onDismiss(toast.id)}
              className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200"
              aria-label="Dismiss notification"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
}
