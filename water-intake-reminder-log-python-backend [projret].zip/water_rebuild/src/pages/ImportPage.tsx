import { useState } from "react";
import { AlertTriangle, CheckCircle2, Download, FileUp, Upload, XCircle } from "lucide-react";
import { commitCsvImport, fetchSampleFile, previewCsvImport } from "../services/api";
import type { AnalyticsData, AppSettings, ImportPreviewResult } from "../types/hydration";

interface ImportPageProps {
  settings: AppSettings;
  onImportCommitted: (analytics: AnalyticsData, importedCount: number) => Promise<void>;
  onNotify: (type: "success" | "warning" | "error", title: string, message: string) => void;
}

export function ImportPage({
  settings,
  onImportCommitted,
  onNotify,
}: ImportPageProps) {
  const [filename, setFilename] = useState("");
  const [csvText, setCsvText] = useState("");
  const [preview, setPreview] = useState<ImportPreviewResult | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [committing, setCommitting] = useState(false);
  const [importSummary, setImportSummary] = useState<{ imported: number; rejected: number } | null>(null);

  const runPreview = async (rawText: string, name: string) => {
    setFilename(name);
    setCsvText(rawText);
    setError("");
    setImportSummary(null);
    setPreview(null);
    setLoading(true);
    try {
      const res = await previewCsvImport(rawText, settings.active_dataset);
      setPreview(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to parse CSV file.");
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.name.toLowerCase().endsWith(".csv")) {
      setError("Unsupported file format. Please select a valid .csv file.");
      return;
    }
    const text = await file.text();
    await runPreview(text, file.name);
    e.target.value = "";
  };

  const handleLoadSample = async (kind: "csv" | "mixed_csv") => {
    try {
      const res = await fetchSampleFile(kind);
      await runPreview(res.content, res.filename);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to load sample CSV.");
    }
  };

  const handleCommit = async () => {
    if (!csvText || !preview || preview.valid_count === 0) return;
    setCommitting(true);
    setError("");
    try {
      const res = await commitCsvImport(csvText, settings.active_dataset);
      setImportSummary({ imported: res.imported_count, rejected: res.rejected_count });
      await onImportCommitted(res.analytics, res.imported_count);
      setPreview(null);
      onNotify(
        res.rejected_count > 0 ? "warning" : "success",
        "CSV Import Complete",
        `Imported ${res.imported_count} valid rows (${res.rejected_count} invalid rows skipped).`
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to commit imported records.");
    } finally {
      setCommitting(false);
    }
  };

  const handleDownloadErrors = () => {
    if (!preview || preview.invalid_rows.length === 0) return;
    const lines = [
      "WATER INTAKE CSV IMPORT ERROR REPORT",
      `File: ${filename}`,
      `Total Rows: ${preview.total_rows} | Valid: ${preview.valid_count} | Rejected: ${preview.invalid_count}`,
      "-".repeat(64),
      ...preview.invalid_rows.map(
        (r) => `Row ${r.row_number} [${JSON.stringify(r.raw)}]: ${r.errors.join(" | ")}`
      ),
    ];
    const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "csv_import_error_report.txt";
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <section className="rounded-xl border border-blue-100 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <h2 className="font-display text-lg font-bold text-[#172554] dark:text-slate-50">
              Bulk CSV Data Import
            </h2>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              Upload a CSV dataset with columns{" "}
              <span className="font-mono-num font-semibold">ID, Date, Time, Amount_ml, Category, Notes</span>.
              Every row is validated and previewed before saving.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => handleLoadSample("mixed_csv")}
              className="rounded-lg border border-blue-200 bg-[#F4F9FF] px-3 py-2 text-xs font-semibold text-[#172554] hover:bg-blue-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
            >
              Load Mixed Validation Test CSV
            </button>
          </div>
        </div>

        <label className="mt-5 flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-blue-200 bg-[#F4F9FF]/70 px-6 py-10 text-center transition-colors hover:border-[#2196F3] hover:bg-blue-50/50 dark:border-slate-700 dark:bg-slate-800/40 dark:hover:border-sky-400">
          <Upload className="h-8 w-8 text-[#2196F3] dark:text-sky-400" />
          <span className="mt-2.5 text-sm font-semibold text-[#172554] dark:text-slate-100">
            Click to select a .csv file to validate and preview
          </span>
          <span className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Malformed files, missing columns, invalid dates/numbers, and duplicates are safely detected
          </span>
          <input type="file" accept=".csv,text/csv" onChange={handleFileChange} className="sr-only" />
        </label>

        {loading && (
          <p className="mt-4 text-xs font-medium text-[#2196F3]">Validating CSV rows...</p>
        )}

        {error && (
          <div
            role="alert"
            className="mt-4 flex items-start gap-2.5 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-xs font-medium text-red-700 dark:border-red-900 dark:bg-red-950/50 dark:text-red-300"
          >
            <XCircle className="mt-0.5 h-4 w-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {importSummary && (
          <div className="mt-4 flex items-start gap-2.5 rounded-lg border border-teal-200 bg-teal-50 px-4 py-3 text-xs font-medium text-teal-800 dark:border-teal-900 dark:bg-teal-950/40 dark:text-teal-300">
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
            <span>
              Import saved to {settings.active_dataset} log: {importSummary.imported} valid entries added,{" "}
              {importSummary.rejected} invalid entries rejected.
            </span>
          </div>
        )}
      </section>

      {preview && (
        <section className="space-y-5 rounded-xl border border-blue-100 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-col justify-between gap-4 border-b border-blue-100 pb-4 dark:border-slate-800 sm:flex-row sm:items-center">
            <div>
              <h3 className="font-display text-base font-bold text-[#172554] dark:text-slate-50">
                Import Preview: {filename}
              </h3>
              <div className="mt-1 flex flex-wrap items-center gap-3 text-xs">
                <span className="font-mono-num text-slate-600 dark:text-slate-300">
                  Total Rows: {preview.total_rows}
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-mono-num font-semibold text-[#14B8A6]">
                  Valid: {preview.valid_count}
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-mono-num font-semibold text-red-600 dark:text-red-400">
                  Rejected: {preview.invalid_count}
                </span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              {preview.invalid_count > 0 && (
                <button
                  type="button"
                  onClick={handleDownloadErrors}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-amber-200 bg-amber-50 px-3.5 py-2 text-xs font-semibold text-amber-800 hover:bg-amber-100 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-300"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Error Report (.txt)</span>
                </button>
              )}
              <button
                type="button"
                disabled={preview.valid_count === 0 || committing}
                onClick={handleCommit}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#2196F3] px-4 py-2 text-xs font-semibold text-white hover:bg-blue-600 disabled:opacity-50"
              >
                <FileUp className="h-3.5 w-3.5" />
                <span>
                  {committing ? "Importing..." : `Import ${preview.valid_count} Valid Rows`}
                </span>
              </button>
            </div>
          </div>

          {preview.invalid_rows.length > 0 && (
            <div>
              <h4 className="flex items-center gap-1.5 text-xs font-bold text-red-600 dark:text-red-400">
                <AlertTriangle className="h-4 w-4" />
                <span>Rejected Rows ({preview.invalid_count})</span>
              </h4>
              <div className="mt-2 overflow-x-auto rounded-lg border border-red-100 dark:border-red-900/50">
                <table className="w-full min-w-[640px] text-left text-xs">
                  <thead className="bg-red-50/70 text-red-800 dark:bg-red-950/40 dark:text-red-300">
                    <tr>
                      <th className="px-3 py-2">CSV Row</th>
                      <th className="px-3 py-2">Raw Input</th>
                      <th className="px-3 py-2">Validation Errors</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-red-50 dark:divide-red-950/40">
                    {preview.invalid_rows.map((bad) => (
                      <tr key={bad.row_number}>
                        <td className="px-3 py-2 font-mono-num font-semibold text-red-700 dark:text-red-300">
                          Row {bad.row_number}
                        </td>
                        <td className="px-3 py-2 font-mono-num text-slate-600 dark:text-slate-300">
                          {bad.raw.date || "?"} · {bad.raw.time || "?"} · {bad.raw.amount_ml || "?"} ml ·{" "}
                          {bad.raw.category || "?"}
                        </td>
                        <td className="px-3 py-2 text-red-700 dark:text-red-300">
                          {bad.errors.join(" ")}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {preview.valid_rows.length > 0 && (
            <div>
              <h4 className="flex items-center gap-1.5 text-xs font-bold text-[#14B8A6]">
                <CheckCircle2 className="h-4 w-4" />
                <span>Valid Rows Ready to Import ({preview.valid_count})</span>
              </h4>
              <div className="mt-2 max-h-72 overflow-auto rounded-lg border border-blue-100 dark:border-slate-800">
                <table className="w-full min-w-[600px] text-left text-xs">
                  <thead className="bg-[#F4F9FF] text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                    <tr>
                      <th className="px-3 py-2">Row</th>
                      <th className="px-3 py-2">Date</th>
                      <th className="px-3 py-2">Time</th>
                      <th className="px-3 py-2 text-right">Amount (ml)</th>
                      <th className="px-3 py-2">Category</th>
                      <th className="px-3 py-2">Notes</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-blue-50 dark:divide-slate-800">
                    {preview.valid_rows.map((row) => (
                      <tr key={row.row_number}>
                        <td className="px-3 py-2 font-mono-num text-slate-500">#{row.row_number}</td>
                        <td className="px-3 py-2 font-mono-num text-[#172554] dark:text-slate-100">
                          {row.date}
                        </td>
                        <td className="px-3 py-2 font-mono-num text-slate-600 dark:text-slate-300">
                          {row.time}
                        </td>
                        <td className="px-3 py-2 text-right font-mono-num font-semibold text-[#2196F3] dark:text-sky-400">
                          {row.amount_ml} ml
                        </td>
                        <td className="px-3 py-2 text-slate-700 dark:text-slate-300">{row.category}</td>
                        <td className="px-3 py-2 text-slate-600 dark:text-slate-400">
                          {row.notes || "—"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </section>
      )}
    </div>
  );
}
