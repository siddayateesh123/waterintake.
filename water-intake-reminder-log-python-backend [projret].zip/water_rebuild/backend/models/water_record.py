"""Dataclass models for water intake records and application settings."""

from dataclasses import dataclass, asdict
from typing import Literal, Optional


VALID_CATEGORIES = ("Morning", "Afternoon", "Evening", "Night", "Other")
DatasetMode = Literal["demo", "personal"]
UnitMode = Literal["ml", "L"]
ThemeMode = Literal["light", "dark"]


class ValidationIssue(ValueError):
    """Raised when incoming record, settings, or CSV data fails validation."""

    def __init__(self, message: str, field: Optional[str] = None, code: str = "VALIDATION_ERROR"):
        super().__init__(message)
        self.message = message
        self.field = field
        self.code = code


@dataclass
class WaterRecord:
    """Represents a single hydration intake entry stored in milliliters."""

    id: int
    date: str
    time: str
    amount_ml: float
    category: str
    notes: str = ""

    def to_dict(self) -> dict:
        data = asdict(self)
        # Format clean integer when whole number for readable JSON/CSV
        if isinstance(data["amount_ml"], float) and data["amount_ml"].is_integer():
            data["amount_ml"] = int(data["amount_ml"])
        return data


@dataclass
class AppSettings:
    """User configuration and preferences persisted locally."""

    daily_target_ml: int = 2500
    preferred_unit: str = "ml"
    reminders_enabled: bool = True
    reminder_interval_min: int = 60
    browser_notifications: bool = False
    low_threshold_ml: int = 50
    high_threshold_ml: int = 1200
    theme: str = "light"
    active_dataset: str = "demo"

    def to_dict(self) -> dict:
        return asdict(self)
