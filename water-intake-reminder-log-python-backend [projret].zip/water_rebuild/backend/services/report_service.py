"""Report generation service producing CSV, Markdown, and Plain Text audit reports."""

import csv
from collections import defaultdict
from datetime import datetime
from io import StringIO
from pathlib import Path
from typing import Any, Dict, List, Optional

from backend.analytics.calculator import compute_analytics
from backend.models.water_record import AppSettings, WaterRecord
from backend.services.record_service import RecordService
from backend.services.storage_service import BASE_DIR, StorageService


REPORTS_DIR = BASE_DIR / "reports"


class ReportService:
    """Generates summary metrics and downloadable CSV, Markdown, and TXT reports."""

    def __init__(self, storage: StorageService, record_service: RecordService):
        self.storage = storage
        self.record_service = record_service
        REPORTS_DIR.mkdir(parents=True, exist_ok=True)

    def build_report_summary(
        self,
        dataset: Optional[str] = None,
        start_date: str = "",
        end_date: str = "",
        category: str = "",
        search: str = "",
        title: str = "Water Intake Summary Report",
        reference_date: Optional[str] = None,
    ) -> Dict[str, Any]:
        settings = self.storage.load_settings()
        target_ds = dataset or settings.active_dataset
        all_records = self.storage.load_records(target_ds)
        filtered = self.record_service.filter_records(
            records=all_records,
            search=search,
            category=category,
            start_date=start_date,
            end_date=end_date,
            sort_by="date_desc",
        )

        daily_totals: Dict[str, float] = defaultdict(float)
        for rec in filtered:
            daily_totals[rec.date] += float(rec.amount_ml)

        total_ml = sum(float(r.amount_ml) for r in filtered)
        day_count = len(daily_totals)
        avg_daily_ml = (total_ml / day_count) if day_count > 0 else 0.0
        target_ml = settings.daily_target_ml
        completion_pct = round((avg_daily_ml / target_ml) * 100.0, 1) if (target_ml > 0 and day_count > 0) else 0.0

        if daily_totals:
            high_d, high_v = max(daily_totals.items(), key=lambda kv: kv[1])
            low_d, low_v = min(daily_totals.items(), key=lambda kv: kv[1])
        else:
            high_d, high_v = "-", 0.0
            low_d, low_v = "-", 0.0

        analytics = compute_analytics(filtered if filtered else all_records, settings, reference_date=reference_date)

        effective_start = start_date or (min(daily_totals.keys()) if daily_totals else "N/A")
        effective_end = end_date or (max(daily_totals.keys()) if daily_totals else "N/A")

        return {
            "title": title.strip() or "Water Intake Summary Report",
            "dataset": target_ds,
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "date_range": {"start": effective_start, "end": effective_end},
            "total_consumption_ml": round(total_ml, 1),
            "total_consumption_liters": round(total_ml / 1000.0, 2),
            "average_daily_ml": round(avg_daily_ml, 1),
            "average_daily_liters": round(avg_daily_ml / 1000.0, 2),
            "daily_target_ml": target_ml,
            "daily_target_liters": round(target_ml / 1000.0, 2),
            "target_completion_pct": completion_pct,
            "total_records": len(filtered),
            "active_days": day_count,
            "highest_intake_day": {"date": high_d, "total_ml": round(high_v, 1)},
            "lowest_intake_day": {"date": low_d, "total_ml": round(low_v, 1)},
            "daily_trends": [
                {"date": d, "total_ml": round(v, 1)} for d, v in sorted(daily_totals.items())
            ],
            "weekly_trends": analytics["monthly"]["weekly_comparison"],
            "records": [r.to_dict() for r in filtered],
        }

    def export_csv(self, records: List[Dict[str, Any]]) -> str:
        buf = StringIO()
        writer = csv.writer(buf, lineterminator="\n")
        writer.writerow(["ID", "Date", "Time", "Amount_ml", "Category", "Notes"])
        for rec in records:
            writer.writerow([
                rec["id"],
                rec["date"],
                rec["time"],
                rec["amount_ml"],
                rec["category"],
                rec.get("notes", ""),
            ])
        return buf.getvalue()

    def export_markdown(self, summary: Dict[str, Any]) -> str:
        lines = [
            f"# {summary['title']}",
            "",
            f"- **Project**: Water Intake Reminder Log (CampusSolve Project #31)",
            f"- **Dataset**: {summary['dataset'].capitalize()} Records",
            f"- **Date Range**: {summary['date_range']['start']} to {summary['date_range']['end']}",
            f"- **Generated At**: {summary['generated_at']}",
            "",
            "## Summary Statistics",
            "",
            "| Metric | Value |",
            "| --- | --- |",
            f"| Total Water Consumption | {summary['total_consumption_ml']} ml ({summary['total_consumption_liters']} L) |",
            f"| Average Daily Consumption | {summary['average_daily_ml']} ml ({summary['average_daily_liters']} L) |",
            f"| Daily Target | {summary['daily_target_ml']} ml ({summary['daily_target_liters']} L) |",
            f"| Target Completion (Avg Day) | {summary['target_completion_pct']}% |",
            f"| Total Recorded Entries | {summary['total_records']} |",
            f"| Highest Intake Day | {summary['highest_intake_day']['date']} ({summary['highest_intake_day']['total_ml']} ml) |",
            f"| Lowest Intake Day | {summary['lowest_intake_day']['date']} ({summary['lowest_intake_day']['total_ml']} ml) |",
            "",
            "## Daily Totals",
            "",
            "| Date | Total (ml) |",
            "| --- | ---: |",
        ]
        if summary["daily_trends"]:
            for day in summary["daily_trends"]:
                lines.append(f"| {day['date']} | {day['total_ml']} |")
        else:
            lines.append("| No records in range | 0 |")

        lines.extend([
            "",
            "## Water Intake Records",
            "",
            "| ID | Date | Time | Amount (ml) | Category | Notes |",
            "| ---: | --- | --- | ---: | --- | --- |",
        ])
        if summary["records"]:
            for rec in summary["records"]:
                notes_clean = str(rec.get("notes", "")).replace("|", "\\|")
                lines.append(
                    f"| {rec['id']} | {rec['date']} | {rec['time']} | {rec['amount_ml']} | {rec['category']} | {notes_clean} |"
                )
        else:
            lines.append("| - | - | - | 0 | - | No matching records |")

        return "\n".join(lines) + "\n"

    def export_txt(self, summary: Dict[str, Any]) -> str:
        sep = "=" * 72
        sub = "-" * 72
        lines = [
            sep,
            f"  {summary['title'].upper()}",
            "  Water Intake Reminder Log | CampusSolve Project #31",
            sep,
            f"Dataset        : {summary['dataset'].capitalize()}",
            f"Date Range     : {summary['date_range']['start']} to {summary['date_range']['end']}",
            f"Generated At   : {summary['generated_at']}",
            sub,
            "SUMMARY METRICS",
            f"  Total Consumption    : {summary['total_consumption_ml']} ml ({summary['total_consumption_liters']} L)",
            f"  Average Daily Intake : {summary['average_daily_ml']} ml ({summary['average_daily_liters']} L)",
            f"  Daily Target         : {summary['daily_target_ml']} ml ({summary['daily_target_liters']} L)",
            f"  Avg Target Attainment: {summary['target_completion_pct']}%",
            f"  Total Entries        : {summary['total_records']}",
            f"  Highest Intake Day   : {summary['highest_intake_day']['date']} ({summary['highest_intake_day']['total_ml']} ml)",
            f"  Lowest Intake Day    : {summary['lowest_intake_day']['date']} ({summary['lowest_intake_day']['total_ml']} ml)",
            sub,
            "AUDIT LOG ENTRIES",
            f"{'ID':<5} {'DATE':<12} {'TIME':<7} {'AMOUNT':<10} {'CATEGORY':<12} NOTES",
            sub,
        ]
        if summary["records"]:
            for rec in summary["records"]:
                lines.append(
                    f"{str(rec['id']):<5} {rec['date']:<12} {rec['time']:<7} "
                    f"{str(rec['amount_ml']) + ' ml':<10} {rec['category']:<12} {rec.get('notes', '')}"
                )
        else:
            lines.append("No water intake records match the selected criteria.")
        lines.append(sep)
        return "\n".join(lines) + "\n"
