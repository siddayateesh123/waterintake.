"""Standalone Flask REST API Blueprint sharing the core Python services."""

from pathlib import Path
from typing import Any, Dict

from flask import Blueprint, Response, jsonify, request, send_file

from backend.analytics.calculator import compute_analytics
from backend.analytics.charts import generate_matplotlib_chart, get_chart_engine_status
from backend.models.water_record import ValidationIssue
from backend.services.record_service import RecordService
from backend.services.report_service import REPORTS_DIR, ReportService
from backend.services.storage_service import StorageService
from backend.utils.validators import validate_settings_payload

api_bp = Blueprint("api", __name__, url_prefix="/api")

storage_service = StorageService()
record_service = RecordService(storage_service)
report_service = ReportService(storage_service, record_service)


def _error_response(message: str, status: int = 400, field: str = None, code: str = "ERROR"):
    return jsonify({"ok": False, "error": message, "field": field, "code": code}), status


@api_bp.errorhandler(ValidationIssue)
def handle_validation_error(err: ValidationIssue):
    status = 404 if err.code == "NOT_FOUND" else 400
    return _error_response(err.message, status=status, field=err.field, code=err.code)


@api_bp.route("/bootstrap", methods=["GET"])
def bootstrap():
    dataset = request.args.get("dataset")
    ref_date = request.args.get("reference_date")
    settings = storage_service.load_settings()
    active_ds = dataset or settings.active_dataset
    records_data = record_service.list_records(dataset=active_ds, sort_by="date_desc")
    records = storage_service.load_records(active_ds)
    analytics = compute_analytics(records, settings, reference_date=ref_date)
    return jsonify({
        "ok": True,
        "settings": settings.to_dict(),
        "records": records_data["records"],
        "total": records_data["total"],
        "analytics": analytics,
        "chart_engine": get_chart_engine_status(),
        "recovery_notice": storage_service.last_recovery_notice,
    })


@api_bp.route("/records", methods=["GET"])
def list_records():
    res = record_service.list_records(
        dataset=request.args.get("dataset"),
        search=request.args.get("search", ""),
        category=request.args.get("category", ""),
        date_exact=request.args.get("date", ""),
        start_date=request.args.get("start_date", ""),
        end_date=request.args.get("end_date", ""),
        sort_by=request.args.get("sort_by", "date_desc"),
        page=int(request.args.get("page", 1) or 1),
        page_size=int(request.args.get("page_size", 0) or 0),
    )
    return jsonify({"ok": True, **res})


@api_bp.route("/records", methods=["POST"])
def create_record():
    body: Dict[str, Any] = request.get_json(silent=True) or {}
    dataset = body.get("dataset") or request.args.get("dataset")
    ref_date = body.get("reference_date")
    res = record_service.add_record(body, dataset=dataset)
    settings = storage_service.load_settings()
    active_ds = dataset or settings.active_dataset
    analytics = compute_analytics(storage_service.load_records(active_ds), settings, reference_date=ref_date)
    return jsonify({"ok": True, **res, "analytics": analytics}), 201


@api_bp.route("/records/<int:record_id>", methods=["PUT"])
def edit_record(record_id: int):
    body: Dict[str, Any] = request.get_json(silent=True) or {}
    dataset = body.get("dataset") or request.args.get("dataset")
    ref_date = body.get("reference_date")
    res = record_service.update_record(record_id, body, dataset=dataset)
    settings = storage_service.load_settings()
    active_ds = dataset or settings.active_dataset
    analytics = compute_analytics(storage_service.load_records(active_ds), settings, reference_date=ref_date)
    return jsonify({"ok": True, **res, "analytics": analytics})


@api_bp.route("/records/<int:record_id>", methods=["DELETE"])
def remove_record(record_id: int):
    dataset = request.args.get("dataset")
    ref_date = request.args.get("reference_date")
    res = record_service.delete_record(record_id, dataset=dataset)
    settings = storage_service.load_settings()
    active_ds = dataset or settings.active_dataset
    analytics = compute_analytics(storage_service.load_records(active_ds), settings, reference_date=ref_date)
    return jsonify({"ok": True, **res, "analytics": analytics})


@api_bp.route("/analytics", methods=["GET"])
def get_analytics():
    dataset = request.args.get("dataset")
    ref_date = request.args.get("reference_date")
    settings = storage_service.load_settings()
    active_ds = dataset or settings.active_dataset
    analytics = compute_analytics(storage_service.load_records(active_ds), settings, reference_date=ref_date)
    return jsonify({"ok": True, "analytics": analytics, "chart_engine": get_chart_engine_status()})


@api_bp.route("/settings", methods=["GET", "PUT"])
def settings_endpoint():
    if request.method == "GET":
        return jsonify({"ok": True, "settings": storage_service.load_settings().to_dict()})
    body: Dict[str, Any] = request.get_json(silent=True) or {}
    current = storage_service.load_settings()
    updated = validate_settings_payload(body, current)
    storage_service.save_settings(updated)
    records = storage_service.load_records(updated.active_dataset)
    analytics = compute_analytics(records, updated, reference_date=body.get("reference_date"))
    return jsonify({"ok": True, "settings": updated.to_dict(), "analytics": analytics})


@api_bp.route("/dataset/reset-demo", methods=["POST"])
def reset_demo():
    body: Dict[str, Any] = request.get_json(silent=True) or {}
    ref_date = body.get("reference_date")
    records = storage_service.reset_demo_data(reference_date=ref_date)
    settings = storage_service.load_settings()
    analytics = compute_analytics(records, settings, reference_date=ref_date)
    return jsonify({"ok": True, "count": len(records), "records": [r.to_dict() for r in records], "analytics": analytics})


@api_bp.route("/dataset/clear-personal", methods=["POST"])
def clear_personal():
    body: Dict[str, Any] = request.get_json(silent=True) or {}
    ref_date = body.get("reference_date")
    storage_service.clear_personal_data()
    settings = storage_service.load_settings()
    analytics = compute_analytics([], settings, reference_date=ref_date)
    return jsonify({"ok": True, "count": 0, "records": [], "analytics": analytics})


@api_bp.route("/import/preview", methods=["POST"])
def import_preview():
    body: Dict[str, Any] = request.get_json(silent=True) or {}
    res = record_service.preview_csv_import(body.get("csv_text", ""), dataset=body.get("dataset"))
    return jsonify({"ok": True, **res})


@api_bp.route("/import/commit", methods=["POST"])
def import_commit():
    body: Dict[str, Any] = request.get_json(silent=True) or {}
    dataset = body.get("dataset")
    res = record_service.commit_csv_import(body.get("csv_text", ""), dataset=dataset)
    settings = storage_service.load_settings()
    active_ds = dataset or settings.active_dataset
    analytics = compute_analytics(storage_service.load_records(active_ds), settings, reference_date=body.get("reference_date"))
    return jsonify({"ok": True, **res, "analytics": analytics})


@api_bp.route("/reports/summary", methods=["GET"])
def report_summary():
    summary = report_service.build_report_summary(
        dataset=request.args.get("dataset"),
        start_date=request.args.get("start_date", ""),
        end_date=request.args.get("end_date", ""),
        category=request.args.get("category", ""),
        search=request.args.get("search", ""),
        title=request.args.get("title", "Water Intake Summary Report"),
        reference_date=request.args.get("reference_date"),
    )
    return jsonify({"ok": True, "summary": summary, "chart_engine": get_chart_engine_status()})


@api_bp.route("/reports/export", methods=["GET"])
def report_export():
    fmt = request.args.get("format", "csv").lower()
    summary = report_service.build_report_summary(
        dataset=request.args.get("dataset"),
        start_date=request.args.get("start_date", ""),
        end_date=request.args.get("end_date", ""),
        category=request.args.get("category", ""),
        search=request.args.get("search", ""),
        title=request.args.get("title", "Water Intake Summary Report"),
        reference_date=request.args.get("reference_date"),
    )
    if fmt == "csv":
        content = report_service.export_csv(summary["records"])
        return Response(content, mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=water_intake_report.csv"})
    if fmt in ("md", "markdown"):
        content = report_service.export_markdown(summary)
        return Response(content, mimetype="text/markdown", headers={"Content-Disposition": "attachment; filename=water_intake_report.md"})
    if fmt == "txt":
        content = report_service.export_txt(summary)
        return Response(content, mimetype="text/plain", headers={"Content-Disposition": "attachment; filename=water_intake_audit.txt"})
    return _error_response("Unsupported export format.", status=400)


@api_bp.route("/charts/export/<chart_type>", methods=["GET"])
def export_chart(chart_type: str):
    settings = storage_service.load_settings()
    active_ds = request.args.get("dataset") or settings.active_dataset
    analytics = compute_analytics(storage_service.load_records(active_ds), settings, reference_date=request.args.get("reference_date"))
    out_path = REPORTS_DIR / f"chart_{chart_type}.png"
    res = generate_matplotlib_chart(chart_type, analytics, out_path)
    if res.get("success"):
        return send_file(Path(res["file_path"]), mimetype="image/png", as_attachment=True, download_name=f"{chart_type}.png")
    return jsonify({"ok": False, **res}), 501
