import { useEffect, useState } from "react";
import { BellRing, CheckCircle2, Download, RefreshCw, Trash2 } from "lucide-react";
import { buildReportExportUrl } from "../services/api";
import type { AppSettings, ThemeMode, UnitMode } from "../types/hydration";

interface SettingsPageProps {
  settings: AppSettings;
  onSaveSettings: (patch: Partial<AppSettings>) => Promise<void>;
  onRequestResetDemo: () => void;
  onRequestClearPersonal: () => void;
  onTriggerTestReminder: () => void;
  onNotify: (type: "success" | "warning" | "error" | "info", title: string, message: string) => void;
}

export function SettingsPage({
  settings,
  onSaveSettings,
  onRequestResetDemo,
  onRequestClearPersonal,
  onTriggerTestReminder,
  onNotify,
}: SettingsPageProps) {
  const [targetMl, setTargetMl] = useState(String(settings.daily_target_ml));
  const [unit, setUnit] = useState<UnitMode>(settings.preferred_unit);
  const [remindersEnabled, setRemindersEnabled] = useState(settings.reminders_enabled);
  const [intervalMin, setIntervalMin] = useState(String(settings.reminder_interval_min));
  const [browserNotifs, setBrowserNotifs] = useState(settings.browser_notifications);
  const [lowThreshold, setLowThreshold] = useState(String(settings.low_threshold_ml));
  const [highThreshold, setHighThreshold] = useState(String(settings.high_threshold_ml));
  const [theme, setTheme] = useState<ThemeMode>(settings.theme);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [savedNotice, setSavedNotice] = useState("");

  useEffect(() => {
    setTargetMl(String(settings.daily_target_ml));
    setUnit(settings.preferred_unit);
    setRemindersEnabled(settings.reminders_enabled);
    setIntervalMin(String(settings.reminder_interval_min));
    setBrowserNotifs(settings.browser_notifications);
    setLowThreshold(String(settings.low_threshold_ml));
    setHighThreshold(String(settings.high_threshold_ml));
    setTheme(settings.theme);
  }, [settings]);

  const numericTarget = Number(targetMl);
  const targetLitersPreview =
    Number.isFinite(numericTarget) && numericTarget > 0 ? (numericTarget / 1000).toFixed(2) : "—";

  const handleBrowserNotifToggle = async (checked: boolean) => {
    if (checked && typeof window !== "undefined" && "Notification" in window) {
      if (Notification.permission === "default") {
        const perm = await Notification.requestPermission();
        if (perm !== "granted") {
          onNotify(
            "info",
            "Browser Notifications Not Granted",
            "In-app toast alerts will still deliver all hydration reminders."
          );
          setBrowserNotifs(false);
          return;
        }
      } else if (Notification.permission === "denied") {
        onNotify(
          "warning",
          "Notifications Blocked in Browser",
          "Enable notifications in browser site settings or rely on in-app toast reminders."
        );
        setBrowserNotifs(false);
        return;
      }
    }
    setBrowserNotifs(checked);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSavedNotice("");
    setSaving(true);
    try {
      await onSaveSettings({
        daily_target_ml: targetMl as unknown as number,
        preferred_unit: unit,
        reminders_enabled: remindersEnabled,
        reminder_interval_min: intervalMin as unknown as number,
        browser_notifications: browserNotifs,
        low_threshold_ml: lowThreshold as unknown as number,
        high_threshold_ml: highThreshold as unknown as number,
        theme,
      });
      setSavedNotice("Settings saved and dashboard metrics recalculated.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save settings.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        {error && (
          <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-xs font-medium text-red-700 dark:border-red-900 dark:bg-red-950/50 dark:text-red-300">
            {error}
          </div>
        )}

        {savedNotice && (
          <div className="flex items-center gap-2 rounded-lg border border-teal-200 bg-teal-50 px-4 py-3 text-xs font-medium text-teal-800 dark:border-teal-900 dark:bg-teal-950/40 dark:text-teal-300">
            <CheckCircle2 className="h-4 w-4 shrink-0" />
            <span>{savedNotice}</span>
          </div>
        )}

        {/* Daily Target & Units */}
        <section className="rounded-xl border border-blue-100 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="font-display text-base font-bold text-[#172554] dark:text-slate-50">
            Daily Hydration Target &amp; Units
          </h2>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Customize your daily goal in milliliters. Internal calculations always run in milliliters for consistency.
          </p>

          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Daily Target (ml)
              </label>
              <input
                type="text"
                inputMode="numeric"
                value={targetMl}
                onChange={(e) => setTargetMl(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3.5 py-2.5 font-mono-num text-sm text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
              />
              <p className="mt-1 font-mono-num text-xs text-[#2196F3] dark:text-sky-400">
                Equivalent: {targetLitersPreview} L per day
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Preferred Display Unit
              </label>
              <div className="mt-1.5 grid grid-cols-2 gap-2">
                {(["ml", "L"] as const).map((u) => (
                  <button
                    key={u}
                    type="button"
                    onClick={() => setUnit(u)}
                    className={`rounded-lg border px-3 py-2.5 text-xs font-semibold transition-colors ${
                      unit === u
                        ? "border-[#2196F3] bg-blue-50 text-[#2196F3] dark:border-sky-400 dark:bg-sky-950/60 dark:text-sky-300"
                        : "border-blue-100 bg-[#F4F9FF] text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
                    }`}
                  >
                    {u === "ml" ? "Milliliters (ml)" : "Liters (L)"}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Reminders & Warning Thresholds */}
        <section className="rounded-xl border border-blue-100 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-col justify-between gap-2 sm:flex-row sm:items-center">
            <div>
              <h2 className="font-display text-base font-bold text-[#172554] dark:text-slate-50">
                Reminders, Notifications &amp; Intake Thresholds
              </h2>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Thresholds highlight unusually low or high entries for personal review and are not medical recommendations.
              </p>
            </div>
            <button
              type="button"
              onClick={onTriggerTestReminder}
              className="inline-flex items-center gap-1.5 self-start rounded-lg border border-blue-200 px-3 py-1.5 text-xs font-semibold text-[#2196F3] hover:bg-blue-50 dark:border-slate-700 dark:text-sky-400 dark:hover:bg-slate-800"
            >
              <BellRing className="h-3.5 w-3.5" />
              <span>Test Reminder</span>
            </button>
          </div>

          <div className="mt-4 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4 rounded-lg border border-blue-100 bg-[#F4F9FF]/60 p-4 dark:border-slate-800 dark:bg-slate-800/40">
              <div>
                <p className="text-sm font-semibold text-[#172554] dark:text-slate-100">
                  Enable Scheduled Hydration Reminders
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Displays in-app toast alerts at your configured minute interval
                </p>
              </div>
              <input
                type="checkbox"
                checked={remindersEnabled}
                onChange={(e) => setRemindersEnabled(e.target.checked)}
                className="h-5 w-5 accent-[#2196F3]"
                aria-label="Enable scheduled reminders"
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-4 rounded-lg border border-blue-100 bg-[#F4F9FF]/60 p-4 dark:border-slate-800 dark:bg-slate-800/40">
              <div>
                <p className="text-sm font-semibold text-[#172554] dark:text-slate-100">
                  Browser Desktop Notifications (Optional)
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Uses browser Notification API when permission is granted; falls back cleanly to in-app toasts
                </p>
              </div>
              <input
                type="checkbox"
                checked={browserNotifs}
                onChange={(e) => void handleBrowserNotifToggle(e.target.checked)}
                className="h-5 w-5 accent-[#2196F3]"
                aria-label="Enable browser notifications"
              />
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Reminder Interval (minutes)
                </label>
                <input
                  type="text"
                  inputMode="numeric"
                  value={intervalMin}
                  onChange={(e) => setIntervalMin(e.target.value)}
                  className="mt-1.5 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3.5 py-2 font-mono-num text-sm text-[#172554] dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Low Entry Review Threshold (ml)
                </label>
                <input
                  type="text"
                  inputMode="numeric"
                  value={lowThreshold}
                  onChange={(e) => setLowThreshold(e.target.value)}
                  className="mt-1.5 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3.5 py-2 font-mono-num text-sm text-[#172554] dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  High Entry Review Threshold (ml)
                </label>
                <input
                  type="text"
                  inputMode="numeric"
                  value={highThreshold}
                  onChange={(e) => setHighThreshold(e.target.value)}
                  className="mt-1.5 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3.5 py-2 font-mono-num text-sm text-[#172554] dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Appearance & Save */}
        <section className="rounded-xl border border-blue-100 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="font-display text-base font-bold text-[#172554] dark:text-slate-50">
            Appearance Theme
          </h2>
          <div className="mt-3 grid grid-cols-2 gap-3 sm:max-w-sm">
            {(["light", "dark"] as const).map((mode) => (
              <button
                key={mode}
                type="button"
                onClick={() => setTheme(mode)}
                className={`rounded-lg border px-4 py-2.5 text-xs font-semibold capitalize transition-colors ${
                  theme === mode
                    ? "border-[#2196F3] bg-blue-50 text-[#2196F3] dark:border-sky-400 dark:bg-sky-950/60 dark:text-sky-300"
                    : "border-blue-100 bg-[#F4F9FF] text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
                }`}
              >
                {mode} Mode
              </button>
            ))}
          </div>

          <div className="mt-6 flex justify-end border-t border-blue-50 pt-4 dark:border-slate-800">
            <button
              type="submit"
              disabled={saving}
              className="rounded-lg bg-[#2196F3] px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-600 disabled:opacity-60"
            >
              {saving ? "Saving Preferences..." : "Save All Settings"}
            </button>
          </div>
        </section>
      </form>

      {/* Data Management */}
      <section className="rounded-xl border border-blue-100 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <h2 className="font-display text-base font-bold text-[#172554] dark:text-slate-50">
          Data Management &amp; Backups
        </h2>
        <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
          Export your active dataset or safely reset demonstration records. Destructive actions require confirmation.
        </p>

        <div className="mt-4 flex flex-wrap gap-3">
          <a
            href={buildReportExportUrl({ dataset: settings.active_dataset, format: "csv" })}
            className="inline-flex items-center gap-1.5 rounded-lg border border-blue-200 bg-[#F4F9FF] px-4 py-2 text-xs font-semibold text-[#172554] hover:bg-blue-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export Active CSV</span>
          </a>

          <button
            type="button"
            onClick={onRequestResetDemo}
            className="inline-flex items-center gap-1.5 rounded-lg border border-blue-200 bg-white px-4 py-2 text-xs font-semibold text-[#2196F3] hover:bg-blue-50 dark:border-slate-700 dark:bg-slate-800 dark:text-sky-400"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Reset Demonstration Data</span>
          </button>

          <button
            type="button"
            onClick={onRequestClearPersonal}
            className="inline-flex items-center gap-1.5 rounded-lg border border-red-200 bg-red-50 px-4 py-2 text-xs font-semibold text-red-700 hover:bg-red-100 dark:border-red-900 dark:bg-red-950/40 dark:text-red-300"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span>Clear Personal Log</span>
          </button>
        </div>
      </section>
    </div>
  );
}
