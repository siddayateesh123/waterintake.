import { useRef, useState } from "react";
import { Download, Info } from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { AnalyticsData, AppSettings, ChartEngineStatus } from "../types/hydration";
import { formatVolume } from "../utils/formatters";
import { exportSvgElementAsPng } from "../utils/pngExport";

interface AnalyticsPageProps {
  analytics: AnalyticsData;
  settings: AppSettings;
  chartEngine: ChartEngineStatus;
  onNotify: (type: "success" | "info" | "error", title: string, message: string) => void;
}

const PIE_COLORS = ["#2196F3", "#38BDF8", "#14B8A6", "#172554", "#94A3B8"];

export function AnalyticsPage({
  analytics,
  settings,
  chartEngine,
  onNotify,
}: AnalyticsPageProps) {
  const [periodTab, setPeriodTab] = useState<"all" | "daily" | "weekly" | "monthly">("all");

  const dailyRef = useRef<HTMLDivElement>(null);
  const weeklyRef = useRef<HTMLDivElement>(null);
  const monthlyRef = useRef<HTMLDivElement>(null);
  const pieRef = useRef<HTMLDivElement>(null);
  const compareRef = useRef<HTMLDivElement>(null);

  const { daily, weekly, monthly, category_distribution } = analytics;
  const activePieData = category_distribution.filter((item) => item.total_ml > 0);

  const handleDownloadChart = async (
    chartType: "daily_bar" | "weekly_line" | "monthly_area" | "category_donut" | "target_vs_actual",
    container: HTMLDivElement | null,
    title: string,
    subtitle: string
  ) => {
    if (chartEngine.matplotlib_available) {
      window.location.href = `/api/charts/export/${chartType}?dataset=${settings.active_dataset}`;
      onNotify("success", "Chart Exported", `Downloading Matplotlib PNG for ${title}.`);
      return;
    }

    const ok = await exportSvgElementAsPng(container, `${chartType}.png`, title, subtitle);
    if (ok) {
      onNotify("success", "PNG Chart Downloaded", `Saved ${chartType}.png cleanly.`);
    } else {
      onNotify("error", "Export Failed", "Ensure the chart has rendered data before exporting.");
    }
  };

  return (
    <div className="space-y-6">
      {/* Period Selector & Matplotlib Status */}
      <div className="flex flex-col justify-between gap-3 rounded-xl border border-blue-100 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 sm:flex-row sm:items-center">
        <div className="flex flex-wrap items-center gap-1 rounded-lg bg-[#F4F9FF] p-1 dark:bg-slate-800">
          {(
            [
              { id: "all", label: "All Analytics" },
              { id: "daily", label: "Daily" },
              { id: "weekly", label: "Weekly" },
              { id: "monthly", label: "Monthly" },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setPeriodTab(tab.id)}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                periodTab === tab.id
                  ? "bg-white text-[#2196F3] shadow-xs dark:bg-slate-700 dark:text-sky-400"
                  : "text-slate-600 hover:text-[#172554] dark:text-slate-300"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400">
          <Info className="h-4 w-4 shrink-0 text-[#2196F3] dark:text-sky-400" />
          <span>
            {chartEngine.matplotlib_available
              ? "Python Matplotlib chart renderer is active."
              : "Matplotlib is not installed in this runtime; high-DPI browser PNG export is active."}
          </span>
        </div>
      </div>

      {/* A. Daily Analytics Summary */}
      {(periodTab === "all" || periodTab === "daily") && (
        <section className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="font-display text-base font-bold text-[#172554] dark:text-slate-50">
            Daily Analytics ({daily.date})
          </h2>
          <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Total Consumed</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#172554] dark:text-slate-50">
                {formatVolume(daily.total_ml, settings.preferred_unit)}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Daily Target</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#172554] dark:text-slate-50">
                {formatVolume(daily.target_ml, settings.preferred_unit)}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Remaining</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#172554] dark:text-slate-50">
                {formatVolume(daily.remaining_ml, settings.preferred_unit)}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Completion</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#2196F3] dark:text-sky-400">
                {daily.completion_pct.toFixed(1)}%
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Recorded Entries</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#172554] dark:text-slate-50">
                {daily.entry_count}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Highest Entry</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#14B8A6]">
                {formatVolume(daily.highest_entry_ml, settings.preferred_unit)}
              </p>
            </div>
          </div>
        </section>
      )}

      {/* B. Weekly Analytics Summary */}
      {(periodTab === "all" || periodTab === "weekly") && (
        <section className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="font-display text-base font-bold text-[#172554] dark:text-slate-50">
            Weekly Analytics ({weekly.start_date} to {weekly.end_date})
          </h2>
          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Total Weekly Intake</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#172554] dark:text-slate-50">
                {formatVolume(weekly.total_ml, settings.preferred_unit)}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Daily Average</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#2196F3] dark:text-sky-400">
                {formatVolume(weekly.daily_average_ml, settings.preferred_unit)}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Highest Day</p>
              <p className="mt-1 font-mono-num text-sm font-bold text-[#172554] dark:text-slate-50">
                {weekly.highest_day.label} ({formatVolume(weekly.highest_day.total_ml, settings.preferred_unit)})
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Lowest Day</p>
              <p className="mt-1 font-mono-num text-sm font-bold text-[#172554] dark:text-slate-50">
                {weekly.lowest_day.label} ({formatVolume(weekly.lowest_day.total_ml, settings.preferred_unit)})
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Target Achieved Days</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#14B8A6]">
                {weekly.days_target_achieved} / 7 days
              </p>
            </div>
          </div>
        </section>
      )}

      {/* C. Monthly Analytics Summary */}
      {(periodTab === "all" || periodTab === "monthly") && (
        <section className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="font-display text-base font-bold text-[#172554] dark:text-slate-50">
            Monthly Analytics (30-Day Window: {monthly.start_date} to {monthly.end_date})
          </h2>
          <div className="mt-4 grid grid-cols-2 gap-4 lg:grid-cols-5">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Total Monthly Intake</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#172554] dark:text-slate-50">
                {formatVolume(monthly.total_ml, settings.preferred_unit)}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">30-Day Daily Avg</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#2196F3] dark:text-sky-400">
                {formatVolume(monthly.daily_average_ml, settings.preferred_unit)}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Monthly Target Completion</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#14B8A6]">
                {monthly.monthly_completion_pct.toFixed(1)}%
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Active Logging Days</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#172554] dark:text-slate-50">
                {monthly.active_days} / 30 days
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Target Hit Days</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#172554] dark:text-slate-50">
                {monthly.days_target_achieved} days
              </p>
            </div>
          </div>

          <div className="mt-5 grid grid-cols-1 gap-4 border-t border-blue-50 pt-4 dark:border-slate-800 md:grid-cols-2">
            <div>
              <h3 className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                Weekly Comparison (30-Day Buckets)
              </h3>
              <div className="mt-2 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
                {monthly.weekly_comparison.map((bucket) => (
                  <div
                    key={bucket.week}
                    className="rounded-lg border border-blue-100 bg-[#F4F9FF] p-2.5 dark:border-slate-700 dark:bg-slate-800/60"
                  >
                    <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                      {bucket.week}
                    </p>
                    <p className="mt-1 font-mono-num text-xs font-bold text-[#172554] dark:text-slate-100">
                      {formatVolume(bucket.total_ml, settings.preferred_unit)}
                    </p>
                    <p className="font-mono-num text-[11px] text-slate-500 dark:text-slate-400">
                      Avg {Math.round(bucket.average_ml)} ml/d
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                Day-of-Week Average Consumption Pattern
              </h3>
              <div className="mt-2 grid grid-cols-7 gap-1.5">
                {monthly.daily_patterns.map((pat) => (
                  <div
                    key={pat.day}
                    className="rounded-lg border border-blue-100 bg-[#F4F9FF] p-2 text-center dark:border-slate-700 dark:bg-slate-800/60"
                  >
                    <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                      {pat.day}
                    </p>
                    <p className="mt-1 font-mono-num text-xs font-bold text-[#172554] dark:text-slate-100">
                      {Math.round(pat.average_ml)}
                    </p>
                    <p className="text-[10px] text-slate-400">ml</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* D. 5 Graphical Visualizations */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* 1. Daily Water Intake – Bar Chart */}
        <section
          ref={dailyRef}
          className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900"
        >
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="font-display text-sm font-bold text-[#172554] dark:text-slate-50">
                1. Daily Water Intake — Bar Chart
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Individual entries recorded on {daily.date}
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                handleDownloadChart(
                  "daily_bar",
                  dailyRef.current,
                  "Daily Water Intake — Bar Chart",
                  `Entries for ${daily.date}`
                )
              }
              className="inline-flex items-center gap-1.5 rounded-lg border border-blue-200 px-3 py-1.5 text-xs font-semibold text-[#172554] hover:bg-blue-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Download className="h-3.5 w-3.5" />
              <span>PNG</span>
            </button>
          </div>

          <div className="mt-4 h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={
                  daily.timeline.length
                    ? daily.timeline.map((item) => ({ label: item.label, amount_ml: item.amount_ml }))
                    : [{ label: "No Entries", amount_ml: 0 }]
                }
                margin={{ top: 10, right: 12, left: -12, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 12, fill: "#64748B" }} />
                <YAxis tick={{ fontSize: 12, fill: "#64748B" }} />
                <Tooltip formatter={(val) => [`${Number(val ?? 0).toLocaleString()} ml`, "Intake"]} />
                <Legend />
                <Bar dataKey="amount_ml" name="Intake (ml)" fill="#2196F3" radius={[6, 6, 0, 0]} maxBarSize={44} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        {/* 2. Weekly Water Consumption – Line Chart */}
        <section
          ref={weeklyRef}
          className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900"
        >
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="font-display text-sm font-bold text-[#172554] dark:text-slate-50">
                2. Weekly Water Consumption — Line Chart
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                7-day hydration trend against daily target
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                handleDownloadChart(
                  "weekly_line",
                  weeklyRef.current,
                  "Weekly Water Consumption — Line Chart",
                  `${weekly.start_date} to ${weekly.end_date}`
                )
              }
              className="inline-flex items-center gap-1.5 rounded-lg border border-blue-200 px-3 py-1.5 text-xs font-semibold text-[#172554] hover:bg-blue-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Download className="h-3.5 w-3.5" />
              <span>PNG</span>
            </button>
          </div>

          <div className="mt-4 h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={weekly.series} margin={{ top: 10, right: 12, left: -12, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#64748B" }} />
                <YAxis tick={{ fontSize: 12, fill: "#64748B" }} />
                <Tooltip formatter={(val) => [`${Number(val ?? 0).toLocaleString()} ml`, "Daily Total"]} />
                <Legend />
                <ReferenceLine y={daily.target_ml} stroke="#14B8A6" strokeDasharray="4 4" />
                <Line
                  type="monotone"
                  dataKey="total_ml"
                  name="Actual Intake (ml)"
                  stroke="#2196F3"
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: "#2196F3" }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </section>

        {/* 3. Monthly Water Consumption – Area Chart */}
        <section
          ref={monthlyRef}
          className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900"
        >
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="font-display text-sm font-bold text-[#172554] dark:text-slate-50">
                3. Monthly Water Consumption — Area Chart
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                30-day cumulative hydration pattern
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                handleDownloadChart(
                  "monthly_area",
                  monthlyRef.current,
                  "Monthly Water Consumption — Area Chart",
                  `${monthly.start_date} to ${monthly.end_date}`
                )
              }
              className="inline-flex items-center gap-1.5 rounded-lg border border-blue-200 px-3 py-1.5 text-xs font-semibold text-[#172554] hover:bg-blue-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Download className="h-3.5 w-3.5" />
              <span>PNG</span>
            </button>
          </div>

          <div className="mt-4 h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthly.series} margin={{ top: 10, right: 12, left: -12, bottom: 0 }}>
                <defs>
                  <linearGradient id="waterAreaGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#38BDF8" stopOpacity={0.45} />
                    <stop offset="95%" stopColor="#38BDF8" stopOpacity={0.04} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#64748B" }} interval={4} />
                <YAxis tick={{ fontSize: 12, fill: "#64748B" }} />
                <Tooltip formatter={(val) => [`${Number(val ?? 0).toLocaleString()} ml`, "Daily Intake"]} />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="total_ml"
                  name="Daily Intake (ml)"
                  stroke="#2196F3"
                  strokeWidth={2}
                  fill="url(#waterAreaGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </section>

        {/* 4. Water Intake Distribution – Pie/Donut Chart */}
        <section
          ref={pieRef}
          className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900"
        >
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="font-display text-sm font-bold text-[#172554] dark:text-slate-50">
                4. Water Intake Distribution — Donut Chart
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Volume breakdown across time-of-day categories
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                handleDownloadChart(
                  "category_donut",
                  pieRef.current,
                  "Water Intake Distribution — Donut Chart",
                  "Volume share by category"
                )
              }
              className="inline-flex items-center gap-1.5 rounded-lg border border-blue-200 px-3 py-1.5 text-xs font-semibold text-[#172554] hover:bg-blue-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Download className="h-3.5 w-3.5" />
              <span>PNG</span>
            </button>
          </div>

          <div className="mt-4 h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={activePieData.length ? activePieData : [{ category: "No Data", total_ml: 1, percentage: 100 }]}
                  dataKey="total_ml"
                  nameKey="category"
                  cx="50%"
                  cy="50%"
                  innerRadius={52}
                  outerRadius={86}
                  paddingAngle={2}
                >
                  {(activePieData.length ? activePieData : [{ category: "No Data" }]).map((entry, index) => (
                    <Cell key={entry.category} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value) => [`${Number(value ?? 0).toLocaleString()} ml`, "Volume"]}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </section>
      </div>

      {/* 5. Daily Target vs Actual Intake – Comparison Chart */}
      <section
        ref={compareRef}
        className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900"
      >
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="font-display text-sm font-bold text-[#172554] dark:text-slate-50">
              5. Daily Target vs Actual Intake — Comparison Chart
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Side-by-side comparison of actual water consumed vs configured target ({daily.target_ml.toLocaleString()} ml)
            </p>
          </div>
          <button
            type="button"
            onClick={() =>
              handleDownloadChart(
                "target_vs_actual",
                compareRef.current,
                "Daily Target vs Actual Intake — Comparison Chart",
                `${weekly.start_date} to ${weekly.end_date}`
              )
            }
            className="inline-flex items-center gap-1.5 rounded-lg border border-blue-200 px-3 py-1.5 text-xs font-semibold text-[#172554] hover:bg-blue-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            <Download className="h-3.5 w-3.5" />
            <span>PNG</span>
          </button>
        </div>

        <div className="mt-4 h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={weekly.series} margin={{ top: 10, right: 16, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 12, fill: "#64748B" }} />
              <YAxis tick={{ fontSize: 12, fill: "#64748B" }} />
              <Tooltip formatter={(val) => `${Number(val ?? 0).toLocaleString()} ml`} />
              <Legend />
              <Bar dataKey="total_ml" name="Actual Intake (ml)" fill="#2196F3" radius={[6, 6, 0, 0]} maxBarSize={36} />
              <Bar dataKey="target_ml" name="Daily Target (ml)" fill="#14B8A6" radius={[6, 6, 0, 0]} maxBarSize={36} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>
    </div>
  );
}
