"""Automated test suite covering all 18 core functional, storage, analytics, and error-handling cases."""

import csv
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from backend.analytics.calculator import compute_analytics
from backend.analytics.charts import MATPLOTLIB_AVAILABLE, generate_matplotlib_chart, get_chart_engine_status
from backend.models.water_record import AppSettings, ValidationIssue
from backend.services.record_service import RecordService
from backend.services.report_service import ReportService
from backend.services.storage_service import StorageService
from backend.utils.validators import validate_settings_payload


class WaterIntakeLogTestSuite(unittest.TestCase):
    """Covers all 18 required test scenarios plus restart persistence verification."""

    def setUp(self) -> None:
        self.tmp_dir = tempfile.TemporaryDirectory()
        self.storage_dir = Path(self.tmp_dir.name) / "storage"
        self.storage = StorageService(storage_dir=self.storage_dir)
        self.records = RecordService(self.storage)
        self.reports = ReportService(self.storage, self.records)

    def tearDown(self) -> None:
        self.tmp_dir.cleanup()

    def test_01_add_valid_record(self):
        res = self.records.add_record(
            {"date": "2026-11-17", "time": "09:00", "amount_ml": 250, "category": "Morning", "notes": "Morning glass"},
            dataset="personal",
        )
        self.assertEqual(res["record"]["amount_ml"], 250)
        self.assertEqual(res["record"]["category"], "Morning")
        self.assertEqual(len(self.storage.load_records("personal")), 1)

    def test_02_reject_negative_amount(self):
        with self.assertRaises(ValidationIssue) as ctx:
            self.records.add_record(
                {"date": "2026-11-17", "time": "09:00", "amount_ml": -150, "category": "Morning"},
                dataset="personal",
            )
        self.assertEqual(ctx.exception.code, "NEGATIVE_AMOUNT")

    def test_03_reject_zero_amount(self):
        with self.assertRaises(ValidationIssue) as ctx:
            self.records.add_record(
                {"date": "2026-11-17", "time": "09:00", "amount_ml": 0, "category": "Morning"},
                dataset="personal",
            )
        self.assertEqual(ctx.exception.code, "ZERO_AMOUNT")

    def test_04_reject_blank_inputs(self):
        with self.assertRaises(ValidationIssue):
            self.records.add_record(
                {"date": "2026-11-17", "time": "09:00", "amount_ml": "", "category": "Morning"},
                dataset="personal",
            )
        with self.assertRaises(ValidationIssue):
            self.records.add_record(
                {"date": "", "time": "09:00", "amount_ml": 200, "category": "Morning"},
                dataset="personal",
            )

    def test_05_update_existing_record(self):
        added = self.records.add_record(
            {"date": "2026-11-17", "time": "09:00", "amount_ml": 250, "category": "Morning", "notes": "Initial"},
            dataset="personal",
        )
        rec_id = added["record"]["id"]
        updated = self.records.update_record(
            rec_id,
            {"date": "2026-11-17", "time": "09:30", "amount_ml": 400, "category": "Morning", "notes": "Updated"},
            dataset="personal",
        )
        self.assertEqual(updated["record"]["amount_ml"], 400)
        self.assertEqual(updated["record"]["notes"], "Updated")

    def test_06_delete_record(self):
        added = self.records.add_record(
            {"date": "2026-11-17", "time": "10:00", "amount_ml": 300, "category": "Morning"},
            dataset="personal",
        )
        res = self.records.delete_record(added["record"]["id"], dataset="personal")
        self.assertEqual(res["remaining_count"], 0)
        self.assertEqual(len(self.storage.load_records("personal")), 0)

    def test_07_calculate_daily_totals(self):
        self.records.add_record({"date": "2026-11-17", "time": "08:00", "amount_ml": 300, "category": "Morning"}, dataset="personal")
        self.records.add_record({"date": "2026-11-17", "time": "13:00", "amount_ml": 500, "category": "Afternoon"}, dataset="personal")
        analytics = compute_analytics(self.storage.load_records("personal"), self.storage.load_settings(), reference_date="2026-11-17")
        self.assertEqual(analytics["daily"]["total_ml"], 800)
        self.assertEqual(analytics["daily"]["entry_count"], 2)

    def test_08_calculate_weekly_averages(self):
        # 700 ml + 1400 ml = 2100 ml over 7-day window -> 300 ml/day avg
        self.records.add_record({"date": "2026-11-16", "time": "10:00", "amount_ml": 700, "category": "Morning"}, dataset="personal")
        self.records.add_record({"date": "2026-11-17", "time": "10:00", "amount_ml": 1400, "category": "Morning"}, dataset="personal")
        analytics = compute_analytics(self.storage.load_records("personal"), self.storage.load_settings(), reference_date="2026-11-17")
        self.assertEqual(analytics["weekly"]["total_ml"], 2100)
        self.assertEqual(analytics["weekly"]["daily_average_ml"], 300)

    def test_09_calculate_completion_percentages(self):
        settings = validate_settings_payload({"daily_target_ml": 2000}, self.storage.load_settings())
        self.storage.save_settings(settings)
        self.records.add_record({"date": "2026-11-17", "time": "09:00", "amount_ml": 1500, "category": "Morning"}, dataset="personal")
        analytics = compute_analytics(self.storage.load_records("personal"), settings, reference_date="2026-11-17")
        self.assertEqual(analytics["daily"]["completion_pct"], 75.0)
        self.assertEqual(analytics["daily"]["remaining_ml"], 500)

    def test_10_search_and_filter_records(self):
        self.records.add_record({"date": "2026-11-15", "time": "08:00", "amount_ml": 250, "category": "Morning", "notes": "Coffee shop"}, dataset="personal")
        self.records.add_record({"date": "2026-11-17", "time": "14:00", "amount_ml": 600, "category": "Afternoon", "notes": "Gym bottle"}, dataset="personal")
        by_keyword = self.records.list_records(dataset="personal", search="gym")
        self.assertEqual(by_keyword["total"], 1)
        by_cat = self.records.list_records(dataset="personal", category="Morning")
        self.assertEqual(by_cat["total"], 1)
        by_range = self.records.list_records(dataset="personal", start_date="2026-11-16", end_date="2026-11-17")
        self.assertEqual(by_range["total"], 1)

    def test_11_save_records_to_json(self):
        self.records.add_record({"date": "2026-11-17", "time": "09:00", "amount_ml": 350, "category": "Morning", "notes": "JSON check"}, dataset="personal")
        data = json.loads(self.storage.personal_json_path.read_text(encoding="utf-8"))
        self.assertEqual(len(data["records"]), 1)
        self.assertEqual(data["records"][0]["amount_ml"], 350)

    def test_12_save_records_to_csv(self):
        self.records.add_record({"date": "2026-11-17", "time": "09:00", "amount_ml": 450, "category": "Morning", "notes": "CSV check"}, dataset="personal")
        with self.storage.personal_csv_path.open("r", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["Amount_ml"], "450")

    def test_13_load_previously_saved_records_after_restart(self):
        self.records.add_record({"date": "2026-11-17", "time": "09:15", "amount_ml": 500, "category": "Morning", "notes": "Persist me"}, dataset="personal")
        self.storage.save_settings(validate_settings_payload({"daily_target_ml": 3000}, self.storage.load_settings()))

        # Simulate full application restart with fresh service instances pointing to same directory
        restarted_storage = StorageService(storage_dir=self.storage_dir)
        reloaded_records = restarted_storage.load_records("personal")
        reloaded_settings = restarted_storage.load_settings()
        self.assertEqual(len(reloaded_records), 1)
        self.assertEqual(reloaded_records[0].notes, "Persist me")
        self.assertEqual(reloaded_settings.daily_target_ml, 3000)

    def test_14_handle_corrupted_json_gracefully(self):
        self.records.add_record({"date": "2026-11-17", "time": "09:00", "amount_ml": 300, "category": "Morning", "notes": "Backup from CSV"}, dataset="personal")
        # Corrupt JSON file while CSV remains intact
        self.storage.personal_json_path.write_text("{corrupted_json: [", encoding="utf-8")
        recovered_storage = StorageService(storage_dir=self.storage_dir)
        recovered = recovered_storage.load_records("personal")
        self.assertEqual(len(recovered), 1)
        self.assertIsNotNone(recovered_storage.last_recovery_notice)

    def test_15_import_valid_csv_files(self):
        csv_text = "ID,Date,Time,Amount_ml,Category,Notes\n1,2026-11-17,08:30,250,Morning,Clean import\n2,2026-11-17,13:00,500,Afternoon,Lunch\n"
        result = self.records.commit_csv_import(csv_text, dataset="personal")
        self.assertEqual(result["imported_count"], 2)
        self.assertEqual(result["rejected_count"], 0)
        self.assertEqual(len(self.storage.load_records("personal")), 2)

    def test_16_reject_malformed_csv_and_mixed_invalid_rows(self):
        with self.assertRaises(ValidationIssue):
            self.records.preview_csv_import("Wrong,Headers,Only\n1,2,3\n", dataset="personal")

        mixed_csv = (
            "ID,Date,Time,Amount_ml,Category,Notes\n"
            "1,2026-11-17,09:00,250,Morning,Valid row\n"
            "2,2026-11-17,10:00,-50,Morning,Negative row\n"
            "3,2026-11-17,11:00,abc,Morning,Alphabetic row\n"
        )
        preview = self.records.preview_csv_import(mixed_csv, dataset="personal")
        self.assertEqual(preview["valid_count"], 1)
        self.assertEqual(preview["invalid_count"], 2)

    def test_17_generate_reports(self):
        self.records.add_record({"date": "2026-11-17", "time": "09:00", "amount_ml": 500, "category": "Morning", "notes": "Report entry"}, dataset="personal")
        summary = self.reports.build_report_summary(dataset="personal", reference_date="2026-11-17")
        md_text = self.reports.export_markdown(summary)
        txt_text = self.reports.export_txt(summary)
        csv_text = self.reports.export_csv(summary["records"])
        self.assertIn("500", md_text)
        self.assertIn("AUDIT LOG ENTRIES", txt_text)
        self.assertIn("Amount_ml", csv_text)

    def test_18_generate_analytical_charts_or_clean_fallback(self):
        analytics = compute_analytics(self.storage.load_records("demo"), self.storage.load_settings(), reference_date="2026-11-17")
        status = get_chart_engine_status()
        self.assertIn("matplotlib_available", status)
        out_path = Path(self.tmp_dir.name) / "test_chart.png"
        res = generate_matplotlib_chart("weekly_line", analytics, out_path)
        if MATPLOTLIB_AVAILABLE:
            self.assertTrue(res["success"])
            self.assertTrue(out_path.exists())
        else:
            self.assertFalse(res["success"])
            self.assertEqual(res["code"], "MATPLOTLIB_UNAVAILABLE")


if __name__ == "__main__":
    unittest.main(verbosity=2)
