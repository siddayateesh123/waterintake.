import { useMemo, useState } from "react";
import {
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  History,
  Pencil,
  RotateCcw,
  Search,
  Trash2,
} from "lucide-react";
import type { AppSettings, NavSection, WaterRecord } from "../types/hydration";
import { formatVolume } from "../utils/formatters";

interface HistoryPageProps {
  records: WaterRecord[];
  settings: AppSettings;
  onEditRecord: (record: WaterRecord) => void;
  onDeleteRecord: (record: WaterRecord) => void;
  onNavigate: (nav: NavSection) => void;
}

const CATEGORIES = ["All", "Morning", "Afternoon", "Evening", "Night", "Other"] as const;
const PAGE_SIZE = 10;

export function HistoryPage({
  records,
  settings,
  onEditRecord,
  onDeleteRecord,
  onNavigate,
}: HistoryPageProps) {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<string>("All");
  const [exactDate, setExactDate] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [sortBy, setSortBy] = useState<"date_desc" | "date_asc" | "amount_desc" | "amount_asc">("date_desc");
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    let list = [...records];

    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter(
        (r) =>
          String(r.id).includes(q) ||
          r.date.toLowerCase().includes(q) ||
          r.time.toLowerCase().includes(q) ||
          String(r.amount_ml).includes(q) ||
          r.category.toLowerCase().includes(q) ||
          (r.notes || "").toLowerCase().includes(q)
      );
    }

    if (category !== "All") {
      list = list.filter((r) => r.category === category);
    }

    if (exactDate) {
      list = list.filter((r) => r.date === exactDate);
    } else {
      if (startDate) list = list.filter((r) => r.date >= startDate);
      if (endDate) list = list.filter((r) => r.date <= endDate);
    }

    list.sort((a, b) => {
      if (sortBy === "date_asc") {
        return `${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`) || a.id - b.id;
      }
      if (sortBy === "amount_desc") {
        return b.amount_ml - a.amount_ml || `${b.date} ${b.time}`.localeCompare(`${a.date} ${a.time}`);
      }
      if (sortBy === "amount_asc") {
        return a.amount_ml - b.amount_ml || `${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`);
      }
      return `${b.date} ${b.time}`.localeCompare(`${a.date} ${a.time}`) || b.id - a.id;
    });

    return list;
  }, [records, search, category, exactDate, startDate, endDate, sortBy]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const pagedRecords = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);
  const filteredSumMl = filtered.reduce((acc, r) => acc + r.amount_ml, 0);

  const hasActiveFilters = Boolean(search || category !== "All" || exactDate || startDate || endDate || sortBy !== "date_desc");

  const handleClearFilters = () => {
    setSearch("");
    setCategory("All");
    setExactDate("");
    setStartDate("");
    setEndDate("");
    setSortBy("date_desc");
    setPage(1);
  };

  return (
    <div className="space-y-5">
      {/* Search and Filter Controls */}
      <section className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
          <div>
            <h2 className="font-display text-base font-bold text-[#172554] dark:text-slate-50">
              Search &amp; Filter Records
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Showing <span className="font-mono-num font-semibold">{filtered.length}</span> of{" "}
              <span className="font-mono-num">{records.length}</span> records · Filtered sum{" "}
              <span className="font-mono-num font-semibold text-[#2196F3] dark:text-sky-400">
                {formatVolume(filteredSumMl, settings.preferred_unit)}
              </span>
            </p>
          </div>
          {hasActiveFilters && (
            <button
              type="button"
              onClick={handleClearFilters}
              className="inline-flex items-center gap-1.5 rounded-lg border border-blue-200 px-3 py-1.5 text-xs font-semibold text-[#172554] hover:bg-blue-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Clear Filters</span>
            </button>
          )}
        </div>

        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-6">
          <div className="relative lg:col-span-2">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              placeholder="Search notes, ID, amount, category..."
              className="w-full rounded-lg border border-blue-100 bg-[#F4F9FF] py-2 pl-9 pr-3 text-xs text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            />
          </div>

          <div>
            <select
              value={category}
              onChange={(e) => {
                setCategory(e.target.value);
                setPage(1);
              }}
              aria-label="Filter by category"
              className="w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3 py-2 text-xs text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            >
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c === "All" ? "All Categories" : c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <input
              type="date"
              value={exactDate}
              onChange={(e) => {
                setExactDate(e.target.value);
                setStartDate("");
                setEndDate("");
                setPage(1);
              }}
              aria-label="Filter by exact date"
              title="Exact date filter"
              className="w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3 py-2 font-mono-num text-xs text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            />
          </div>

          <div>
            <input
              type="date"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setExactDate("");
                setPage(1);
              }}
              aria-label="Range start date"
              title="Custom range start date"
              className="w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3 py-2 font-mono-num text-xs text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            />
          </div>

          <div>
            <input
              type="date"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                setExactDate("");
                setPage(1);
              }}
              aria-label="Range end date"
              title="Custom range end date"
              className="w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3 py-2 font-mono-num text-xs text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            />
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-blue-50 pt-3 dark:border-slate-800">
          <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
            <span>Tip: Use Exact Date or Start/End Range to narrow logs.</span>
          </div>
          <div className="flex items-center gap-2">
            <label htmlFor="history-sort" className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Sort by:
            </label>
            <select
              id="history-sort"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
              className="rounded-lg border border-blue-100 bg-[#F4F9FF] px-2.5 py-1.5 text-xs font-medium text-[#172554] dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            >
              <option value="date_desc">Date (Newest First)</option>
              <option value="date_asc">Date (Oldest First)</option>
              <option value="amount_desc">Amount (Highest First)</option>
              <option value="amount_asc">Amount (Lowest First)</option>
            </select>
          </div>
        </div>
      </section>

      {/* Records Table */}
      <section className="rounded-xl border border-blue-100 bg-white dark:border-slate-800 dark:bg-slate-900">
        {pagedRecords.length === 0 ? (
          <div className="flex flex-col items-center justify-center px-6 py-14 text-center">
            <History className="h-10 w-10 text-[#38BDF8]" />
            <h3 className="mt-3 font-display text-base font-bold text-[#172554] dark:text-slate-50">
              {records.length === 0 ? "No Water Intake History Yet" : "No Matching Records Found"}
            </h3>
            <p className="mt-1 max-w-md text-xs text-slate-500 dark:text-slate-400">
              {records.length === 0
                ? "Start recording your daily water intake to build a searchable hydration history."
                : "Try adjusting your keyword, category, or date range filters."}
            </p>
            <div className="mt-4 flex gap-2.5">
              {hasActiveFilters ? (
                <button
                  type="button"
                  onClick={handleClearFilters}
                  className="rounded-lg border border-blue-200 px-4 py-2 text-xs font-semibold text-[#172554] hover:bg-blue-50 dark:border-slate-700 dark:text-slate-100"
                >
                  Reset All Filters
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => onNavigate("log")}
                  className="rounded-lg bg-[#2196F3] px-4 py-2 text-xs font-semibold text-white hover:bg-blue-600"
                >
                  Log First Entry
                </button>
              )}
            </div>
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[720px] text-left text-sm">
                <thead>
                  <tr className="border-b border-blue-100 bg-[#F4F9FF]/80 text-xs font-semibold text-slate-600 dark:border-slate-800 dark:bg-slate-800/60 dark:text-slate-300">
                    <th className="px-4 py-3">Record ID</th>
                    <th className="px-4 py-3">Date</th>
                    <th className="px-4 py-3">Time</th>
                    <th className="px-4 py-3 text-right">Water Amount</th>
                    <th className="px-4 py-3">Category</th>
                    <th className="px-4 py-3">Notes</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-blue-50 dark:divide-slate-800">
                  {pagedRecords.map((rec) => (
                    <tr key={rec.id} className="hover:bg-[#F4F9FF]/60 dark:hover:bg-slate-800/40">
                      <td className="px-4 py-3 font-mono-num text-xs text-slate-500 dark:text-slate-400">
                        #{rec.id}
                      </td>
                      <td className="px-4 py-3 font-mono-num text-xs text-[#172554] dark:text-slate-100">
                        {rec.date}
                      </td>
                      <td className="px-4 py-3 font-mono-num text-xs text-slate-600 dark:text-slate-300">
                        {rec.time}
                      </td>
                      <td className="px-4 py-3 text-right font-mono-num text-xs font-semibold text-[#172554] dark:text-slate-50">
                        <span>{formatVolume(rec.amount_ml, settings.preferred_unit)}</span>
                        {rec.unusual_warning && (
                          <span
                            title={rec.unusual_warning.message}
                            className="ml-2 inline-flex items-center gap-1 text-[11px] font-medium text-amber-600 dark:text-amber-400"
                          >
                            <AlertTriangle className="h-3 w-3" />
                            <span>{rec.unusual_warning.level === "high" ? "High" : "Low"}</span>
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-700 dark:text-slate-300">
                        {rec.category}
                      </td>
                      <td className="max-w-xs truncate px-4 py-3 text-xs text-slate-600 dark:text-slate-400">
                        {rec.notes || "—"}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => onEditRecord(rec)}
                            className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium text-[#2196F3] hover:bg-blue-50 dark:text-sky-400 dark:hover:bg-slate-800"
                          >
                            <Pencil className="h-3 w-3" />
                            <span>Edit</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteRecord(rec)}
                            className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/50"
                          >
                            <Trash2 className="h-3 w-3" />
                            <span>Delete</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex items-center justify-between border-t border-blue-100 px-4 py-3 text-xs dark:border-slate-800">
              <span className="font-mono-num text-slate-500 dark:text-slate-400">
                Page {safePage} of {totalPages}
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={safePage <= 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  className="inline-flex items-center gap-1 rounded-lg border border-blue-100 px-3 py-1.5 font-medium text-slate-700 hover:bg-blue-50 disabled:opacity-40 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                >
                  <ChevronLeft className="h-3.5 w-3.5" />
                  <span>Previous</span>
                </button>
                <button
                  type="button"
                  disabled={safePage >= totalPages}
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                  className="inline-flex items-center gap-1 rounded-lg border border-blue-100 px-3 py-1.5 font-medium text-slate-700 hover:bg-blue-50 disabled:opacity-40 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                >
                  <span>Next</span>
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          </>
        )}
      </section>
    </div>
  );
}
