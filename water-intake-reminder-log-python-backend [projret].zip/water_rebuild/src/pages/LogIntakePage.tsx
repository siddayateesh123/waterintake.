import { useState } from "react";
import { AlertTriangle, CheckCircle2, Droplets, Pencil, Trash2 } from "lucide-react";
import type { AppSettings, CategoryType, WaterRecord } from "../types/hydration";
import {
  formatVolume,
  getLocalDateString,
  getLocalTimeString,
  suggestCategoryForTime,
} from "../utils/formatters";

interface LogIntakePageProps {
  records: WaterRecord[];
  settings: AppSettings;
  onAddRecord: (payload: {
    amount_ml: string;
    date: string;
    time: string;
    category: CategoryType;
    notes: string;
  }) => Promise<void>;
  onEditRecord: (record: WaterRecord) => void;
  onDeleteRecord: (record: WaterRecord) => void;
}

const CATEGORIES: CategoryType[] = ["Morning", "Afternoon", "Evening", "Night", "Other"];
const QUICK_PRESETS = [100, 150, 200, 250, 300, 500];

export function LogIntakePage({
  records,
  settings,
  onAddRecord,
  onEditRecord,
  onDeleteRecord,
}: LogIntakePageProps) {
  const initialTime = getLocalTimeString();
  const [amount, setAmount] = useState("250");
  const [date, setDate] = useState(getLocalDateString());
  const [time, setTime] = useState(initialTime);
  const [category, setCategory] = useState<CategoryType>(suggestCategoryForTime(initialTime));
  const [notes, setNotes] = useState("");
  const [error, setError] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleTimeChange = (newTime: string) => {
    setTime(newTime);
    if (newTime) {
      setCategory(suggestCategoryForTime(newTime));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccessMsg("");
    setSubmitting(true);

    try {
      await onAddRecord({
        amount_ml: amount,
        date,
        time,
        category,
        notes,
      });
      setSuccessMsg(`Saved ${amount} ml entry for ${date} at ${time}.`);
      setNotes("");
      const nextTime = getLocalTimeString();
      setTime(nextTime);
      setDate(getLocalDateString());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to record water intake.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleResetTime = () => {
    const nowTime = getLocalTimeString();
    setDate(getLocalDateString());
    setTime(nowTime);
    setCategory(suggestCategoryForTime(nowTime));
  };

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      {/* Form Column */}
      <section className="rounded-xl border border-blue-100 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 lg:col-span-6">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-[#2196F3] dark:bg-sky-950 dark:text-sky-400">
            <Droplets className="h-5 w-5" />
          </div>
          <div>
            <h2 className="font-display text-lg font-bold text-[#172554] dark:text-slate-50">
              Record Water Consumption
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Validated entries are saved immediately to JSON and CSV storage.
            </p>
          </div>
        </div>

        <div className="mt-5">
          <span className="block text-xs font-medium text-slate-600 dark:text-slate-400">
            Quick-Fill Preset Amounts
          </span>
          <div className="mt-2 flex flex-wrap gap-2">
            {QUICK_PRESETS.map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => {
                  setAmount(String(preset));
                  setError("");
                }}
                className={`rounded-lg border px-3 py-1.5 font-mono-num text-xs font-semibold transition-colors ${
                  amount === String(preset)
                    ? "border-[#2196F3] bg-blue-50 text-[#2196F3] dark:border-sky-400 dark:bg-sky-950/70 dark:text-sky-300"
                    : "border-blue-100 bg-[#F4F9FF] text-[#172554] hover:border-blue-300 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                }`}
              >
                {preset} ml
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4" noValidate>
          {error && (
            <div
              role="alert"
              className="flex items-start gap-2.5 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-xs font-medium text-red-700 dark:border-red-900 dark:bg-red-950/50 dark:text-red-300"
            >
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {successMsg && (
            <div
              role="status"
              className="flex items-start gap-2.5 rounded-lg border border-teal-200 bg-teal-50 px-4 py-3 text-xs font-medium text-teal-800 dark:border-teal-900 dark:bg-teal-950/40 dark:text-teal-300"
            >
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          <div>
            <label htmlFor="intake-amount" className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Water Amount (ml) *
            </label>
            <input
              id="intake-amount"
              type="text"
              inputMode="decimal"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter positive milliliters (e.g. 250)"
              className="mt-1.5 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3.5 py-2.5 font-mono-num text-sm text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            />
            <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
              Must be a positive number greater than 0 ml. Empty, zero, negative, or text inputs are rejected.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="intake-date" className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Date *
              </label>
              <input
                id="intake-date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3.5 py-2.5 font-mono-num text-sm text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
              />
            </div>

            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="intake-time" className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Time *
                </label>
                <button
                  type="button"
                  onClick={handleResetTime}
                  className="text-[11px] font-medium text-[#2196F3] hover:underline dark:text-sky-400"
                >
                  Use Now
                </button>
              </div>
              <input
                id="intake-time"
                type="time"
                value={time}
                onChange={(e) => handleTimeChange(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3.5 py-2.5 font-mono-num text-sm text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
              />
            </div>
          </div>

          <div>
            <label htmlFor="intake-category" className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Category *
            </label>
            <select
              id="intake-category"
              value={category}
              onChange={(e) => setCategory(e.target.value as CategoryType)}
              className="mt-1.5 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3.5 py-2.5 text-sm text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="intake-notes" className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Optional Notes
            </label>
            <textarea
              id="intake-notes"
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              maxLength={300}
              placeholder="Add context (e.g., After morning lecture, Gym bottle refill)"
              className="mt-1.5 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3.5 py-2.5 text-sm text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full rounded-lg bg-[#2196F3] px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-blue-600 disabled:opacity-60"
          >
            {submitting ? "Recording Entry..." : "Save Water Intake Record"}
          </button>
        </form>
      </section>

      {/* Recent & Editable Entries Column */}
      <section className="rounded-xl border border-blue-100 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 lg:col-span-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-display text-lg font-bold text-[#172554] dark:text-slate-50">
              Latest Logged Entries
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Review, edit, or delete recent water consumption records
            </p>
          </div>
          <span className="font-mono-num text-xs text-slate-500 dark:text-slate-400">
            {records.length} total
          </span>
        </div>

        {records.length === 0 ? (
          <div className="mt-6 rounded-lg border border-dashed border-blue-200 bg-[#F4F9FF] p-8 text-center dark:border-slate-700 dark:bg-slate-800/40">
            <p className="text-sm font-semibold text-[#172554] dark:text-slate-100">
              No records stored yet
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Submit the form on the left to create your first water intake entry.
            </p>
          </div>
        ) : (
          <ul className="mt-5 max-h-[520px] space-y-3 overflow-y-auto pr-1">
            {records.slice(0, 12).map((rec) => (
              <li
                key={rec.id}
                className="flex items-start justify-between gap-3 rounded-lg border border-blue-100 bg-[#F4F9FF]/60 p-3.5 dark:border-slate-800 dark:bg-slate-800/50"
              >
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                    <span className="font-mono-num font-semibold text-[#172554] dark:text-slate-100">
                      #{rec.id}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono-num">{rec.date} {rec.time}</span>
                    <span aria-hidden="true">·</span>
                    <span>{rec.category}</span>
                  </div>
                  <p className="mt-1 font-mono-num text-sm font-bold text-[#2196F3] dark:text-sky-400">
                    {formatVolume(rec.amount_ml, settings.preferred_unit)}
                  </p>
                  {rec.notes && (
                    <p className="mt-0.5 text-xs text-slate-600 dark:text-slate-300">
                      {rec.notes}
                    </p>
                  )}
                  {rec.unusual_warning && (
                    <p className="mt-1.5 flex items-center gap-1 text-[11px] font-medium text-amber-700 dark:text-amber-400">
                      <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                      <span>{rec.unusual_warning.message}</span>
                    </p>
                  )}
                </div>

                <div className="flex shrink-0 items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => onEditRecord(rec)}
                    className="flex h-8 w-8 items-center justify-center rounded-lg border border-blue-100 bg-white text-slate-600 hover:border-[#2196F3] hover:text-[#2196F3] dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
                    aria-label={`Edit record ${rec.id}`}
                    title="Edit"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteRecord(rec)}
                    className="flex h-8 w-8 items-center justify-center rounded-lg border border-blue-100 bg-white text-slate-600 hover:border-red-300 hover:text-red-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
                    aria-label={`Delete record ${rec.id}`}
                    title="Delete"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
