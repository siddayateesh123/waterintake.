import { useState } from "react";
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Droplets,
  Plus,
  Sparkles,
  Target,
  TrendingUp,
  X,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { CircularProgress } from "../components/CircularProgress";
import type {
  AnalyticsData,
  AppSettings,
  DatasetMode,
  NavSection,
  WaterRecord,
} from "../types/hydration";
import { formatDisplayDate, formatDualVolume, formatVolume } from "../utils/formatters";

interface DashboardPageProps {
  analytics: AnalyticsData;
  settings: AppSettings;
  records: WaterRecord[];
  onQuickAddAmount: (amount: number | "") => void;
  onNavigate: (nav: NavSection) => void;
  onSwitchDataset: (mode: DatasetMode) => void;
  onEditRecord: (record: WaterRecord) => void;
  onDeleteRecord: (record: WaterRecord) => void;
}

const QUICK_AMOUNTS = [100, 150, 200, 250, 300];

export function DashboardPage({
  analytics,
  settings,
  records,
  onQuickAddAmount,
  onNavigate,
  onSwitchDataset,
  onEditRecord,
  onDeleteRecord,
}: DashboardPageProps) {
  const [bannerDismissed, setBannerDismissed] = useState(false);

  const { daily, weekly } = analytics;
  const recentRecords = records.slice(0, 6);
  const progressBarPct = Math.min(100, Math.max(0, daily.completion_pct));

  return (
    <div className="space-y-6">
      {!bannerDismissed && (
        <section
          aria-label="Welcome banner"
          className="rounded-xl border border-blue-200 bg-gradient-to-r from-[#2196F3]/10 via-[#38BDF8]/10 to-[#14B8A6]/10 p-5 dark:border-sky-900/60 dark:from-sky-950/70 dark:via-slate-900 dark:to-teal-950/50"
        >
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-center">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-xs font-medium text-[#2196F3] dark:text-sky-400">
                <span>Water Intake Reminder Log</span>
                <span aria-hidden="true">·</span>
                <span>CampusSolve Project #31</span>
              </div>
              <h2 className="font-display text-lg font-bold text-[#172554] dark:text-slate-50 sm:text-xl">
                Stay consistent with daily hydration tracking and analytics
              </h2>
              <p className="max-w-2xl text-sm text-slate-600 dark:text-slate-300">
                {settings.active_dataset === "demo"
                  ? "Viewing the 42-record Demonstration Dataset so you can explore dashboard trends, filters, and report exports immediately. Switch to Personal Log anytime to keep your own private entries."
                  : "Viewing your Personal Hydration Log stored locally in synchronized JSON and CSV files."}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2.5 shrink-0">
              <div className="flex items-center rounded-lg border border-blue-200 bg-white p-1 dark:border-slate-700 dark:bg-slate-800">
                <button
                  type="button"
                  onClick={() => onSwitchDataset("demo")}
                  className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                    settings.active_dataset === "demo"
                      ? "bg-[#2196F3] text-white"
                      : "text-slate-600 hover:text-[#172554] dark:text-slate-300"
                  }`}
                >
                  Demo Dataset
                </button>
                <button
                  type="button"
                  onClick={() => onSwitchDataset("personal")}
                  className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                    settings.active_dataset === "personal"
                      ? "bg-[#2196F3] text-white"
                      : "text-slate-600 hover:text-[#172554] dark:text-slate-300"
                  }`}
                >
                  Personal Log
                </button>
              </div>

              <button
                type="button"
                onClick={() => setBannerDismissed(true)}
                className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-white/70 hover:text-[#172554] dark:text-slate-400 dark:hover:bg-slate-800"
                aria-label="Dismiss welcome banner"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        </section>
      )}

      {/* 4 Statistics KPI Cards */}
      <section aria-label="Hydration statistics" className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {/* Card 1: Today's Water Intake */}
        <div className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Today&apos;s Water Intake
            </span>
            <Droplets className="h-4 w-4 text-[#2196F3] dark:text-sky-400" />
          </div>
          <p className="mt-3 font-mono-num text-2xl font-bold text-[#172554] dark:text-slate-50">
            {daily.total_ml.toLocaleString()} ml
          </p>
          <p className="mt-1 font-mono-num text-xs text-slate-500 dark:text-slate-400">
            {daily.total_liters.toFixed(2)} L · {daily.entry_count}{" "}
            {daily.entry_count === 1 ? "entry" : "entries"} today
          </p>
        </div>

        {/* Card 2: Daily Target */}
        <div className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Daily Target
            </span>
            <Target className="h-4 w-4 text-[#14B8A6]" />
          </div>
          <p className="mt-3 font-mono-num text-2xl font-bold text-[#172554] dark:text-slate-50">
            {daily.target_ml.toLocaleString()} ml
          </p>
          <div className="mt-1 flex items-center justify-between text-xs">
            <span className="font-mono-num text-slate-500 dark:text-slate-400">
              {daily.target_liters.toFixed(2)} L goal
            </span>
            <button
              type="button"
              onClick={() => onNavigate("settings")}
              className="font-medium text-[#2196F3] hover:underline dark:text-sky-400"
            >
              Adjust target
            </button>
          </div>
        </div>

        {/* Card 3: Remaining Water */}
        <div className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Remaining Water
            </span>
            {daily.remaining_ml === 0 ? (
              <CheckCircle2 className="h-4 w-4 text-[#14B8A6]" />
            ) : (
              <TrendingUp className="h-4 w-4 text-[#38BDF8]" />
            )}
          </div>
          <p className="mt-3 font-mono-num text-2xl font-bold text-[#172554] dark:text-slate-50">
            {daily.remaining_ml.toLocaleString()} ml
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            {daily.exceeded_ml > 0 ? (
              <span className="font-medium text-[#14B8A6] dark:text-teal-400">
                Target exceeded by {daily.exceeded_ml.toLocaleString()} ml
              </span>
            ) : daily.remaining_ml === 0 ? (
              <span className="font-medium text-[#14B8A6] dark:text-teal-400">
                Daily hydration target reached
              </span>
            ) : (
              <span className="font-mono-num">
                {daily.remaining_liters.toFixed(2)} L remaining today
              </span>
            )}
          </p>
        </div>

        {/* Card 4: Goal Completion */}
        <div className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <CircularProgress
            percentage={daily.completion_pct}
            size={84}
            strokeWidth={8}
            statusLabel={daily.hydration_status}
          />
        </div>
      </section>

      {/* Quick-Add Bar & Daily Goal Progress */}
      <section className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-center">
          <div>
            <h2 className="font-display text-base font-bold text-[#172554] dark:text-slate-50">
              Quick Add Water Intake
            </h2>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              Select a preset volume or enter a custom amount to log immediately after confirmation.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {QUICK_AMOUNTS.map((amt) => (
              <button
                key={amt}
                type="button"
                onClick={() => onQuickAddAmount(amt)}
                className="inline-flex h-10 items-center gap-1 rounded-lg border border-blue-200 bg-[#F4F9FF] px-3.5 font-mono-num text-xs font-semibold text-[#172554] transition-colors hover:border-[#2196F3] hover:bg-blue-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:border-sky-400 dark:hover:bg-slate-700"
              >
                <Plus className="h-3.5 w-3.5 text-[#2196F3] dark:text-sky-400" />
                <span>{amt} ml</span>
              </button>
            ))}
            <button
              type="button"
              onClick={() => onQuickAddAmount("")}
              className="inline-flex h-10 items-center gap-1.5 rounded-lg bg-[#2196F3] px-4 text-xs font-semibold text-white transition-colors hover:bg-blue-600"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>Custom Amount</span>
            </button>
          </div>
        </div>

        <div className="mt-5 border-t border-blue-50 pt-4 dark:border-slate-800">
          <div className="flex items-center justify-between text-xs">
            <span className="font-medium text-slate-600 dark:text-slate-300">
              Daily Goal Progress ({formatDualVolume(daily.total_ml)} of {formatDualVolume(daily.target_ml)})
            </span>
            <span className="font-mono-num font-semibold text-[#172554] dark:text-slate-100">
              {daily.completion_pct.toFixed(1)}%
            </span>
          </div>
          <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-blue-100 dark:bg-slate-800">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                daily.completion_pct >= 100 ? "bg-[#14B8A6]" : "bg-[#2196F3]"
              }`}
              style={{ width: `${progressBarPct}%` }}
            />
          </div>
        </div>
      </section>

      {/* Main 2-Column Visual Section: Weekly Overview + Today's Timeline */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 lg:col-span-7">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display text-base font-bold text-[#172554] dark:text-slate-50">
                Weekly Hydration Overview
              </h2>
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                Last 7 days ({weekly.start_date} to {weekly.end_date}) · Avg{" "}
                <span className="font-mono-num">{formatVolume(weekly.daily_average_ml, settings.preferred_unit)}</span>/day
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate("analytics")}
              className="inline-flex items-center gap-1 text-xs font-semibold text-[#2196F3] hover:underline dark:text-sky-400"
            >
              <span>Full Analytics</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="mt-4 h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weekly.series} margin={{ top: 10, right: 12, left: -12, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                <XAxis dataKey="short_day" tick={{ fontSize: 12, fill: "#64748B" }} />
                <YAxis tick={{ fontSize: 12, fill: "#64748B" }} />
                <Tooltip
                  formatter={(value) => [`${Number(value ?? 0).toLocaleString()} ml`, "Intake"]}
                  contentStyle={{
                    borderRadius: "10px",
                    border: "1px solid #DBEAFE",
                    fontSize: "12px",
                  }}
                />
                <ReferenceLine
                  y={daily.target_ml}
                  stroke="#14B8A6"
                  strokeDasharray="4 4"
                  label={{ value: "Target", position: "insideTopRight", fill: "#14B8A6", fontSize: 11 }}
                />
                <Bar dataKey="total_ml" fill="#2196F3" radius={[6, 6, 0, 0]} maxBarSize={42} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 lg:col-span-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display text-base font-bold text-[#172554] dark:text-slate-50">
                Today&apos;s Consumption Timeline
              </h2>
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                Chronological hydration entries for {formatDisplayDate(daily.date)}
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate("log")}
              className="text-xs font-semibold text-[#2196F3] hover:underline dark:text-sky-400"
            >
              Add Entry
            </button>
          </div>

          {daily.timeline.length === 0 ? (
            <div className="mt-6 flex flex-col items-center justify-center rounded-lg border border-dashed border-blue-200 bg-[#F4F9FF] px-4 py-10 text-center dark:border-slate-700 dark:bg-slate-800/40">
              <Droplets className="h-8 w-8 text-[#38BDF8]" />
              <p className="mt-2 text-sm font-semibold text-[#172554] dark:text-slate-100">
                No intake recorded today
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Use a Quick Add button above or log a custom glass to begin today&apos;s timeline.
              </p>
            </div>
          ) : (
            <ul className="mt-4 max-h-64 space-y-2.5 overflow-y-auto pr-1">
              {daily.timeline.map((item) => (
                <li
                  key={item.id}
                  className="flex items-center justify-between gap-3 rounded-lg border border-blue-100 bg-[#F4F9FF]/70 px-3.5 py-2.5 dark:border-slate-800 dark:bg-slate-800/50"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span className="font-mono-num font-semibold text-[#2196F3] dark:text-sky-400">
                        {item.time}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{item.category}</span>
                    </div>
                    <p className="mt-0.5 truncate text-xs text-slate-700 dark:text-slate-300">
                      {item.notes || "Water intake logged"}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="font-mono-num text-sm font-bold text-[#172554] dark:text-slate-50">
                      +{formatVolume(item.amount_ml, settings.preferred_unit)}
                    </p>
                    <p className="font-mono-num text-[11px] text-slate-500 dark:text-slate-400">
                      Total {formatVolume(item.cumulative_ml, settings.preferred_unit)}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>

      {/* Recent Water Intake Records */}
      <section className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-display text-base font-bold text-[#172554] dark:text-slate-50">
              Recent Water Intake Records
            </h2>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              Latest entries saved to JSON and CSV persistence
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate("history")}
            className="inline-flex items-center gap-1 text-xs font-semibold text-[#2196F3] hover:underline dark:text-sky-400"
          >
            <span>View Full History</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>

        {recentRecords.length === 0 ? (
          <div className="mt-4 rounded-lg border border-dashed border-blue-200 bg-[#F4F9FF] p-8 text-center dark:border-slate-700 dark:bg-slate-800/40">
            <p className="text-sm font-semibold text-[#172554] dark:text-slate-100">
              Your personal log is currently empty
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Log your first drink or switch to Demo Dataset to explore sample records.
            </p>
            <button
              type="button"
              onClick={() => onQuickAddAmount(250)}
              className="mt-4 rounded-lg bg-[#2196F3] px-4 py-2 text-xs font-semibold text-white hover:bg-blue-600"
            >
              Log First 250 ml
            </button>
          </div>
        ) : (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[640px] text-left text-sm">
              <thead>
                <tr className="border-b border-blue-100 text-xs font-semibold text-slate-500 dark:border-slate-800 dark:text-slate-400">
                  <th className="py-2.5 pr-3">ID</th>
                  <th className="py-2.5 px-3">Date &amp; Time</th>
                  <th className="py-2.5 px-3 text-right">Amount</th>
                  <th className="py-2.5 px-3">Category</th>
                  <th className="py-2.5 px-3">Notes</th>
                  <th className="py-2.5 pl-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-blue-50 dark:divide-slate-800">
                {recentRecords.map((rec) => (
                  <tr key={rec.id} className="hover:bg-[#F4F9FF]/60 dark:hover:bg-slate-800/50">
                    <td className="py-2.5 pr-3 font-mono-num text-xs text-slate-500 dark:text-slate-400">
                      #{rec.id}
                    </td>
                    <td className="py-2.5 px-3 font-mono-num text-xs text-[#172554] dark:text-slate-200">
                      {rec.date} · {rec.time}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono-num text-xs font-semibold text-[#172554] dark:text-slate-100">
                      <span>{formatVolume(rec.amount_ml, settings.preferred_unit)}</span>
                      {rec.unusual_warning && (
                        <span
                          className="ml-2 inline-flex items-center gap-1 text-[11px] font-medium text-amber-600 dark:text-amber-400"
                          title={rec.unusual_warning.message}
                        >
                          <AlertTriangle className="h-3 w-3" />
                          Review
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-xs text-slate-600 dark:text-slate-300">
                      {rec.category}
                    </td>
                    <td className="max-w-xs truncate py-2.5 px-3 text-xs text-slate-600 dark:text-slate-400">
                      {rec.notes || "—"}
                    </td>
                    <td className="py-2.5 pl-3 text-right">
                      <div className="inline-flex items-center gap-2 text-xs">
                        <button
                          type="button"
                          onClick={() => onEditRecord(rec)}
                          className="font-medium text-[#2196F3] hover:underline dark:text-sky-400"
                        >
                          Edit
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteRecord(rec)}
                          className="font-medium text-red-600 hover:underline dark:text-red-400"
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
