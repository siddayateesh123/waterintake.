"""Python analytics engine computing daily, weekly, monthly, and category hydration metrics."""

from collections import defaultdict
from datetime import date, datetime, timedelta
import math
from typing import Any, Dict, List, Optional

from backend.models.water_record import AppSettings, VALID_CATEGORIES, WaterRecord


def _parse_date(date_str: str) -> date:
    return datetime.strptime(date_str, "%Y-%m-%d").date()


def _clean_num(val: float) -> float:
    rounded = round(float(val), 1)
    return int(rounded) if rounded.is_integer() else rounded


def compute_analytics(
    records: List[WaterRecord],
    settings: AppSettings,
    reference_date: Optional[str] = None,
) -> Dict[str, Any]:
    """Compute complete daily, weekly, monthly, and chart series from stored records."""
    if reference_date:
        try:
            ref_day = _parse_date(reference_date)
        except ValueError:
            ref_day = date.today()
    else:
        ref_day = date.today()

    target_ml = settings.daily_target_ml

    # Group records by date
    by_date: Dict[str, List[WaterRecord]] = defaultdict(list)
    for rec in records:
        by_date[rec.date].append(rec)

    daily_totals: Dict[str, float] = {
        d_str: sum(float(r.amount_ml) for r in day_recs) for d_str, day_recs in by_date.items()
    }

    # --- A. Daily Analytics ---
    today_str = ref_day.isoformat()
    today_records = sorted(by_date.get(today_str, []), key=lambda r: (r.time, r.id))
    today_total = sum(float(r.amount_ml) for r in today_records)
    remaining_ml = max(0.0, float(target_ml) - today_total)
    exceeded_ml = max(0.0, today_total - float(target_ml))
    completion_pct = round((today_total / float(target_ml)) * 100.0, 1) if target_ml > 0 else 0.0
    highest_entry_ml = max((float(r.amount_ml) for r in today_records), default=0.0)

    if today_total == 0:
        hydration_status = "Not Started"
    elif completion_pct < 40:
        hydration_status = "Low Progress"
    elif completion_pct < 80:
        hydration_status = "On Track"
    elif completion_pct < 100:
        hydration_status = "Almost There"
    elif exceeded_ml > 0:
        hydration_status = "Target Exceeded"
    else:
        hydration_status = "Target Achieved"

    cumulative = 0.0
    today_timeline = []
    for r in today_records:
        cumulative += float(r.amount_ml)
        today_timeline.append({
            "id": r.id,
            "time": r.time,
            "label": r.time,
            "amount_ml": _clean_num(float(r.amount_ml)),
            "cumulative_ml": _clean_num(cumulative),
            "target_ml": target_ml,
            "category": r.category,
            "notes": r.notes,
        })

    daily_stats = {
        "date": today_str,
        "day_name": ref_day.strftime("%A"),
        "total_ml": _clean_num(today_total),
        "total_liters": round(today_total / 1000.0, 2),
        "target_ml": target_ml,
        "target_liters": round(target_ml / 1000.0, 2),
        "remaining_ml": _clean_num(remaining_ml),
        "remaining_liters": round(remaining_ml / 1000.0, 2),
        "exceeded_ml": _clean_num(exceeded_ml),
        "exceeded_liters": round(exceeded_ml / 1000.0, 2),
        "completion_pct": completion_pct,
        "entry_count": len(today_records),
        "highest_entry_ml": _clean_num(highest_entry_ml),
        "hydration_status": hydration_status,
        "timeline": today_timeline,
    }

    # --- B. Weekly Analytics (last 7 days inclusive of ref_day) ---
    week_days = [ref_day - timedelta(days=offset) for offset in range(6, -1, -1)]
    weekly_series = []
    week_totals_list: List[float] = []
    for d_obj in week_days:
        d_str = d_obj.isoformat()
        total = daily_totals.get(d_str, 0.0)
        week_totals_list.append(total)
        pct = round((total / float(target_ml)) * 100.0, 1) if target_ml > 0 else 0.0
        weekly_series.append({
            "date": d_str,
            "label": d_obj.strftime("%a %d"),
            "short_day": d_obj.strftime("%a"),
            "total_ml": _clean_num(total),
            "target_ml": target_ml,
            "completion_pct": pct,
            "entries": len(by_date.get(d_str, [])),
            "met_target": total >= target_ml,
        })

    week_total = sum(week_totals_list)
    week_avg = week_total / 7.0
    highest_week_day = max(weekly_series, key=lambda x: x["total_ml"])
    lowest_week_day = min(weekly_series, key=lambda x: x["total_ml"])
    days_target_achieved = sum(1 for item in weekly_series if item["met_target"])

    weekly_stats = {
        "start_date": week_days[0].isoformat(),
        "end_date": week_days[-1].isoformat(),
        "total_ml": _clean_num(week_total),
        "total_liters": round(week_total / 1000.0, 2),
        "daily_average_ml": _clean_num(week_avg),
        "daily_average_liters": round(week_avg / 1000.0, 2),
        "highest_day": {"date": highest_week_day["date"], "label": highest_week_day["label"], "total_ml": highest_week_day["total_ml"]},
        "lowest_day": {"date": lowest_week_day["date"], "label": lowest_week_day["label"], "total_ml": lowest_week_day["total_ml"]},
        "days_target_achieved": days_target_achieved,
        "series": weekly_series,
    }

    # --- C. Monthly Analytics (last 30 days inclusive of ref_day) ---
    month_days = [ref_day - timedelta(days=offset) for offset in range(29, -1, -1)]
    monthly_series = []
    month_totals_list: List[float] = []
    for d_obj in month_days:
        d_str = d_obj.isoformat()
        total = daily_totals.get(d_str, 0.0)
        month_totals_list.append(total)
        monthly_series.append({
            "date": d_str,
            "label": d_obj.strftime("%b %d"),
            "total_ml": _clean_num(total),
            "target_ml": target_ml,
        })

    month_total = sum(month_totals_list)
    month_avg = month_total / 30.0
    month_target_total = target_ml * 30.0
    month_completion_pct = round((month_total / month_target_total) * 100.0, 1) if month_target_total > 0 else 0.0
    active_days_month = sum(1 for v in month_totals_list if v > 0)

    # 4 weekly comparison buckets across the 30-day window
    weekly_comparison = []
    for w_idx in range(4):
        chunk = monthly_series[w_idx * 7 : (w_idx + 1) * 7]
        if w_idx == 3:
            chunk = monthly_series[21:30]
        chunk_total = sum(c["total_ml"] for c in chunk)
        chunk_avg = chunk_total / len(chunk) if chunk else 0.0
        weekly_comparison.append({
            "week": f"Week {w_idx + 1}",
            "range": f"{chunk[0]['label']} - {chunk[-1]['label']}" if chunk else "",
            "total_ml": _clean_num(chunk_total),
            "average_ml": _clean_num(chunk_avg),
            "target_ml": target_ml,
        })

    # Daily consumption patterns across days of week (Mon-Sun) across all stored records
    dow_totals: Dict[int, List[float]] = defaultdict(list)
    for d_str, d_total in daily_totals.items():
        try:
            dow = _parse_date(d_str).weekday()
            dow_totals[dow].append(d_total)
        except ValueError:
            continue
    day_names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    daily_patterns = []
    for idx, name in enumerate(day_names):
        vals = dow_totals.get(idx, [])
        avg_val = sum(vals) / len(vals) if vals else 0.0
        daily_patterns.append({"day": name, "average_ml": _clean_num(avg_val), "logged_days": len(vals)})

    monthly_stats = {
        "start_date": month_days[0].isoformat(),
        "end_date": month_days[-1].isoformat(),
        "total_ml": _clean_num(month_total),
        "total_liters": round(month_total / 1000.0, 2),
        "daily_average_ml": _clean_num(month_avg),
        "monthly_completion_pct": month_completion_pct,
        "active_days": active_days_month,
        "days_target_achieved": sum(1 for v in month_totals_list if v >= target_ml),
        "series": monthly_series,
        "weekly_comparison": weekly_comparison,
        "daily_patterns": daily_patterns,
    }

    # --- D. Category Distribution (across all stored records) ---
    cat_totals: Dict[str, float] = {cat: 0.0 for cat in VALID_CATEGORIES}
    cat_counts: Dict[str, int] = {cat: 0 for cat in VALID_CATEGORIES}
    for rec in records:
        cat = rec.category if rec.category in cat_totals else "Other"
        cat_totals[cat] += float(rec.amount_ml)
        cat_counts[cat] += 1

    grand_total = sum(cat_totals.values())
    category_distribution = []
    for cat in VALID_CATEGORIES:
        val = cat_totals[cat]
        pct = round((val / grand_total) * 100.0, 1) if grand_total > 0 else 0.0
        category_distribution.append({
            "category": cat,
            "total_ml": _clean_num(val),
            "count": cat_counts[cat],
            "percentage": pct,
        })

    # Overall summary
    all_totals = list(daily_totals.values())
    overall_highest_day = max(daily_totals.items(), key=lambda kv: kv[1]) if daily_totals else (today_str, 0.0)
    overall_lowest_day = min(daily_totals.items(), key=lambda kv: kv[1]) if daily_totals else (today_str, 0.0)

    return {
        "reference_date": today_str,
        "total_records": len(records),
        "overall_total_ml": _clean_num(grand_total),
        "overall_highest_day": {"date": overall_highest_day[0], "total_ml": _clean_num(overall_highest_day[1])},
        "overall_lowest_day": {"date": overall_lowest_day[0], "total_ml": _clean_num(overall_lowest_day[1])},
        "daily": daily_stats,
        "weekly": weekly_stats,
        "monthly": monthly_stats,
        "category_distribution": category_distribution,
    }
