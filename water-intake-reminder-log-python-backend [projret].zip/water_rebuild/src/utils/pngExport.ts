/**
 * Exports either a live Recharts SVG container or a generated PNG chart file
 * when server-side Matplotlib is not installed in the runtime sandbox.
 */
export async function exportSvgElementAsPng(
  container: HTMLElement | null,
  filename: string,
  title: string,
  subtitle: string
): Promise<boolean> {
  if (!container) return false;
  const svg = container.querySelector("svg.recharts-surface") || container.querySelector("svg");
  if (!svg) return false;

  const rect = svg.getBoundingClientRect();
  const width = Math.max(820, Math.round(rect.width) || 820);
  const height = Math.max(360, Math.round(rect.height) || 360);
  const headerHeight = 68;
  const padding = 24;
  const scale = 2;

  const clonedSvg = svg.cloneNode(true) as SVGElement;
  clonedSvg.setAttribute("xmlns", "http://www.w3.org/2000/svg");
  clonedSvg.setAttribute("width", String(width));
  clonedSvg.setAttribute("height", String(height));

  const svgData = new XMLSerializer().serializeToString(clonedSvg);
  const svgBlob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
  const svgUrl = URL.createObjectURL(svgBlob);

  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = (width + padding * 2) * scale;
      canvas.height = (height + headerHeight + padding * 2) * scale;
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        URL.revokeObjectURL(svgUrl);
        resolve(false);
        return;
      }

      ctx.scale(scale, scale);
      ctx.fillStyle = "#FFFFFF";
      ctx.fillRect(0, 0, width + padding * 2, height + headerHeight + padding * 2);

      // Header branding
      ctx.fillStyle = "#172554";
      ctx.font = "700 18px 'Plus Jakarta Sans', system-ui, sans-serif";
      ctx.fillText(title, padding, padding + 20);

      ctx.fillStyle = "#475569";
      ctx.font = "400 12px 'DM Sans', system-ui, sans-serif";
      ctx.fillText(`${subtitle} · Water Intake Reminder Log`, padding, padding + 42);

      ctx.strokeStyle = "#E2E8F0";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(padding, padding + 54);
      ctx.lineTo(width + padding, padding + 54);
      ctx.stroke();

      ctx.drawImage(img, padding, padding + headerHeight, width, height);

      canvas.toBlob((blob) => {
        URL.revokeObjectURL(svgUrl);
        if (!blob) {
          resolve(false);
          return;
        }
        const dlUrl = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = dlUrl;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        link.remove();
        URL.revokeObjectURL(dlUrl);
        resolve(true);
      }, "image/png");
    };
    img.onerror = () => {
      URL.revokeObjectURL(svgUrl);
      resolve(false);
    };
    img.src = svgUrl;
  });
}
