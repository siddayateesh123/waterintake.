"""Atomic local JSON and CSV persistence with resilient error recovery."""

import csv
from datetime import date, datetime, timedelta
import json
import os
from pathlib import Path
import shutil
import tempfile
from typing import Any, Dict, List, Optional, Tuple

from backend.models.water_record import AppSettings, VALID_CATEGORIES, WaterRecord
from backend.utils.validators import validate_record_payload, validate_settings_payload


BASE_DIR = Path(__file__).resolve().parent.parent.parent
DEFAULT_STORAGE_DIR = BASE_DIR / "backend" / "storage"
DEFAULT_SAMPLE_PATH = BASE_DIR / "sample_data" / "sample_records.json"


class StorageService:
    """Manages synchronized JSON and CSV persistence for water records and settings."""

    CSV_HEADERS = ["ID", "Date", "Time", "Amount_ml", "Category", "Notes"]

    def __init__(self, storage_dir: Optional[Path] = None, sample_file: Optional[Path] = None):
        self.storage_dir = Path(storage_dir) if storage_dir else DEFAULT_STORAGE_DIR
        self.sample_file = Path(sample_file) if sample_file else DEFAULT_SAMPLE_PATH
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        self.settings_path = self.storage_dir / "settings.json"
        self.personal_json_path = self.storage_dir / "water_records.json"
        self.personal_csv_path = self.storage_dir / "water_records.csv"
        self.demo_json_path = self.storage_dir / "demo_records.json"
        self.demo_csv_path = self.storage_dir / "demo_records.csv"

        self.last_recovery_notice: Optional[str] = None
        self._ensure_initialized()

    def _atomic_write_text(self, path: Path, content: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp_name = tempfile.mkstemp(dir=str(path.parent), prefix=f".{path.name}.", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
                handle.write(content)
            os.replace(tmp_name, path)
        except Exception:
            if os.path.exists(tmp_name):
                os.unlink(tmp_name)
            raise

    def _backup_corrupted_file(self, path: Path) -> None:
        if path.exists():
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup = path.with_name(f"{path.stem}.corrupted_{stamp}{path.suffix}")
            try:
                shutil.copy2(path, backup)
            except OSError:
                pass

    def _dataset_paths(self, dataset: str) -> Tuple[Path, Path]:
        if dataset == "demo":
            return self.demo_json_path, self.demo_csv_path
        return self.personal_json_path, self.personal_csv_path

    def _load_sample_seed(self, reference_date: Optional[str] = None) -> List[WaterRecord]:
        """Load 42 realistic sample records and shift anchor_date to reference_date if needed."""
        ref_day = date.today()
        if reference_date:
            try:
                ref_day = datetime.strptime(reference_date, "%Y-%m-%d").date()
            except ValueError:
                pass

        raw_records: List[Dict[str, Any]] = []
        anchor_day = date(2026, 11, 17)

        if self.sample_file.exists():
            try:
                payload = json.loads(self.sample_file.read_text(encoding="utf-8"))
                meta = payload.get("metadata", {})
                if isinstance(meta, dict) and meta.get("anchor_date"):
                    anchor_day = datetime.strptime(meta["anchor_date"], "%Y-%m-%d").date()
                raw_records = payload.get("records", [])
            except (OSError, json.JSONDecodeError, ValueError):
                raw_records = []

        if not raw_records:
            # Built-in fallback seed if sample file is missing
            raw_records = [
                {"id": 1, "date": anchor_day.isoformat(), "time": "08:00", "amount_ml": 350, "category": "Morning", "notes": "First morning glass"},
                {"id": 2, "date": anchor_day.isoformat(), "time": "12:30", "amount_ml": 500, "category": "Afternoon", "notes": "Lunch hydration"},
            ]

        day_delta = (ref_day - anchor_day).days
        seeded: List[WaterRecord] = []
        for idx, item in enumerate(raw_records, start=1):
            try:
                orig_date = datetime.strptime(str(item["date"]), "%Y-%m-%d").date()
                shifted_date = (orig_date + timedelta(days=day_delta)).isoformat()
                validated = validate_record_payload({
                    "date": shifted_date,
                    "time": item["time"],
                    "amount_ml": item["amount_ml"],
                    "category": item["category"],
                    "notes": item.get("notes", ""),
                })
                seeded.append(WaterRecord(id=int(item.get("id", idx)), **validated))
            except Exception:
                continue
        return seeded

    def _ensure_initialized(self) -> None:
        if not self.settings_path.exists():
            self.save_settings(AppSettings())

        if not self.personal_json_path.exists():
            if self.personal_csv_path.exists():
                records = self._read_csv_records(self.personal_csv_path)
                self._write_dataset_files("personal", records, self.load_settings())
            else:
                self._write_dataset_files("personal", [], self.load_settings())
        elif not self.personal_csv_path.exists():
            records = self.load_records("personal")
            self._write_csv_file(self.personal_csv_path, records)

        if not self.demo_json_path.exists():
            if self.demo_csv_path.exists():
                records = self._read_csv_records(self.demo_csv_path)
                self._write_dataset_files("demo", records, self.load_settings())
            else:
                demo_records = self._load_sample_seed()
                self._write_dataset_files("demo", demo_records, self.load_settings())
        elif not self.demo_csv_path.exists():
            demo_records = self.load_records("demo")
            self._write_csv_file(self.demo_csv_path, demo_records)

    def load_settings(self) -> AppSettings:
        """Load settings from settings.json, recovering cleanly if missing or corrupted."""
        defaults = AppSettings()
        if not self.settings_path.exists():
            self.save_settings(defaults)
            return defaults

        try:
            raw = json.loads(self.settings_path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                raise ValueError("Settings root must be a JSON object")
            settings = validate_settings_payload(raw, defaults)
            return settings
        except (OSError, json.JSONDecodeError, ValueError):
            self._backup_corrupted_file(self.settings_path)
            self.last_recovery_notice = "Settings file was corrupted and safely restored to defaults."
            self.save_settings(defaults)
            return defaults

    def save_settings(self, settings: AppSettings) -> AppSettings:
        """Persist settings to settings.json and mirror summary settings inside active JSON storage."""
        payload = json.dumps(settings.to_dict(), indent=2)
        self._atomic_write_text(self.settings_path, payload + "\n")

        # Keep personal water_records.json header settings synchronized
        for ds in ("personal", "demo"):
            json_path, _ = self._dataset_paths(ds)
            if json_path.exists():
                try:
                    existing = json.loads(json_path.read_text(encoding="utf-8"))
                    if isinstance(existing, dict) and isinstance(existing.get("records"), list):
                        existing["settings"] = {
                            "daily_target_ml": settings.daily_target_ml,
                            "reminders_enabled": settings.reminders_enabled,
                            "preferred_unit": settings.preferred_unit,
                        }
                        self._atomic_write_text(json_path, json.dumps(existing, indent=2) + "\n")
                except (OSError, json.JSONDecodeError):
                    pass
        return settings

    def _read_csv_records(self, csv_path: Path) -> List[WaterRecord]:
        records: List[WaterRecord] = []
        if not csv_path.exists():
            return records
        try:
            with csv_path.open("r", encoding="utf-8", newline="") as handle:
                reader = csv.DictReader(handle)
                if not reader.fieldnames:
                    return records
                for idx, row in enumerate(reader, start=1):
                    try:
                        rec_id = int(str(row.get("ID", idx)).strip() or idx)
                        validated = validate_record_payload({
                            "date": row.get("Date", ""),
                            "time": row.get("Time", ""),
                            "amount_ml": row.get("Amount_ml", ""),
                            "category": row.get("Category", ""),
                            "notes": row.get("Notes", ""),
                        })
                        records.append(WaterRecord(id=rec_id, **validated))
                    except Exception:
                        continue
        except OSError:
            return []
        return records

    def _write_csv_file(self, csv_path: Path, records: List[WaterRecord]) -> None:
        from io import StringIO

        buf = StringIO()
        writer = csv.writer(buf, lineterminator="\n")
        writer.writerow(self.CSV_HEADERS)
        for rec in records:
            d = rec.to_dict()
            writer.writerow([d["id"], d["date"], d["time"], d["amount_ml"], d["category"], d["notes"]])
        self._atomic_write_text(csv_path, buf.getvalue())

    def _write_dataset_files(self, dataset: str, records: List[WaterRecord], settings: AppSettings) -> None:
        json_path, csv_path = self._dataset_paths(dataset)
        payload = {
            "settings": {
                "daily_target_ml": settings.daily_target_ml,
                "reminders_enabled": settings.reminders_enabled,
                "preferred_unit": settings.preferred_unit,
            },
            "records": [rec.to_dict() for rec in records],
        }
        self._atomic_write_text(json_path, json.dumps(payload, indent=2) + "\n")
        self._write_csv_file(csv_path, records)

    def load_records(self, dataset: Optional[str] = None) -> List[WaterRecord]:
        """Load records for the requested dataset ('demo' or 'personal') with JSON/CSV fallback recovery."""
        settings = self.load_settings()
        target_ds = dataset or settings.active_dataset
        json_path, csv_path = self._dataset_paths(target_ds)

        if not json_path.exists():
            if csv_path.exists():
                records = self._read_csv_records(csv_path)
                self._write_dataset_files(target_ds, records, settings)
                return records
            if target_ds == "demo":
                records = self._load_sample_seed()
                self._write_dataset_files("demo", records, settings)
                return records
            self._write_dataset_files("personal", [], settings)
            return []

        try:
            raw = json.loads(json_path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                raw_list = raw.get("records")
                if not isinstance(raw_list, list):
                    raise ValueError("Missing 'records' list in JSON storage")
            elif isinstance(raw, list):
                raw_list = raw
            else:
                raise ValueError("Invalid JSON storage root type")

            valid_records: List[WaterRecord] = []
            seen_ids = set()
            for idx, entry in enumerate(raw_list, start=1):
                if not isinstance(entry, dict):
                    continue
                try:
                    rec_id = int(entry.get("id", idx))
                    while rec_id in seen_ids or rec_id <= 0:
                        rec_id += 1
                    seen_ids.add(rec_id)
                    validated = validate_record_payload(entry)
                    valid_records.append(WaterRecord(id=rec_id, **validated))
                except Exception:
                    continue
            return valid_records
        except (OSError, json.JSONDecodeError, ValueError):
            self._backup_corrupted_file(json_path)
            # Recover from CSV if available and valid
            recovered = self._read_csv_records(csv_path) if csv_path.exists() else []
            self.last_recovery_notice = (
                f"Detected corrupted {json_path.name}; backed up original and recovered "
                f"{len(recovered)} valid records."
            )
            self._write_dataset_files(target_ds, recovered, settings)
            return recovered

    def save_records(self, records: List[WaterRecord], dataset: Optional[str] = None) -> List[WaterRecord]:
        """Synchronize both JSON and CSV files for the specified dataset."""
        settings = self.load_settings()
        target_ds = dataset or settings.active_dataset
        self._write_dataset_files(target_ds, records, settings)
        return records

    def reset_demo_data(self, reference_date: Optional[str] = None) -> List[WaterRecord]:
        """Restore the 42-record demonstration dataset anchored to today's date."""
        settings = self.load_settings()
        demo_records = self._load_sample_seed(reference_date=reference_date)
        self._write_dataset_files("demo", demo_records, settings)
        return demo_records

    def clear_personal_data(self) -> List[WaterRecord]:
        """Clear all user-created personal records cleanly while preserving settings."""
        settings = self.load_settings()
        self._write_dataset_files("personal", [], settings)
        return []
