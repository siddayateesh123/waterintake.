import type { CategoryType, UnitMode } from "../types/hydration";

export function getLocalDateString(dateObj = new Date()): string {
  const year = dateObj.getFullYear();
  const month = String(dateObj.getMonth() + 1).padStart(2, "0");
  const day = String(dateObj.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function getLocalTimeString(dateObj = new Date()): string {
  const hours = String(dateObj.getHours()).padStart(2, "0");
  const minutes = String(dateObj.getMinutes()).padStart(2, "0");
  return `${hours}:${minutes}`;
}

export function suggestCategoryForTime(timeStr: string): CategoryType {
  const hour = Number(timeStr.split(":")[0] || 9);
  if (hour >= 5 && hour < 12) return "Morning";
  if (hour >= 12 && hour < 17) return "Afternoon";
  if (hour >= 17 && hour < 21) return "Evening";
  return "Night";
}

export function formatVolume(amountMl: number, unit: UnitMode = "ml"): string {
  if (unit === "L") {
    return `${(amountMl / 1000).toFixed(2)} L`;
  }
  return `${Math.round(amountMl).toLocaleString()} ml`;
}

export function formatDualVolume(amountMl: number): string {
  const liters = (amountMl / 1000).toFixed(2);
  return `${Math.round(amountMl).toLocaleString()} ml (${liters} L)`;
}

export function formatDisplayDate(dateStr: string): string {
  try {
    const [y, m, d] = dateStr.split("-").map(Number);
    const dt = new Date(y, (m || 1) - 1, d || 1);
    return dt.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  } catch {
    return dateStr;
  }
}
