"""Unified Python 3.11 JSON-over-stdio engine called by Express API routes."""

import json
from pathlib import Path
import sys
from typing import Any, Dict

# Ensure project root is importable regardless of working directory
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from backend.analytics.calculator import compute_analytics
from backend.analytics.charts import generate_matplotlib_chart, get_chart_engine_status
from backend.models.water_record import ValidationIssue
from backend.services.record_service import RecordService
from backend.services.report_service import REPORTS_DIR, ReportService
from backend.services.storage_service import StorageService
from backend.utils.validators import validate_settings_payload


def dispatch(action: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    storage = StorageService()
    record_service = RecordService(storage)
    report_service = ReportService(storage, record_service)

    dataset = payload.get("dataset")
    ref_date = payload.get("reference_date")

    if action == "bootstrap":
        settings = storage.load_settings()
        active_ds = dataset or settings.active_dataset
        records_data = record_service.list_records(dataset=active_ds, sort_by="date_desc")
        records = storage.load_records(active_ds)
        analytics = compute_analytics(records, settings, reference_date=ref_date)
        return {
            "ok": True,
            "settings": settings.to_dict(),
            "records": records_data["records"],
            "total": records_data["total"],
            "analytics": analytics,
            "chart_engine": get_chart_engine_status(),
            "recovery_notice": storage.last_recovery_notice,
        }

    if action == "get_records":
        res = record_service.list_records(
            dataset=dataset,
            search=str(payload.get("search", "")),
            category=str(payload.get("category", "")),
            date_exact=str(payload.get("date_exact", "")),
            start_date=str(payload.get("start_date", "")),
            end_date=str(payload.get("end_date", "")),
            sort_by=str(payload.get("sort_by", "date_desc")),
            page=int(payload.get("page", 1) or 1),
            page_size=int(payload.get("page_size", 0) or 0),
        )
        return {"ok": True, **res}

    if action == "add_record":
        res = record_service.add_record(payload, dataset=dataset)
        settings = storage.load_settings()
        active_ds = dataset or settings.active_dataset
        analytics = compute_analytics(storage.load_records(active_ds), settings, reference_date=ref_date)
        return {"ok": True, **res, "analytics": analytics}

    if action == "update_record":
        record_id = int(payload.get("id", 0))
        res = record_service.update_record(record_id, payload, dataset=dataset)
        settings = storage.load_settings()
        active_ds = dataset or settings.active_dataset
        analytics = compute_analytics(storage.load_records(active_ds), settings, reference_date=ref_date)
        return {"ok": True, **res, "analytics": analytics}

    if action == "delete_record":
        record_id = int(payload.get("id", 0))
        res = record_service.delete_record(record_id, dataset=dataset)
        settings = storage.load_settings()
        active_ds = dataset or settings.active_dataset
        analytics = compute_analytics(storage.load_records(active_ds), settings, reference_date=ref_date)
        return {"ok": True, **res, "analytics": analytics}

    if action == "get_analytics":
        settings = storage.load_settings()
        active_ds = dataset or settings.active_dataset
        records = storage.load_records(active_ds)
        analytics = compute_analytics(records, settings, reference_date=ref_date)
        return {"ok": True, "analytics": analytics, "chart_engine": get_chart_engine_status()}

    if action == "get_settings":
        settings = storage.load_settings()
        return {"ok": True, "settings": settings.to_dict()}

    if action == "update_settings":
        current = storage.load_settings()
        updated = validate_settings_payload(payload, current)
        storage.save_settings(updated)
        records = storage.load_records(updated.active_dataset)
        analytics = compute_analytics(records, updated, reference_date=ref_date)
        return {"ok": True, "settings": updated.to_dict(), "analytics": analytics}

    if action == "reset_demo":
        records = storage.reset_demo_data(reference_date=ref_date)
        settings = storage.load_settings()
        analytics = compute_analytics(records, settings, reference_date=ref_date)
        return {
            "ok": True,
            "count": len(records),
            "records": [r.to_dict() for r in records],
            "analytics": analytics,
        }

    if action == "clear_personal":
        records = storage.clear_personal_data()
        settings = storage.load_settings()
        analytics = compute_analytics(records, settings, reference_date=ref_date)
        return {"ok": True, "count": 0, "records": [], "analytics": analytics}

    if action == "import_preview":
        csv_text = str(payload.get("csv_text", ""))
        preview = record_service.preview_csv_import(csv_text, dataset=dataset)
        return {"ok": True, **preview}

    if action == "import_commit":
        csv_text = str(payload.get("csv_text", ""))
        result = record_service.commit_csv_import(csv_text, dataset=dataset)
        settings = storage.load_settings()
        active_ds = dataset or settings.active_dataset
        analytics = compute_analytics(storage.load_records(active_ds), settings, reference_date=ref_date)
        return {"ok": True, **result, "analytics": analytics}

    if action == "report_summary":
        summary = report_service.build_report_summary(
            dataset=dataset,
            start_date=str(payload.get("start_date", "")),
            end_date=str(payload.get("end_date", "")),
            category=str(payload.get("category", "")),
            search=str(payload.get("search", "")),
            title=str(payload.get("title", "Water Intake Summary Report")),
            reference_date=ref_date,
        )
        return {"ok": True, "summary": summary, "chart_engine": get_chart_engine_status()}

    if action == "export_report":
        fmt = str(payload.get("format", "csv")).lower()
        summary = report_service.build_report_summary(
            dataset=dataset,
            start_date=str(payload.get("start_date", "")),
            end_date=str(payload.get("end_date", "")),
            category=str(payload.get("category", "")),
            search=str(payload.get("search", "")),
            title=str(payload.get("title", "Water Intake Summary Report")),
            reference_date=ref_date,
        )
        if fmt == "csv":
            content = report_service.export_csv(summary["records"])
            mime = "text/csv; charset=utf-8"
            filename = f"water_intake_report_{summary['dataset']}.csv"
        elif fmt in ("md", "markdown"):
            content = report_service.export_markdown(summary)
            mime = "text/markdown; charset=utf-8"
            filename = f"water_intake_report_{summary['dataset']}.md"
        elif fmt == "txt":
            content = report_service.export_txt(summary)
            mime = "text/plain; charset=utf-8"
            filename = f"water_intake_audit_{summary['dataset']}.txt"
        else:
            raise ValidationIssue("Supported export formats are csv, md, and txt.", code="UNSUPPORTED_FORMAT")

        return {"ok": True, "content": content, "mime": mime, "filename": filename}

    if action == "chart_status":
        return {"ok": True, **get_chart_engine_status()}

    if action == "generate_chart":
        chart_type = str(payload.get("chart_type", "weekly_line"))
        settings = storage.load_settings()
        active_ds = dataset or settings.active_dataset
        records = storage.load_records(active_ds)
        analytics = compute_analytics(records, settings, reference_date=ref_date)
        out_path = REPORTS_DIR / f"chart_{chart_type}.png"
        result = generate_matplotlib_chart(chart_type, analytics, out_path)
        return {"ok": result.get("success", False), **result}

    raise ValidationIssue(f"Unknown backend action: {action}", code="UNKNOWN_ACTION")


def main() -> None:
    try:
        raw_stdin = sys.stdin.read()
        request_data = json.loads(raw_stdin) if raw_stdin.strip() else {}
        action = str(request_data.get("action", ""))
        payload = request_data.get("payload", {}) or {}
        response = dispatch(action, payload)
        print(json.dumps(response))
    except ValidationIssue as err:
        print(json.dumps({"ok": False, "error": err.message, "field": err.field, "code": err.code}))
        sys.exit(0)
    except Exception as exc:
        print(json.dumps({"ok": False, "error": "An unexpected storage or processing error occurred. Please try again.", "code": "INTERNAL_ERROR"}))
        sys.exit(0)


if __name__ == "__main__":
    main()
