# Water Intake Reminder Log — React Frontend + Python Flask Backend

A responsive hydration tracker with a React/TypeScript frontend and a **Python Flask REST API** backend. All application data, validation, persistence, analytics, imports, and reports are handled by Python.

## Features

- Hydration dashboard with daily intake, target progress, quick-add, timeline, and weekly overview.
- Demo and personal datasets kept separate.
- Python-side validation and local JSON/CSV persistence.
- Searchable intake history with filters, sorting, editing, deletion, and pagination.
- Daily, weekly, monthly, category, and target-vs-actual analytics.
- CSV import preview, validation, and commit.
- CSV, Markdown, and text reports; chart PNG export when Matplotlib is installed.
- Configurable reminders, browser notifications, and light/dark themes.

## Requirements

- Python 3.10+
- Node.js 20+

## Run the complete website

Open a terminal in this project folder and run:

```bash
# 1. Build the React website
npm install
npm run build

# 2. Install Python backend dependencies
python -m pip install -r backend/requirements.txt

# 3. Start the website and Python API together
python backend/app.py
```

Then open **http://localhost:5000**. Flask serves the built React website and handles `/api/*` requests directly. No Express/Node backend is required at runtime.

For frontend development with hot reload, run `npm run dev:frontend` in one terminal and `python backend/app.py` in another. The built production setup is the recommended way to run the complete app.

## Run tests

```bash
python -m unittest discover -s tests -v
```

## Data storage

Personal records, demo records, and settings are stored locally under `backend/storage/`. Keep this folder if you want to preserve your data. Do not commit personal records to a public repository.
