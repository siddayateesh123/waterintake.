"""Flask application serving the React frontend and Python REST API."""
from pathlib import Path
import sys

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from flask import Flask, jsonify, send_from_directory
from flask_cors import CORS
from backend.routes.api import api_bp

DIST_DIR = ROOT_DIR / "dist"


def create_app() -> Flask:
    app = Flask(__name__, static_folder=str(DIST_DIR), static_url_path="")
    CORS(app)
    app.register_blueprint(api_bp)

    @app.get("/health")
    @app.get("/api/health")
    def health():
        return jsonify({"ok": True, "status": "ok", "service": "Water Intake Reminder Log Flask API"})

    @app.get("/api/sample-file/<kind>")
    def sample_file(kind):
        files = {
            "csv": "sample_records.csv",
            "json": "sample_records.json",
            "mixed_csv": "sample_import_mixed_test.csv",
        }
        filename = files.get(kind)
        path = ROOT_DIR / "sample_data" / filename if filename else None
        if not path or not path.is_file():
            return jsonify({"ok": False, "error": "Sample file not found."}), 404
        return jsonify({"ok": True, "filename": filename, "content": path.read_text(encoding="utf-8")})

    @app.route("/", defaults={"path": ""})
    @app.route("/<path:path>")
    def frontend(path):
        requested = DIST_DIR / path
        if path and requested.is_file():
            return send_from_directory(DIST_DIR, path)
        index_file = DIST_DIR / "index.html"
        if index_file.is_file():
            return send_from_directory(DIST_DIR, "index.html")
        return ("Frontend build not found. Run: npm install && npm run build", 503)

    return app


if __name__ == "__main__":
    create_app().run(host="0.0.0.0", port=5000, debug=False)
