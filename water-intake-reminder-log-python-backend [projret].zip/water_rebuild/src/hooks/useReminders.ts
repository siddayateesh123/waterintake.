import { useEffect, useRef } from "react";
import type { AppSettings, ToastNotification } from "../types/hydration";

export function useReminders(
  settings: AppSettings | null,
  remainingMl: number,
  pushToast: (toast: Omit<ToastNotification, "id" | "timestamp">) => void
) {
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }

    if (!settings || !settings.reminders_enabled) return;

    const intervalMs = Math.max(1, settings.reminder_interval_min) * 60 * 1000;

    timerRef.current = window.setInterval(() => {
      const msg =
        remainingMl > 0
          ? `Time for a hydration break. ${Math.round(remainingMl).toLocaleString()} ml remaining toward today's target.`
          : "Scheduled hydration reminder: you have already met today's hydration target.";

      pushToast({
        type: "reminder",
        title: "Hydration Reminder",
        message: msg,
      });

      if (
        settings.browser_notifications &&
        typeof window !== "undefined" &&
        "Notification" in window &&
        Notification.permission === "granted"
      ) {
        try {
          new Notification("Water Intake Reminder Log", {
            body: msg,
          });
        } catch {
          // Fallback already shown via in-app toast
        }
      }
    }, intervalMs);

    return () => {
      if (timerRef.current) {
        window.clearInterval(timerRef.current);
      }
    };
  }, [
    settings?.reminders_enabled,
    settings?.reminder_interval_min,
    settings?.browser_notifications,
    remainingMl,
    pushToast,
  ]);
}
