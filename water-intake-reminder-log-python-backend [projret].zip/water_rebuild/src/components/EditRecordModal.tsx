import { useEffect, useState } from "react";
import { X } from "lucide-react";
import type { CategoryType, WaterRecord } from "../types/hydration";

interface EditRecordModalProps {
  record: WaterRecord | null;
  onClose: () => void;
  onSave: (
    id: number,
    payload: {
      amount_ml: string;
      date: string;
      time: string;
      category: CategoryType;
      notes: string;
    }
  ) => Promise<void>;
}

const CATEGORIES: CategoryType[] = ["Morning", "Afternoon", "Evening", "Night", "Other"];

export function EditRecordModal({ record, onClose, onSave }: EditRecordModalProps) {
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [category, setCategory] = useState<CategoryType>("Morning");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (record) {
      setAmount(String(record.amount_ml));
      setDate(record.date);
      setTime(record.time);
      setCategory(record.category);
      setNotes(record.notes || "");
      setError("");
    }
  }, [record]);

  if (!record) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSaving(true);
    try {
      await onSave(record.id, {
        amount_ml: amount,
        date,
        time,
        category,
        notes,
      });
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to update record.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4 backdrop-blur-[1px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="edit-record-title"
    >
      <div className="w-full max-w-md rounded-xl border border-blue-100 bg-white p-6 shadow-xl dark:border-slate-700 dark:bg-slate-900">
        <div className="flex items-center justify-between">
          <h2 id="edit-record-title" className="font-display text-base font-bold text-[#172554] dark:text-slate-50">
            Edit Record #{record.id}
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800"
            aria-label="Close edit modal"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          {error && (
            <div className="rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs font-medium text-red-700 dark:border-red-900 dark:bg-red-950/50 dark:text-red-300">
              {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
              Water Amount (ml)
            </label>
            <input
              type="text"
              inputMode="decimal"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="mt-1.5 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3.5 py-2 font-mono-num text-sm text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                Date
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3 py-2 font-mono-num text-sm text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                Time
              </label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3 py-2 font-mono-num text-sm text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
              Category
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as CategoryType)}
              className="mt-1.5 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3.5 py-2 text-sm text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
              Notes
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              maxLength={300}
              className="mt-1.5 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3.5 py-2 text-sm text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            />
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="rounded-lg bg-[#2196F3] px-4 py-2 text-xs font-semibold text-white hover:bg-blue-600 disabled:opacity-60"
            >
              {saving ? "Saving..." : "Save Changes"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
