"""Centralized defensive input validation for Water Intake Reminder Log."""

from datetime import datetime
import math
import re
from typing import Any, Dict, Optional, Tuple

from backend.models.water_record import AppSettings, VALID_CATEGORIES, ValidationIssue


MAX_SINGLE_ENTRY_ML = 10000.0
MIN_TARGET_ML = 250
MAX_TARGET_ML = 15000


def validate_amount(raw_amount: Any, field_name: str = "amount_ml") -> float:
    """Validate that water amount is a positive, finite number within sensible bounds."""
    if raw_amount is None or (isinstance(raw_amount, str) and raw_amount.strip() == ""):
        raise ValidationIssue("Water amount is required and cannot be blank.", field=field_name, code="EMPTY_AMOUNT")

    if isinstance(raw_amount, bool):
        raise ValidationIssue("Water amount must be a valid number.", field=field_name, code="INVALID_AMOUNT")

    if isinstance(raw_amount, str):
        cleaned = raw_amount.strip()
        if not re.fullmatch(r"[-+]?\d+(\.\d+)?", cleaned):
            raise ValidationIssue(
                "Water amount must contain numbers only (for example: 250).",
                field=field_name,
                code="NON_NUMERIC_AMOUNT",
            )
        try:
            value = float(cleaned)
        except ValueError as exc:
            raise ValidationIssue("Water amount must be a valid number.", field=field_name, code="INVALID_AMOUNT") from exc
    elif isinstance(raw_amount, (int, float)):
        value = float(raw_amount)
    else:
        raise ValidationIssue("Water amount must be a valid number.", field=field_name, code="INVALID_AMOUNT")

    if math.isnan(value) or math.isinf(value):
        raise ValidationIssue("Water amount must be a finite number.", field=field_name, code="INVALID_AMOUNT")

    if value < 0:
        raise ValidationIssue("Water amount cannot be negative.", field=field_name, code="NEGATIVE_AMOUNT")

    if value == 0:
        raise ValidationIssue("Water amount must be greater than zero.", field=field_name, code="ZERO_AMOUNT")

    if value > MAX_SINGLE_ENTRY_ML:
        raise ValidationIssue(
            f"Single entry cannot exceed {int(MAX_SINGLE_ENTRY_ML)} ml. Please verify your entry.",
            field=field_name,
            code="AMOUNT_TOO_LARGE",
        )

    return round(value, 2)


def validate_date(raw_date: Any, field_name: str = "date") -> str:
    """Validate YYYY-MM-DD date string."""
    if raw_date is None or not isinstance(raw_date, str) or raw_date.strip() == "":
        raise ValidationIssue("Date is required (YYYY-MM-DD).", field=field_name, code="EMPTY_DATE")

    cleaned = raw_date.strip()
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", cleaned):
        raise ValidationIssue("Date must follow YYYY-MM-DD format.", field=field_name, code="INVALID_DATE_FORMAT")

    try:
        parsed = datetime.strptime(cleaned, "%Y-%m-%d").date()
    except ValueError as exc:
        raise ValidationIssue("The entered date is not a valid calendar date.", field=field_name, code="INVALID_DATE") from exc

    if parsed.year < 2000 or parsed.year > 2100:
        raise ValidationIssue("Date year must be between 2000 and 2100.", field=field_name, code="DATE_OUT_OF_RANGE")

    return cleaned


def validate_time(raw_time: Any, field_name: str = "time") -> str:
    """Validate HH:MM 24-hour time string (accepts HH:MM:SS by normalizing to HH:MM)."""
    if raw_time is None or not isinstance(raw_time, str) or raw_time.strip() == "":
        raise ValidationIssue("Time is required (HH:MM).", field=field_name, code="EMPTY_TIME")

    cleaned = raw_time.strip()
    if re.fullmatch(r"\d{2}:\d{2}:\d{2}", cleaned):
        cleaned = cleaned[:5]

    if not re.fullmatch(r"\d{1,2}:\d{2}", cleaned):
        raise ValidationIssue("Time must follow 24-hour HH:MM format.", field=field_name, code="INVALID_TIME_FORMAT")

    try:
        parsed = datetime.strptime(cleaned, "%H:%M")
    except ValueError as exc:
        raise ValidationIssue("Time must be a valid 24-hour clock value (00:00 to 23:59).", field=field_name, code="INVALID_TIME") from exc

    return parsed.strftime("%H:%M")


def validate_category(raw_category: Any, field_name: str = "category") -> str:
    """Validate hydration time-of-day category."""
    if raw_category is None or not isinstance(raw_category, str) or raw_category.strip() == "":
        raise ValidationIssue("Category is required.", field=field_name, code="EMPTY_CATEGORY")

    cleaned = raw_category.strip().capitalize()
    if cleaned not in VALID_CATEGORIES:
        allowed = ", ".join(VALID_CATEGORIES)
        raise ValidationIssue(
            f"Category must be one of: {allowed}.",
            field=field_name,
            code="INVALID_CATEGORY",
        )
    return cleaned


def validate_notes(raw_notes: Any, field_name: str = "notes") -> str:
    """Sanitize optional notes text."""
    if raw_notes is None:
        return ""
    if not isinstance(raw_notes, str):
        raw_notes = str(raw_notes)
    cleaned = raw_notes.strip()
    if len(cleaned) > 300:
        raise ValidationIssue("Notes cannot exceed 300 characters.", field=field_name, code="NOTES_TOO_LONG")
    return cleaned


def validate_record_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Validate and normalize a full water intake record payload."""
    if not isinstance(payload, dict):
        raise ValidationIssue("Invalid request payload.", code="INVALID_PAYLOAD")

    amount_ml = validate_amount(payload.get("amount_ml"))
    date_str = validate_date(payload.get("date"))
    time_str = validate_time(payload.get("time"))
    category = validate_category(payload.get("category"))
    notes = validate_notes(payload.get("notes", ""))

    return {
        "date": date_str,
        "time": time_str,
        "amount_ml": int(amount_ml) if float(amount_ml).is_integer() else amount_ml,
        "category": category,
        "notes": notes,
    }


def check_unusual_intake(amount_ml: float, settings: AppSettings) -> Optional[Dict[str, str]]:
    """Return a non-medical configurable threshold notice when an entry is unusually low or high."""
    if amount_ml < settings.low_threshold_ml:
        return {
            "level": "low",
            "message": (
                f"Entry of {int(amount_ml) if float(amount_ml).is_integer() else amount_ml} ml is below "
                f"your configured low-entry threshold ({settings.low_threshold_ml} ml). Please verify if this was intentional."
            ),
        }
    if amount_ml > settings.high_threshold_ml:
        return {
            "level": "high",
            "message": (
                f"Entry of {int(amount_ml) if float(amount_ml).is_integer() else amount_ml} ml exceeds "
                f"your configured single-entry threshold ({settings.high_threshold_ml} ml). Please double-check the amount."
            ),
        }
    return None


def validate_settings_payload(payload: Dict[str, Any], current: AppSettings) -> AppSettings:
    """Validate partial or complete settings update against current settings."""
    if not isinstance(payload, dict):
        raise ValidationIssue("Invalid settings payload.", code="INVALID_PAYLOAD")

    daily_target_ml = current.daily_target_ml
    if "daily_target_ml" in payload:
        raw_target = payload["daily_target_ml"]
        target_val = validate_amount(raw_target, field_name="daily_target_ml")
        if target_val < MIN_TARGET_ML or target_val > MAX_TARGET_ML:
            raise ValidationIssue(
                f"Daily target must be between {MIN_TARGET_ML} ml and {MAX_TARGET_ML} ml.",
                field="daily_target_ml",
                code="TARGET_OUT_OF_RANGE",
            )
        daily_target_ml = int(round(target_val))

    preferred_unit = current.preferred_unit
    if "preferred_unit" in payload:
        unit = str(payload["preferred_unit"]).strip()
        if unit not in ("ml", "L"):
            raise ValidationIssue("Preferred unit must be 'ml' or 'L'.", field="preferred_unit")
        preferred_unit = unit

    reminders_enabled = current.reminders_enabled
    if "reminders_enabled" in payload:
        if not isinstance(payload["reminders_enabled"], bool):
            raise ValidationIssue("Reminders enabled must be true or false.", field="reminders_enabled")
        reminders_enabled = payload["reminders_enabled"]

    reminder_interval_min = current.reminder_interval_min
    if "reminder_interval_min" in payload:
        raw_interval = payload["reminder_interval_min"]
        interval_val = validate_amount(raw_interval, field_name="reminder_interval_min")
        if interval_val < 1 or interval_val > 720:
            raise ValidationIssue("Reminder interval must be between 1 and 720 minutes.", field="reminder_interval_min")
        reminder_interval_min = int(round(interval_val))

    browser_notifications = current.browser_notifications
    if "browser_notifications" in payload:
        if not isinstance(payload["browser_notifications"], bool):
            raise ValidationIssue("Browser notifications must be true or false.", field="browser_notifications")
        browser_notifications = payload["browser_notifications"]

    low_threshold_ml = current.low_threshold_ml
    if "low_threshold_ml" in payload:
        low_val = validate_amount(payload["low_threshold_ml"], field_name="low_threshold_ml")
        if low_val < 1 or low_val > 2000:
            raise ValidationIssue("Low intake warning threshold must be between 1 and 2000 ml.", field="low_threshold_ml")
        low_threshold_ml = int(round(low_val))

    high_threshold_ml = current.high_threshold_ml
    if "high_threshold_ml" in payload:
        high_val = validate_amount(payload["high_threshold_ml"], field_name="high_threshold_ml")
        if high_val < 100 or high_val > MAX_SINGLE_ENTRY_ML:
            raise ValidationIssue(
                f"High intake warning threshold must be between 100 and {int(MAX_SINGLE_ENTRY_ML)} ml.",
                field="high_threshold_ml",
            )
        high_threshold_ml = int(round(high_val))

    if low_threshold_ml >= high_threshold_ml:
        raise ValidationIssue(
            "Low warning threshold must be less than high warning threshold.",
            field="low_threshold_ml",
        )

    theme = current.theme
    if "theme" in payload:
        t = str(payload["theme"]).strip().lower()
        if t not in ("light", "dark"):
            raise ValidationIssue("Theme must be 'light' or 'dark'.", field="theme")
        theme = t

    active_dataset = current.active_dataset
    if "active_dataset" in payload:
        ds = str(payload["active_dataset"]).strip().lower()
        if ds not in ("demo", "personal"):
            raise ValidationIssue("Dataset mode must be 'demo' or 'personal'.", field="active_dataset")
        active_dataset = ds

    return AppSettings(
        daily_target_ml=daily_target_ml,
        preferred_unit=preferred_unit,
        reminders_enabled=reminders_enabled,
        reminder_interval_min=reminder_interval_min,
        browser_notifications=browser_notifications,
        low_threshold_ml=low_threshold_ml,
        high_threshold_ml=high_threshold_ml,
        theme=theme,
        active_dataset=active_dataset,
    )
