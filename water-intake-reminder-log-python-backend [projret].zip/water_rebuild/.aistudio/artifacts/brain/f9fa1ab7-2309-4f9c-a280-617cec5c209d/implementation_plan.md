# Water Intake Reminder Log

A full-stack hydration tracking, analytics, and reporting web application (**CampusSolve Project #31 — Health & Wellbeing**) built with a responsive React + Tailwind + Recharts workspace backed by an Express API, a modular Python 3.11 persistence/validation/analytics engine, and standalone Flask + Matplotlib backend source modules.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> All four architectural and UX preferences confirmed during clarification are locked into this plan. Review the summary below and click **Proceed** to begin implementation.

- **Confirmed Decision 1 (Live Preview Backend + Python Stack)**: Express serves the Vite-built React frontend and REST API on port `3000`, delegating data validation, JSON/CSV atomic persistence, analytics calculations, CSV import auditing, and report generation to a **Python 3.11** engine via subprocess calls. A complete standalone **Flask + Matplotlib** backend (`requirements.txt`, modular routes/services/analytics) is also included for native Python deployment.
- **Confirmed Decision 2 (First-Launch & Sample Data Experience)**: The app launches directly into the **Dashboard** with a dismissible **Welcome Banner** and a prominent **Dataset Mode Toggle** (`Personal Log` vs. `Demo Dataset` with 40+ realistic records), keeping demonstration data strictly isolated from actual user records.
- **Confirmed Decision 3 (Visual Identity & Dual Theme)**: Uses a **Crisp Clinical Light Canvas** (`#F4F9FF` canvas, `#FFFFFF` cards, `#2196F3` Ocean Blue, `#38BDF8` Aqua, `#14B8A6` Teal, `#172554` Dark Navy) paired with a **Deep Slate Dark Mode** (`#0F172A` canvas, `#1E293B` elevated cards) toggled seamlessly across all views.
- **Confirmed Decision 4 (Reminders & Intake Warnings)**: Uses non-intrusive **in-app toast notifications** paired with optional **browser Notification API** alerts for scheduled hydration intervals, daily goal milestones, and configurable high/low intake threshold warnings.

---

## 1. Overview & Core Concept

- **What It Does**: Replaces a traditional terminal-based Python water logger with a full-featured, responsive hydration dashboard. Users record water intake in milliliters, customize daily hydration targets, browse/filter/edit historical logs, inspect daily/weekly/monthly analytics charts, bulk-import CSV datasets with row-level validation, and export formatted CSV, Markdown, TXT, and PNG graphical reports.
- **Target Audience**: Students and everyday users seeking reliable, private, local-first hydration tracking without external cloud subscriptions or medical claims.
- **Key Value**: Combines instant, beginner-friendly quick-logging and responsive interactive charts with strict defensive validation, resilient JSON/CSV file persistence, and comprehensive export/audit capabilities.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **First Launch & Onboarding**: User lands on the Dashboard showing a dismissible welcome banner explaining CampusSolve Project #31, current date/day, hydration status, and a dataset switcher (`Demo Dataset` pre-populated with 42 realistic records vs. clean `Personal Log`).
2. **Quick-Log & Full Recording**: Clicking quick-add buttons (`100 ml`, `150 ml`, `200 ml`, `250 ml`, `300 ml`, or `Custom`) prompts a lightweight confirmation and immediately saves to JSON & CSV, updating all 4 KPI cards, the animated circular progress ring, today's timeline, and analytics without a page reload. The dedicated **Log Water Intake** view supports custom amounts, date, time, category (`Morning`, `Afternoon`, `Evening`, `Night`, `Other`), and optional notes with inline validation errors.
3. **History Search & Management**: The **History** view displays a paginated, sortable table (`ID`, `Date`, `Time`, `Amount`, `Category`, `Notes`, `Actions`) with live keyword search, category selector, single-date or date-range filtering, inline edit modal, delete confirmation modal, and a `Reset Filters` control.
4. **Analytics & Report Export**: **Analytics** renders 5 synchronized Recharts visualizations (Daily Bar, Weekly Line, Monthly Area, Category Donut, Target vs. Actual Comparison) with timeframe filters and downloadable PNG chart exports. **Reports & Export** generates live summary cards and one-click downloads in CSV (all or filtered), Markdown, Plain Text audit log, and PNG charts.
5. **Bulk CSV Import**: **Import Data** lets users upload `.csv` files (or test with the bundled sample CSV), displays a row-by-row validation preview flagging malformed numbers, missing fields, invalid dates, or duplicates, and commits only valid rows while producing a downloadable error summary.
6. **Settings, Reminders & Help**: **Settings** configures daily target (ml/L), preferred display unit (`ml` or `L`), reminder intervals, browser notification permission, configurable unusual-intake warning thresholds, light/dark theme, demo data reset, and destructive data clearing (with confirmation). **Help & About** documents CampusSolve Project #31, validation rules, persistence format, and usage guide.

### Visual Identity & Theme

- **Aesthetic Direction**: Clean clinical precision with calm hydration clarity—single-elevation hairline surfaces (`1px` borders, zero nested cards-within-cards), generous breathing room, and tabular alignment for every numeric reading.
- **Color Palette & Tokens**:
  - *Light Mode*: `--background: #F4F9FF`, `--surface: #FFFFFF`, `--border: #E2E8F0`, `--text-primary: #172554`, `--text-muted: #475569`
  - *Dark Mode*: `--background: #0F172A`, `--surface: #1E293B`, `--border: #334155`, `--text-primary: #F8FAFC`, `--text-muted: #94A3B8`
  - *Brand & Semantic Accents (10% budget)*: Ocean Blue `#2196F3` (primary actions), Aqua `#38BDF8` (secondary chart series), Teal `#14B8A6` (goal met / positive progress), Amber `#D97706` (unusual intake warning with text label), Crimson `#DC2626` (validation/destructive error with text label).
- **Typography & Hierarchy**:
  - *Display & Navigation*: `Plus Jakarta Sans` (weights 600–700, `text-wrap: balance` on headings).
  - *Body & Forms*: `DM Sans` (14px–16px, 1.5–1.6 line-height).
  - *Metrics, Timestamps & Tables*: `JetBrains Mono` with `tabular-nums` on all milliliter/liter totals, percentages, dates, and IDs.
- **Component Styling & Restraint**:
  - Left collapsible sidebar (`260px` desktop, slide-over drawer on mobile/tablet) with 8 navigation items and a top contextual header bar (`Current View`, `Date & Day`, `Quick Add`, `Notifications`, `Theme Switch`, `Settings`).
  - Zero static pill enclosures for metadata (render category/date/unit metadata as clean inline text with `·` separators); interactive filter tabs and quick-add buttons use crisp segmented button styling.
  - Smooth `150ms`–`200ms` transitions on `transform` and `opacity` only (`cubic-bezier(0.16, 1, 0.3, 1)`), animated SVG circular completion ring, and clean empty/loading/error states across all views.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Hybrid Express + Python 3.11 Runtime Alongside Standalone Flask/Matplotlib Codebase**
  - *Chosen Approach*: Express handles HTTP serving on port `3000` and routes API requests directly to a Python 3.11 stdlib engine for validation, JSON/CSV persistence, analytics aggregation, CSV import auditing, and report generation. Standalone Flask routes and Matplotlib chart generators are also maintained in the backend package for native Python execution.
  - *Why*: The live preview container runs Node.js `v22` and Python `3.11.2` stdlib (without `pip`, `flask`, or `matplotlib` preinstalled). Bridging Express to Python 3.11 ensures 100% real Python business logic, file persistence, and automated Python tests run live in preview without failing on missing third-party Python packages.
  - *Alternatives Considered*: Pure TypeScript backend (would bypass Python in live execution) or raw Python `http.server` only (less seamless integration with Vite dev middleware on port `3000`).

- **Decision 2: Resilient PNG Chart Export with Matplotlib + Built-in PNG Fallback**
  - *Chosen Approach*: The Python analytics module uses Matplotlib when installed; when Matplotlib is absent in the runtime environment, the backend reports Matplotlib status transparently and the frontend/server exports high-resolution crisp PNG charts rendered directly from the live Recharts/Canvas data.
  - *Why*: Guarantees the user can always download crisp PNG analytical graphs during a live hackathon demo even without Matplotlib installed, while clearly explaining Matplotlib availability status as required.

- **Decision 3: Isolated Personal vs. Demo Storage Files**
  - *Chosen Approach*: Persist user records in dedicated `water_records.json`, `water_records.csv`, and `settings.json`, while storing demonstration records in separate `sample_records.json` / `sample_records.csv` and an active mode flag.
  - *Why*: Prevents accidental overwriting of personal hydration records when toggling or resetting the 40+ record demonstration dataset, while maintaining 100% JSON/CSV synchronization in both modes.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### System Architecture Diagram

```
┌──────────────────────────────────────────────────────────────────────────┐
│                        Browser Client (React 19)                         │
│                                                                          │
│  ┌─────────────────────┐   ┌──────────────────────────────────────────┐  │
│  │ Collapsible Sidebar │   │ Main Workspace & Toast / Browser Alerts  │  │
│  │ • Dashboard         │   │ • KPI Cards + Animated Circular Ring     │  │
│  │ • Log Water Intake  │   │ • Quick-Add & Validated Intake Form      │  │
│  │ • History           │   │ • Search/Filter/Paginated Records Table  │  │
│  │ • Analytics         │   │ • 5 Recharts Views + PNG Graph Exporter  │  │
│  │ • Reports & Export  │   │ • CSV/MD/TXT Report Generator            │  │
│  │ • Import Data       │   │ • Bulk CSV Preview & Error Auditor       │  │
│  │ • Settings          │   │ • Target, Unit, Threshold & Theme Config │  │
│  │ • Help & About      │   │ • CampusSolve #31 Documentation          │  │
│  └──────────┬──────────┘   └────────────────────┬─────────────────────┘  │
└─────────────┼───────────────────────────────────┼────────────────────────┘
              │         REST API (/api/*)         │
              ▼                                   ▼
┌──────────────────────────────────────────────────────────────────────────┐
│                 Express Server (Port 3000 + Vite Middleware)             │
│  • Serves SPA & static assets                                            │
│  • Invokes Python 3.11 CLI/Engine via JSON-over-stdio                    │
│  • Streams CSV, Markdown, TXT, and PNG report downloads                  │
└─────────────────────────────────────┬────────────────────────────────────┘
                                      │
                                      ▼
┌──────────────────────────────────────────────────────────────────────────┐
│                    Python 3.11 Core Engine (+ Flask Source)              │
│                                                                          │
│  ┌──────────────────┐  ┌───────────────────┐  ┌───────────────────────┐  │
│  │ Validation Layer │  │ Analytics & Chart │  │   Report & Import     │  │
│  │ • Positive float │  │ • Daily / Weekly  │  │ • CSV / MD / TXT      │  │
│  │ • Date/Time ISO  │  │   / Monthly stats │  │ • Row-by-row CSV      │  │
│  │ • Category enum  │  │ • Matplotlib PNG  │  │   audit & deduping    │  │
│  └────────┬─────────┘  └─────────┬─────────┘  └───────────┬───────────┘  │
│           └──────────────────────┼────────────────────────┘              │
│                                  ▼                                       │
│  ┌────────────────────────────────────────────────────────────────────┐  │
│  │                 Atomic Persistence Layer (JSON + CSV)              │  │
│  │  • water_records.json & water_records.csv (synchronized writes)    │  │
│  │  • settings.json (target, unit, reminders, thresholds, theme)      │  │
│  │  • Corrupted JSON / malformed CSV auto-recovery + backup creation  │  │
│  └────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State

- **WaterRecord**: `{ id: number, date: "YYYY-MM-DD", time: "HH:MM", amount_ml: number, category: "Morning" | "Afternoon" | "Evening" | "Night" | "Other", notes: string, is_unusual?: boolean }`
- **AppSettings**: `{ daily_target_ml: number, preferred_unit: "ml" | "L", reminders_enabled: boolean, reminder_interval_min: number, browser_notifications: boolean, low_threshold_ml: number, high_threshold_ml: number, theme: "light" | "dark", active_dataset: "demo" | "personal" }`
- **AnalyticsSummary**: Computed dynamically in Python from active records + `daily_target_ml`:
  - *Daily*: `total_ml`, `target_ml`, `remaining_ml` (`max(0, target - total)`), `exceeded_ml`, `completion_pct`, `entry_count`, `highest_entry_ml`, `timeline_entries`.
  - *Weekly*: `total_ml`, `daily_average_ml`, `highest_day`, `lowest_day`, `days_target_achieved`, `daily_series[7]`.
  - *Monthly*: `total_ml`, `daily_average_ml`, `monthly_completion_pct`, `daily_patterns`, `weekly_comparison`, `category_distribution`.

### Interactive Component & State Mapping

- **Quick-Add & Confirmation Flow**: Clicking a preset amount (`100`–`300 ml`) or custom amount opens a fast confirmation prompt (or confirms inline), dispatches `POST /api/records`, runs Python validation + unusual-threshold check (`< low_threshold_ml` or `> high_threshold_ml`), writes both JSON & CSV atomically, triggers a success/warning/goal-reached toast (and optional browser notification), and refreshes Dashboard + Analytics state immediately.
- **History Filtering & CRUD**: Search keyword, category, start/end dates, and sort keys (`date_desc`, `date_asc`, `amount_desc`, `amount_asc`) query `/api/records` (or filter synchronized state with pagination) and support `PUT /api/records/:id` and `DELETE /api/records/:id` with confirmation.
- **CSV Bulk Import Pipeline**: Uploading a `.csv` file posts multipart/text content to `POST /api/import/preview` -> Python parses headers (`ID`, `Date`, `Time`, `Amount_ml`, `Category`, `Notes`), validates every cell and checks duplicates -> returns `{ valid_rows, invalid_rows, error_report }` -> user reviews preview table and clicks `Import Valid Rows` (`POST /api/import/commit`) to persist cleanly.
- **Reminder Scheduler**: Client-side interval hook tracks `reminders_enabled` and `reminder_interval_min`, firing in-app toast alerts and optional Web Notification API alerts at scheduled intervals without blocking UI interaction.
- **Automated Verification Suite**: Python `unittest` suite covering all 18 required test cases (CRUD, defensive validation, daily/weekly/completion math, search/filter, JSON & CSV sync, corrupted JSON recovery, CSV import/rejection, report generation, and chart output).
