import { useCallback, useEffect, useRef, useState } from "react";
import { Download, FileCode2, FileSpreadsheet, FileText, Image as ImageIcon, Info } from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { buildReportExportUrl, fetchReportSummary } from "../services/api";
import type { AnalyticsData, AppSettings, ChartEngineStatus, ReportSummary } from "../types/hydration";
import { formatVolume } from "../utils/formatters";
import { exportSvgElementAsPng } from "../utils/pngExport";

interface ReportsPageProps {
  settings: AppSettings;
  analytics: AnalyticsData;
  chartEngine: ChartEngineStatus;
  onNotify: (type: "success" | "info" | "error", title: string, message: string) => void;
}

const CATEGORIES = ["All", "Morning", "Afternoon", "Evening", "Night", "Other"] as const;

export function ReportsPage({
  settings,
  analytics,
  chartEngine,
  onNotify,
}: ReportsPageProps) {
  const [title, setTitle] = useState("Water Intake Summary Report");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [summary, setSummary] = useState<ReportSummary | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const previewChartRef = useRef<HTMLDivElement>(null);

  const loadSummary = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetchReportSummary({
        dataset: settings.active_dataset,
        start_date: startDate,
        end_date: endDate,
        category: category === "All" ? "" : category,
        search,
        title,
      });
      setSummary(res.summary);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to generate report summary.");
    } finally {
      setLoading(false);
    }
  }, [settings.active_dataset, startDate, endDate, category, search, title]);

  useEffect(() => {
    void loadSummary();
  }, [loadSummary]);

  const handleDownload = (format: "csv" | "md" | "txt", ignoreFilters = false) => {
    const url = buildReportExportUrl({
      dataset: settings.active_dataset,
      format,
      start_date: ignoreFilters ? "" : startDate,
      end_date: ignoreFilters ? "" : endDate,
      category: ignoreFilters || category === "All" ? "" : category,
      search: ignoreFilters ? "" : search,
      title,
    });
    const link = document.createElement("a");
    link.href = url;
    document.body.appendChild(link);
    link.click();
    link.remove();
    onNotify("success", "Report Exported", `Downloaded ${format.toUpperCase()} report.`);
  };

  const handleDownloadGraph = async (
    chartType: "weekly_line" | "target_vs_actual" | "daily_bar" | "monthly_area" | "category_donut"
  ) => {
    if (chartEngine.matplotlib_available) {
      window.location.href = `/api/charts/export/${chartType}?dataset=${settings.active_dataset}`;
      onNotify("success", "Matplotlib Graph Exported", `Downloaded ${chartType}.png.`);
      return;
    }

    const ok = await exportSvgElementAsPng(
      previewChartRef.current,
      `water_intake_${chartType}.png`,
      title || "Water Intake Summary Graph",
      `Dataset: ${settings.active_dataset} · Target: ${settings.daily_target_ml} ml`
    );
    if (ok) {
      onNotify("success", "PNG Graph Exported", "Saved high-resolution PNG chart.");
    } else {
      onNotify("error", "Graph Export Failed", "Unable to render PNG chart.");
    }
  };

  return (
    <div className="space-y-6">
      {/* Filter & Configuration Bar */}
      <section className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
          <div>
            <h2 className="font-display text-base font-bold text-[#172554] dark:text-slate-50">
              Configure Report Scope
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              All CSV, Markdown, and Plain Text exports dynamically reflect your selected date range and filters.
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              setStartDate("");
              setEndDate("");
              setCategory("All");
              setSearch("");
              setTitle("Water Intake Summary Report");
            }}
            className="self-start rounded-lg border border-blue-200 px-3 py-1.5 text-xs font-semibold text-[#172554] hover:bg-blue-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            Reset Scope
          </button>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <div className="lg:col-span-2">
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              Report Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="mt-1 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3 py-2 text-xs text-[#172554] focus:border-[#2196F3] focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              Start Date
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="mt-1 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3 py-2 font-mono-num text-xs text-[#172554] dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              End Date
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="mt-1 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3 py-2 font-mono-num text-xs text-[#172554] dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              Category
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="mt-1 w-full rounded-lg border border-blue-100 bg-[#F4F9FF] px-3 py-2 text-xs text-[#172554] dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            >
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c === "All" ? "All Categories" : c}
                </option>
              ))}
            </select>
          </div>
        </div>
      </section>

      {/* Export Action Cards */}
      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <FileSpreadsheet className="h-5 w-5 text-[#2196F3] dark:text-sky-400" />
          <h3 className="mt-3 font-display text-sm font-bold text-[#172554] dark:text-slate-50">
            CSV Data Export
          </h3>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Structured spreadsheet export with ID, Date, Time, Amount_ml, Category, and Notes.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => handleDownload("csv", false)}
              className="inline-flex items-center gap-1.5 rounded-lg bg-[#2196F3] px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-600"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export Filtered</span>
            </button>
            <button
              type="button"
              onClick={() => handleDownload("csv", true)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-blue-200 px-3 py-1.5 text-xs font-semibold text-[#172554] hover:bg-blue-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <span>All Records</span>
            </button>
          </div>
        </div>

        <div className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <FileCode2 className="h-5 w-5 text-[#14B8A6]" />
          <h3 className="mt-3 font-display text-sm font-bold text-[#172554] dark:text-slate-50">
            Markdown Report (.md)
          </h3>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Formatted Markdown summary with summary statistics, daily totals, and record tables.
          </p>
          <button
            type="button"
            onClick={() => handleDownload("md", false)}
            className="mt-4 inline-flex items-center gap-1.5 rounded-lg bg-[#14B8A6] px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-teal-600"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Download Markdown</span>
          </button>
        </div>

        <div className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <FileText className="h-5 w-5 text-[#38BDF8]" />
          <h3 className="mt-3 font-display text-sm font-bold text-[#172554] dark:text-slate-50">
            Plain Text Audit Log (.txt)
          </h3>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Human-readable fixed-width audit log listing dates, times, volumes, and categories.
          </p>
          <button
            type="button"
            onClick={() => handleDownload("txt", false)}
            className="mt-4 inline-flex items-center gap-1.5 rounded-lg bg-[#172554] px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-sky-600 dark:hover:bg-sky-500"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Download Audit TXT</span>
          </button>
        </div>

        <div className="rounded-xl border border-blue-100 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <ImageIcon className="h-5 w-5 text-[#2196F3] dark:text-sky-400" />
          <h3 className="mt-3 font-display text-sm font-bold text-[#172554] dark:text-slate-50">
            Graphical Chart (.png)
          </h3>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            {chartEngine.matplotlib_available
              ? "Server-side Matplotlib PNG chart generator ready."
              : "High-DPI browser PNG renderer active (Matplotlib fallback)."}
          </p>
          <button
            type="button"
            onClick={() => handleDownloadGraph("target_vs_actual")}
            className="mt-4 inline-flex items-center gap-1.5 rounded-lg border border-blue-200 bg-[#F4F9FF] px-3.5 py-1.5 text-xs font-semibold text-[#172554] hover:bg-blue-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Download PNG Chart</span>
          </button>
        </div>
      </section>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-xs font-medium text-red-700 dark:border-red-900 dark:bg-red-950/40 dark:text-red-300">
          {error}
        </div>
      )}

      {/* Report Summary Preview */}
      {summary && (
        <section className="rounded-xl border border-blue-100 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-col justify-between gap-2 border-b border-blue-100 pb-4 dark:border-slate-800 sm:flex-row sm:items-end">
            <div>
              <h2 className="font-display text-lg font-bold text-[#172554] dark:text-slate-50">
                {summary.title}
              </h2>
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                Range: <span className="font-mono-num">{summary.date_range.start}</span> to{" "}
                <span className="font-mono-num">{summary.date_range.end}</span> · Generated{" "}
                <span className="font-mono-num">{summary.generated_at}</span>
              </p>
            </div>
            {loading && <span className="text-xs text-slate-400">Refreshing summary...</span>}
          </div>

          <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Total Consumption</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#172554] dark:text-slate-50">
                {formatVolume(summary.total_consumption_ml, settings.preferred_unit)}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Daily Average</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#2196F3] dark:text-sky-400">
                {formatVolume(summary.average_daily_ml, settings.preferred_unit)}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Daily Target</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#172554] dark:text-slate-50">
                {formatVolume(summary.daily_target_ml, settings.preferred_unit)}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Target Completion</p>
              <p className="mt-1 font-mono-num text-base font-bold text-[#14B8A6]">
                {summary.target_completion_pct.toFixed(1)}%
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Highest Day</p>
              <p className="mt-1 font-mono-num text-xs font-bold text-[#172554] dark:text-slate-100">
                {summary.highest_intake_day.date}
                <span className="block font-normal text-slate-500">
                  {formatVolume(summary.highest_intake_day.total_ml, settings.preferred_unit)}
                </span>
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Lowest Day</p>
              <p className="mt-1 font-mono-num text-xs font-bold text-[#172554] dark:text-slate-100">
                {summary.lowest_intake_day.date}
                <span className="block font-normal text-slate-500">
                  {formatVolume(summary.lowest_intake_day.total_ml, settings.preferred_unit)}
                </span>
              </p>
            </div>
          </div>

          <div ref={previewChartRef} className="mt-6 border-t border-blue-50 pt-5 dark:border-slate-800">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                Graphical Summary Preview (Target vs Actual)
              </h3>
              <span className="flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400">
                <Info className="h-3.5 w-3.5 text-[#2196F3]" />
                <span>{summary.total_records} matching records</span>
              </span>
            </div>
            <div className="mt-3 h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={analytics.weekly.series} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                  <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#64748B" }} />
                  <YAxis tick={{ fontSize: 11, fill: "#64748B" }} />
                  <Tooltip formatter={(val) => `${Number(val ?? 0).toLocaleString()} ml`} />
                  <Legend />
                  <Bar dataKey="total_ml" name="Actual Intake (ml)" fill="#2196F3" radius={[5, 5, 0, 0]} />
                  <Bar dataKey="target_ml" name="Target (ml)" fill="#14B8A6" radius={[5, 5, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
